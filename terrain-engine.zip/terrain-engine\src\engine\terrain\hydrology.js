// ============================================================
// hydrology.js - 水文分析
// Priority-Flood 填洼 -> D8 流向 -> 汇流累积 -> 河网 / 湖泊 / 海洋
// 河流从高地顺坡汇聚成干流，入海处自然形成分汊与三角洲。
// 纯数值模块，可在 Web Worker 中运行。
// ============================================================
import { clamp, saturate, smoothstep } from '../geo/noise.js';

const DX = [0, 1, 1, 1, 0, -1, -1, -1];
const DY = [-1, -1, 0, 1, 1, 1, 0, -1];
const DIST = [1, 1.4142, 1, 1.4142, 1, 1.4142, 1, 1.4142];
const N4X = [0, 1, 0, -1];
const N4Y = [-1, 0, 1, 0];

/** 轻量二叉最小堆（Priority-Flood 用） */
class MinHeap {
  constructor(cap) {
    this.id = new Int32Array(cap);
    this.key = new Float32Array(cap);
    this.n = 0;
  }
  push(id, key) {
    let p = this.n++;
    this.id[p] = id;
    this.key[p] = key;
    while (p > 0) {
      const par = (p - 1) >> 1;
      if (this.key[par] <= this.key[p]) break;
      this.swap(par, p);
      p = par;
    }
  }
  pop() {
    const top = this.id[0];
    this.n--;
    if (this.n > 0) {
      this.id[0] = this.id[this.n];
      this.key[0] = this.key[this.n];
      let p = 0;
      for (;;) {
        const l = p * 2 + 1;
        const r = l + 1;
        let s = p;
        if (l < this.n && this.key[l] < this.key[s]) s = l;
        if (r < this.n && this.key[r] < this.key[s]) s = r;
        if (s === p) break;
        this.swap(p, s);
        p = s;
      }
    }
    return top;
  }
  swap(a, b) {
    const ti = this.id[a]; this.id[a] = this.id[b]; this.id[b] = ti;
    const tk = this.key[a]; this.key[a] = this.key[b]; this.key[b] = tk;
  }
}

/**
 * @param {Float32Array} dem 原始高程（会被读取但不修改）
 * @param {number} W
 * @param {number} H
 * @param {object} opt { seaLevel, water, riverThreshold, minRiverFlow }
 * @returns {object} 水文场
 */
export function analyzeHydrology(dem, W, H, opt = {}) {
  const N = W * H;
  const seaLevel = typeof opt.seaLevel === 'number' ? opt.seaLevel : 0.18;
  const water = opt.water || null;
  const eps = 1e-5;

  // ---------- 1. 海洋：从图幅边界出发的连通低洼水体 ----------
  const ocean = new Uint8Array(N);
  const stack = new Int32Array(N);
  let sp = 0;
  const isSea = (i) => {
    if (water) return water[i] > 0.5 && dem[i] < seaLevel + 0.02;
    return dem[i] < seaLevel;
  };
  const pushIf = (i) => {
    if (!ocean[i] && isSea(i)) { ocean[i] = 1; stack[sp++] = i; }
  };
  for (let x = 0; x < W; x++) {
    pushIf(x);
    pushIf((H - 1) * W + x);
  }
  for (let y = 0; y < H; y++) {
    pushIf(y * W);
    pushIf(y * W + W - 1);
  }
  while (sp > 0) {
    const i = stack[--sp];
    const x = i % W;
    const y = (i / W) | 0;
    if (x > 0) pushIf(i - 1);
    if (x < W - 1) pushIf(i + 1);
    if (y > 0) pushIf(i - W);
    if (y < H - 1) pushIf(i + W);
  }

  // ---------- 2. Priority-Flood 填洼 ----------
  // 从边界向内陆按最低溢出口扩展，保证每个像元都有一条顺坡入海路径。
  // 填洼量 depression 同时用来识别内陆湖盆。
  const filled = new Float32Array(N);
  const closed = new Uint8Array(N);
  const heap = new MinHeap(N);
  const seed = (i) => {
    if (!closed[i]) {
      closed[i] = 1;
      filled[i] = dem[i];
      heap.push(i, dem[i]);
    }
  };
  for (let x = 0; x < W; x++) { seed(x); seed((H - 1) * W + x); }
  for (let y = 0; y < H; y++) { seed(y * W); seed(y * W + W - 1); }

  while (heap.n > 0) {
    const i = heap.pop();
    const x = i % W;
    const y = (i / W) | 0;
    for (let d = 0; d < 8; d++) {
      const nx = x + DX[d];
      const ny = y + DY[d];
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const j = ny * W + nx;
      if (closed[j]) continue;
      closed[j] = 1;
      filled[j] = Math.max(dem[j], filled[i] + eps * DIST[d]);
      heap.push(j, filled[j]);
    }
  }
  const depression = new Float32Array(N);
  for (let i = 0; i < N; i++) depression[i] = filled[i] - dem[i];

  // ---------- 3. D8 流向 ----------
  const dir = new Int8Array(N);
  dir.fill(-1);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      if (ocean[i]) continue;
      let bestD = -1;
      let bestSlope = 0;
      for (let d = 0; d < 8; d++) {
        const nx = x + DX[d];
        const ny = y + DY[d];
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const j = ny * W + nx;
        const drop = (filled[i] - filled[j]) / DIST[d];
        if (drop > bestSlope) { bestSlope = drop; bestD = d; }
      }
      dir[i] = bestD;
    }
  }

  // ---------- 4. 汇流累积（按填洼高程从高到低做拓扑累加） ----------
  const order = new Int32Array(N);
  for (let i = 0; i < N; i++) order[i] = i;
  order.sort((a, b) => filled[b] - filled[a]);
  const flow = new Float32Array(N);
  for (let i = 0; i < N; i++) flow[i] = ocean[i] ? 0 : 1;
  for (let k = 0; k < N; k++) {
    const i = order[k];
    const d = dir[i];
    if (d < 0) continue;
    const x = i % W;
    const y = (i / W) | 0;
    const nx = x + DX[d];
    const ny = y + DY[d];
    if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
    flow[ny * W + nx] += flow[i];
  }
  let maxFlow = 1;
  for (let i = 0; i < N; i++) if (flow[i] > maxFlow) maxFlow = flow[i];

  // ---------- 5. 河网 / 河宽 / 水面高度 ----------
  // 阈值随图幅自适应：约千分之一的像元成为河道
  const baseThreshold = Math.max(12, N * 0.0014);
  const threshold = baseThreshold * (typeof opt.riverThreshold === 'number' ? opt.riverThreshold : 1);
  const river = new Float32Array(N);
  const riverWidth = new Float32Array(N);
  const riverLevel = new Float32Array(N);
  let riverCells = 0;
  for (let i = 0; i < N; i++) {
    if (ocean[i]) continue;
    if (flow[i] >= threshold) {
      const t = saturate(Math.log(flow[i] / threshold + 1) / Math.log(maxFlow / threshold + 1));
      river[i] = 0.35 + t * 0.65;
      riverWidth[i] = 0.8 + Math.sqrt(flow[i] / maxFlow) * Math.min(W, H) * 0.022;
      riverLevel[i] = Math.max(dem[i], seaLevel - 0.005);
      riverCells++;
    }
  }

  // ---------- 6. 湖泊：填洼深度显著的连通盆地 ----------
  const lake = new Uint8Array(N);
  const lakeLevel = new Float32Array(N);
  const visited = new Uint8Array(N);
  let lakeCount = 0;
  const comp = new Int32Array(N);
  for (let i = 0; i < N; i++) {
    if (visited[i] || ocean[i] || depression[i] < 0.012) continue;
    // 连通分量
    let head = 0;
    comp[head++] = i;
    visited[i] = 1;
    let peak = filled[i];
    let deepest = 0;
    let touchesSea = false;
    for (let c = 0; c < head; c++) {
      const p = comp[c];
      const x = p % W;
      const y = (p / W) | 0;
      if (filled[p] < peak) peak = filled[p];
      if (depression[p] > deepest) deepest = depression[p];
      for (let d = 0; d < 4; d++) {
        const nx = x + N4X[d];
        const ny = y + N4Y[d];
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const j = ny * W + nx;
        if (ocean[j]) { touchesSea = true; continue; }
        if (!visited[j] && depression[j] >= 0.012) {
          visited[j] = 1;
          if (head < N) comp[head++] = j;
        }
      }
    }
    if (touchesSea || head < 24 || deepest < 0.018) continue;
    lakeCount++;
    const level = peak + 0.0015;
    for (let c = 0; c < head; c++) {
      const p = comp[c];
      lake[p] = 1;
      lakeLevel[p] = level;
    }
  }

  // ---------- 7. 统一水面：海 / 湖 / 河 ----------
  const surface = new Float32Array(N);
  const waterMask = new Uint8Array(N);
  for (let i = 0; i < N; i++) {
    if (ocean[i]) { surface[i] = seaLevel; waterMask[i] = 1; }
    else if (lake[i]) { surface[i] = lakeLevel[i]; waterMask[i] = 2; }
    else if (river[i] > 0) { surface[i] = riverLevel[i]; waterMask[i] = 3; }
  }

  return {
    filled, depression, dir, flow, maxFlow,
    ocean, lake, lakeLevel, lakeCount,
    river, riverWidth, riverLevel, riverCells,
    surface, waterMask, seaLevel,
    stats: {
      seaCells: ocean.reduce((a, v) => a + v, 0),
      riverCells,
      riverKm: Math.round((riverCells / Math.max(1, W)) * 2.0) / 10,
      lakeCount,
      maxFlow: Math.round(maxFlow),
    },
  };
}

/** 河网可视化：把 flow 转成 0..1 的灰度，便于调试/导出 */
export function flowToImageData(hydro) {
  const { flow, maxFlow } = hydro;
  const W = hydro.width || Math.round(Math.sqrt(flow.length));
  const H = flow.length / W;
  const img = new ImageData(W, H);
  for (let i = 0; i < flow.length; i++) {
    const t = saturate(Math.log(flow[i] + 1) / Math.log(maxFlow + 1));
    img.data[i * 4] = Math.round(t * 90);
    img.data[i * 4 + 1] = Math.round(t * 160);
    img.data[i * 4 + 2] = Math.round(t * 220);
    img.data[i * 4 + 3] = 255;
  }
  return img;
}
