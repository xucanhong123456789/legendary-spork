// ============================================================
// biome.js - 生态分层与植被散布
// 按 海拔 / 坡度 / 湿度 / 离水距离 / 坡向 划分生态带：
// 雪线以上为积雪与裸岩，林线以下针阔混交，密林成片树冠，
// 河岸有灌木带，高山有苔原草甸，海岸有沙滩与湿地。
// 输出地表反照率贴图 + GPU 实例化所需的植被点数据。
// ============================================================
import { clamp, saturate, smoothstep, lerp, mulberry32, fbm2, valueNoise2 } from '../geo/noise.js';

export const BAND = {
  WATER: 0, BEACH: 1, WETLAND: 2, GRASS: 3, FOREST: 4,
  BOREAL: 5, TUNDRA: 6, ALPINE: 7, ROCK: 8, SNOW: 9,
};
export const BAND_NAMES = ['水域', '沙滩', '湿地', '草原', '阔叶林', '针叶林', '苔原', '高山草甸', '裸岩', '雪原'];

/** 地表反照率（中土手稿调色） */
const C = {
  snow:   [246, 249, 251],
  rock:   [140, 138, 132],
  scree:  [152, 146, 136],
  alpine: [152, 156, 112],
  tundra: [128, 138, 106],
  grass:  [140, 154, 100],
  dry:    [172, 162, 110],
  forest: [ 82, 108,  70],
  jungle: [ 62,  96,  62],
  wet:    [ 96, 118,  88],
  sand:   [216, 202, 162],
  mud:    [132, 124,  96],
};

export const BIOME_PRESETS = {
  temperate: { name: '温带大陆', snowLine: 0.86, treeLine: 0.70, forest: 1.00, jungle: 0.05, rock: 1.0, palm: 0 },
  alpine:    { name: '高山雪原', snowLine: 0.68, treeLine: 0.54, forest: 0.80, jungle: 0.00, rock: 1.3, palm: 0 },
  tropical:  { name: '热带海岛', snowLine: 0.99, treeLine: 0.92, forest: 1.35, jungle: 0.95, rock: 0.7, palm: 1 },
  karst:     { name: '岩溶高原', snowLine: 0.90, treeLine: 0.66, forest: 0.45, jungle: 0.00, rock: 1.7, palm: 0 },
};

/** 线性混合三种颜色 */
function mix(a, b, t) {
  return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
}

/**
 * @param {object} fields read2DMap 输出（含 height/moisture/slope/dist/water/cls）
 * @param {object} hydro analyzeHydrology 输出
 * @param {object} opt { preset, snowLine, veg, seed, maxTrees }
 */
export function buildBiomes(fields, hydro, opt = {}) {
  const { W, H, height, moisture, slope, dist } = prepare(fields);
  const N = W * H;
  const preset = BIOME_PRESETS[opt.preset] || BIOME_PRESETS.temperate;
  const sea = fields.meta.seaLevel;
  const snowLine = typeof opt.snowLine === 'number' ? opt.snowLine : preset.snowLine;
  const treeLine = typeof opt.treeLine === 'number' ? opt.treeLine : preset.treeLine;
  const veg = clamp(opt.veg ?? 1, 0, 2);
  const seed = (opt.seed | 0) || 1337;
  const rnd = mulberry32(seed * 7 + 11);

  const albedo = new Uint8Array(N * 3);
  const albedoNoSnow = new Uint8Array(N * 3);
  const band = new Uint8Array(N);
  const forestDensity = new Float32Array(N);
  const shrubDensity = new Float32Array(N);
  const rockDensity = new Float32Array(N);

  // ---- 生态带 + 地表颜色 ----
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const h = height[i];
      const m = moisture[i];
      const s = slope[i];
      const d = dist[i];

      // 低频噪声让生态边界交错，不出现整齐等高线
      const u = x / W;
      const v = y / H;
      const jitter = (fbm2(u * 6.2 + 3.1, v * 6.2 + 9.4, 4) - 0.5) * 0.075;
      const hj = h + jitter;
      const forestPatch = smoothstep(0.34, 0.63, fbm2(u * 9.5 + 21.7, v * 9.5 + 4.3, 4) + m * 0.18);

      let col = C.grass;
      let noSnowCol = C.mud;
      let bd = BAND.GRASS;

      if (hydro.ocean[i] || hydro.lake[i] || h < sea - 0.012) {
        bd = BAND.WATER;
        col = C.mud;
      } else {
        // 沙滩带
        const beachW = 1 - smoothstep(sea - 0.008, sea + 0.030, h);
        // 湿地：低平 + 近水 + 高湿
        const wetW = (1 - smoothstep(sea + 0.005, sea + 0.075, h)) * smoothstep(0.55, 0.85, m) * (1 - s * 0.6);
        // 植被：林线以下、坡度可承载、水分足够
        const altitudeOK = 1 - smoothstep(treeLine - 0.10, treeLine + 0.05, hj);
        const treeW = altitudeOK * (1 - smoothstep(0.30, 0.62, s)) * smoothstep(0.24, 0.55, m) * forestPatch;
        // 针叶林比例随海拔升高
        const borealW = smoothstep(treeLine - 0.26, treeLine - 0.02, hj);
        // 苔原 / 高山草甸
        const tundraW = smoothstep(treeLine - 0.05, treeLine + 0.09, hj) * (1 - smoothstep(snowLine - 0.12, snowLine, hj));
        const alpineW = smoothstep(snowLine - 0.20, snowLine - 0.04, hj) * (1 - smoothstep(snowLine - 0.02, snowLine + 0.06, hj));
        // 裸岩：陡坡 + 高海拔
        const rockW = saturate(smoothstep(0.38, 0.72, s) * 0.95 + smoothstep(snowLine - 0.16, snowLine + 0.02, hj) * 0.55) * preset.rock;
        // 积雪：雪线以上（阳坡略高、阴坡略低）
        const aspect = (height[Math.max(0, i - 1)] - height[Math.min(N - 1, i + 1)]) * 8;
        const snowW = smoothstep(snowLine - 0.085, snowLine + 0.020, hj + aspect * 0.012) * (1 - saturate(s * 0.75));

        // 由低到高逐层覆盖（顺序即优先级）
        col = mix(C.dry, C.grass, saturate(m * 1.4));
        bd = BAND.GRASS;
        if (wetW > 0.25) { col = mix(col, C.wet, wetW); bd = BAND.WETLAND; }
        if (beachW > 0.30) { col = mix(col, C.sand, beachW); bd = BAND.BEACH; }
        if (treeW > 0.12) {
          const fcol = mix(C.forest, C.jungle, preset.jungle * saturate(m));
          col = mix(col, fcol, treeW * 0.85);
          bd = borealW > 0.52 ? BAND.BOREAL : BAND.FOREST;
        }
        if (tundraW > 0.15) { col = mix(col, C.tundra, tundraW); bd = BAND.TUNDRA; }
        if (alpineW > 0.15) { col = mix(col, C.alpine, alpineW); bd = BAND.ALPINE; }
        if (rockW > 0.20) { col = mix(col, C.rock, saturate(rockW)); bd = BAND.ROCK; }
        noSnowCol = [col[0], col[1], col[2]];
        if (snowW > 0.08) { col = mix(col, C.snow, saturate(snowW * 1.5)); bd = BAND.SNOW; }

        forestDensity[i] = treeW * (1 - snowW) * veg * preset.forest;
        shrubDensity[i] = saturate((1 - treeW) * m * (1 - s) * (1 - smoothstep(treeLine, treeLine + 0.12, hj))) * veg;
        rockDensity[i] = saturate(rockW * (1 - snowW) * 0.8);
      }

      // 河槽：细窄河道染成深水色，配合 V 型下切形成可见河流
      const rv = Math.max(hydro.river[i], hydro.riverSoft ? hydro.riverSoft[i] * 2.4 : 0);
      if (rv > 0.10 && !hydro.ocean[i] && !hydro.lake[i]) {
        col = mix(col, [46, 96, 124], saturate(rv * 1.15));
      }

      // 细微色斑，避免大片纯色
      const grain = (valueNoise2(u * 90 + 3, v * 90 + 7) - 0.5) * 14;
      const o = i * 3;
      albedo[o] = clamp(col[0] + grain, 0, 255);
      albedo[o + 1] = clamp(col[1] + grain * 0.8, 0, 255);
      albedo[o + 2] = clamp(col[2] + grain * 0.6, 0, 255);
      albedoNoSnow[o] = clamp(noSnowCol[0] + grain, 0, 255);
      albedoNoSnow[o + 1] = clamp(noSnowCol[1] + grain * 0.8, 0, 255);
      albedoNoSnow[o + 2] = clamp(noSnowCol[2] + grain * 0.6, 0, 255);
      band[i] = bd;
    }
  }

  // ---- 植被实例化采样 ----
  const maxTrees = opt.maxTrees || 22000;
  const step = Math.max(3, Math.round(Math.min(W, H) / (58 * Math.sqrt(Math.max(0.25, veg)))));
  const pos = [];
  const scl = [];
  const colArr = [];
  const typ = [];
  const bushPos = [];
  const bushScl = [];
  const bushCol = [];
  const rockPos = [];
  const rockScl = [];

  for (let y = 2; y < H - 2; y += step) {
    for (let x = 2; x < W - 2; x += step) {
      const px = x + (rnd() - 0.5) * step * 0.95;
      const py = y + (rnd() - 0.5) * step * 0.95;
      const xi = clamp(Math.round(px), 0, W - 1);
      const yi = clamp(Math.round(py), 0, H - 1);
      const i = yi * W + xi;
      if (hydro.ocean[i] || hydro.lake[i] || hydro.river[i] > 0.4) continue;
      const h = height[i];
      if (h < sea + 0.008) continue;

      const fd = forestDensity[i];
      if (pos.length / 3 < maxTrees && rnd() < fd * 0.62) {
        const type = pickTreeType(preset, h, snowLine, treeLine, moisture[i], rnd);
        const size = 0.72 + rnd() * 0.75;
        pos.push(px, py, h);
        scl.push(size, size * (0.85 + rnd() * 0.35), size);
        const c = treeColor(type, rnd);
        colArr.push(c[0], c[1], c[2]);
        typ.push(type);
      } else if (rnd() < shrubDensity[i] * 0.42 && bushPos.length / 3 < maxTrees) {
        bushPos.push(px, py, h);
        const s = 0.35 + rnd() * 0.5;
        bushScl.push(s, s * 0.7, s);
        const c = mix([96, 118, 72], [128, 132, 84], rnd());
        bushCol.push(c[0] / 255, c[1] / 255, c[2] / 255);
      } else if (rnd() < rockDensity[i] * 0.16 && rockPos.length / 3 < 4000) {
        rockPos.push(px, py, h);
        rockScl.push(0.4 + rnd() * 0.9);
      }
    }
  }

  return {
    W, H, albedo, albedoNoSnow, band, forestDensity, shrubDensity, rockDensity,
    trees: {
      count: pos.length / 3,
      pos: new Float32Array(pos),
      scale: new Float32Array(scl),
      color: new Float32Array(colArr),
      type: new Uint8Array(typ),
    },
    bushes: {
      count: bushPos.length / 3,
      pos: new Float32Array(bushPos),
      scale: new Float32Array(bushScl),
      color: new Float32Array(bushCol),
    },
    rocks: {
      count: rockPos.length / 3,
      pos: new Float32Array(rockPos),
      scale: new Float32Array(rockScl),
    },
    preset: preset.name,
    snowLine,
    stats: {
      trees: pos.length / 3,
      bushes: bushPos.length / 3,
      rocks: rockPos.length / 3,
      bands: histogram(band),
    },
  };
}

function prepare(fields) {
  return {
    W: fields.meta.w,
    H: fields.meta.h,
    height: fields.height,
    moisture: fields.moisture,
    slope: fields.slope,
    dist: fields.dist,
  };
}

function pickTreeType(preset, h, snowLine, treeLine, moisture, rnd) {
  // 0 针叶（尖锥） 1 阔叶（圆冠） 2 雨林（宽冠） 3 棕榈
  if (preset.palm > 0 && h < 0.30 && rnd() < 0.38 + preset.palm * 0.25) return 3;
  if (preset.jungle > 0.5 && moisture > 0.55 && rnd() < preset.jungle * 0.7) return 2;
  const t = smoothstep(treeLine - 0.28, treeLine - 0.03, h);
  return rnd() < t ? 0 : 1;
}

function treeColor(type, rnd) {
  const base = type === 0 ? [0.20, 0.30, 0.21]
    : type === 1 ? [0.28, 0.38, 0.20]
      : type === 2 ? [0.19, 0.34, 0.19]
        : [0.26, 0.40, 0.22];
  const k = 0.80 + rnd() * 0.42;
  return [base[0] * k, base[1] * k, base[2] * k];
}

function histogram(band) {
  const out = new Array(BAND_NAMES.length).fill(0);
  for (let i = 0; i < band.length; i++) out[band[i]]++;
  return out;
}
