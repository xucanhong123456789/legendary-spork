// ============================================================
// leafTexture.js - 程序化叶片 / 针叶 / 棕榈叶 贴图（canvas 生成，无外部素材）
// 用于「十字交叉叶片片」的 alpha 镂空，使叶冠读作真实叶片轮廓而非圆球。
// 在浏览器上下文生成（依赖 document）；桌面壳可改用 OffscreenCanvas。
// ============================================================
import * as THREE from 'three';
import { mulberry32 } from '../geo/noise.js';

function ctx2d(size) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  return { c, ctx: c.getContext('2d') };
}

/** 画一片叶子（尖头椭圆 + 主脉） */
function drawLeaf(ctx, x, y, len, wid, ang, hue, light) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(ang);
  const g = ctx.createLinearGradient(0, -len / 2, 0, len / 2);
  g.addColorStop(0, `hsl(${hue}, 42%, ${light + 14}%)`);
  g.addColorStop(1, `hsl(${hue}, 46%, ${light - 6}%)`);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(0, -len / 2);
  ctx.quadraticCurveTo(wid, -len * 0.1, 0, len / 2);
  ctx.quadraticCurveTo(-wid, -len * 0.1, 0, -len / 2);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = `hsla(${hue - 12}, 50%, ${light - 28}%, 0.55)`;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, -len / 2);
  ctx.lineTo(0, len / 2);
  ctx.stroke();
  // 侧脉
  ctx.lineWidth = 0.6;
  for (let s = -1; s <= 1; s += 2) {
    for (let t = -0.3; t <= 0.3; t += 0.3) {
      const yy = t * len;
      ctx.beginPath();
      ctx.moveTo(0, yy);
      ctx.lineTo(s * wid * 0.7, yy + len * 0.12);
      ctx.stroke();
    }
  }
  ctx.restore();
}

/** 阔叶 / 雨林：一簇小叶片（叶片贴图） */
export function makeLeafTexture() {
  const size = 256;
  const { c, ctx } = ctx2d(size);
  ctx.clearRect(0, 0, size, size);
  const rng = mulberry32(20251109);
  const n = 86;
  for (let i = 0; i < n; i++) {
    const x = size * 0.5 + (rng() - 0.5) * size * 0.74;
    const y = size * 0.5 + (rng() - 0.5) * size * 0.74;
    const len = 16 + rng() * 40;
    const wid = 6 + rng() * 13;
    const ang = rng() * Math.PI * 2;
    const hue = 92 + rng() * 34;            // 绿
    const light = 34 + rng() * 16;
    drawLeaf(ctx, x, y, len, wid, ang, hue, light);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/** 针叶：竖直针状纹理（细密绿色条纹 + 透明） */
export function makeNeedleTexture() {
  const size = 256;
  const { c, ctx } = ctx2d(size);
  ctx.clearRect(0, 0, size, size);
  const rng = mulberry32(770077);
  // 底色淡绿雾，便于密集成束
  for (let i = 0; i < 240; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const len = 40 + rng() * 150;
    const ang = (rng() - 0.5) * 0.28; // 接近竖直
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ang);
    const hue = 110 + rng() * 30;
    const light = 26 + rng() * 16;
    ctx.strokeStyle = `hsla(${hue}, 45%, ${light}%, 0.9)`;
    ctx.lineWidth = 1.4 + rng() * 1.2;
    ctx.beginPath();
    ctx.moveTo(0, -len / 2);
    ctx.lineTo(0, len / 2);
    ctx.stroke();
    ctx.restore();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/** 棕榈叶：长羽状（中央叶轴 + 两侧小羽片 + 透明锯齿边） */
export function makeFrondTexture() {
  const W = 128, H = 256;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, W, H);
  const rng = mulberry32(314159);
  // 中央叶轴
  ctx.strokeStyle = 'hsl(95, 40%, 30%)';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(W / 2, H);
  ctx.lineTo(W / 2, 4);
  ctx.stroke();
  // 两侧小羽片
  const n = 22;
  for (let i = 1; i < n; i++) {
    const y = H - (i / n) * (H - 8);
    const reach = (1 - i / n) * (W * 0.46) + 8;
    const hue = 96 + rng() * 22;
    const light = 30 + rng() * 14;
    for (let s = -1; s <= 1; s += 2) {
      ctx.strokeStyle = `hsl(${hue}, 44%, ${light}%)`;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(W / 2, y);
      ctx.lineTo(W / 2 + s * reach, y - reach * 0.5);
      ctx.stroke();
      // 次级羽片
      ctx.lineWidth = 1;
      ctx.strokeStyle = `hsla(${hue - 8}, 46%, ${light - 10}%, 0.8)`;
      for (let k = 1; k <= 3; k++) {
        const fx = W / 2 + s * (reach * k / 3);
        ctx.beginPath();
        ctx.moveTo(fx, y - reach * 0.12 * k);
        ctx.lineTo(fx + s * 5, y - reach * 0.12 * k - 6);
        ctx.stroke();
      }
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}
