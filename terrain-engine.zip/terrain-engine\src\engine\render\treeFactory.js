// ============================================================
// treeFactory.js - 程序化树木几何体（无 DOM 依赖，可被渲染层/桌面壳复用）
// 每棵树拆成「木本」(树干+递归枝, 棕色) 与「叶冠」(叶团/针叶/棕榈叶, 待 instanceColor 染绿)
// 两套几何体，保证树干永远读作棕色、不被叶色污染；叶冠用偏移小多面体拼成，
// 避免完美球形轮廓，远处看也有枝干结构。
// ============================================================
import * as THREE from 'three';
import { mulberry32 } from '../geo/noise.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

const UP = new THREE.Vector3(0, 1, 0);
export const TRUNK_COLOR = [0.34, 0.25, 0.17];   // 木本（树干/枝）底色
export const LEAF_COLOR = [1, 1, 1];             // 叶冠底色（由 instanceColor 染成绿）

/** 给几何体加顶点色（instanceColor 再乘上去） */
function tint(geo, color) {
  const g = geo.index ? geo.toNonIndexed() : geo;
  const n = g.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    arr[i * 3] = color[0];
    arr[i * 3 + 1] = color[1];
    arr[i * 3 + 2] = color[2];
  }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}

/** 一段锥形枝干，基点在 start、沿 dir 延伸 len */
function branchSegment(start, dir, len, r0, r1, radial) {
  const g = new THREE.CylinderGeometry(r1, r0, len, radial, 1);
  g.translate(0, len / 2, 0);
  g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(UP, dir));
  g.translate(start.x, start.y, start.z);
  return g;
}

/** 一簇交叉叶片片（2~3 张互相垂直的平面），贴叶片贴图后读作真实叶丛而非圆球 */
function addLeafCluster(parts, center, rng, size, planes = 3) {
  for (let i = 0; i < planes; i++) {
    const g = new THREE.PlaneGeometry(size, size);
    g.rotateY((i / planes) * Math.PI);
    g.translate(center.x, center.y, center.z);
    parts.push(tint(g, LEAF_COLOR));
  }
}

/** 递归分枝：depth 递减，沿途与末端挂交叉叶片片 —— 枝干裸露、叶冠成丛不圆 */
function growBranches(woody, foliage, rng, start, dir, len, r0, r1, radial, depth, spread) {
  woody.push(tint(branchSegment(start, dir, len, r0, r1, radial), TRUNK_COLOR));
  const end = start.clone().addScaledVector(dir, len);
  // 沿途也挂少量叶丛让冠层饱满（细枝段裸露仍可辨）
  if (depth <= 1) addLeafCluster(foliage, end, rng, len * 0.85, 3);
  if (depth <= 0) {
    addLeafCluster(foliage, end, rng, len * 1.15, 3);
    return;
  }
  const n = depth >= 2 ? 2 + Math.floor(rng() * 2) : 3;
  for (let i = 0; i < n; i++) {
    const axis = new THREE.Vector3(rng() - 0.5, rng() - 0.5, rng() - 0.5).normalize();
    const ang = spread * (0.5 + rng() * 0.7);
    const nd = dir.clone().applyAxisAngle(axis, ang);
    nd.y = Math.abs(nd.y) * 0.5 + nd.y * 0.4 + 0.18;   // 整体向上偏
    nd.normalize();
    const nl = len * (0.66 + rng() * 0.16);
    growBranches(woody, foliage, rng, end, nd, nl, r1, r1 * 0.6, radial, depth - 1, spread);
  }
}

/** 阔叶 / 雨林：高裸干 + 几根外伸主枝 + 枝端叶簇（枝干裸露可读） */
function buildBroadleaf(woody, foliage, rng, type) {
  const trunkH = type === 2 ? 2.35 : 2.05;
  const trunkR = type === 2 ? 0.16 : 0.13;
  woody.push(tint(branchSegment(new THREE.Vector3(0, 0, 0), UP, trunkH, trunkR, trunkR * 0.7, 6), TRUNK_COLOR));
  const base = new THREE.Vector3(0, trunkH * 0.72, 0); // 主枝从树干上部发出，下部裸干可见
  const nMain = type === 2 ? 5 : 4;
  for (let i = 0; i < nMain; i++) {
    const a = (i / nMain) * Math.PI * 2 + rng() * 0.5;
    const dir = new THREE.Vector3(Math.cos(a), 0.42 + rng() * 0.28, Math.sin(a)).normalize();
    const len = (type === 2 ? 1.75 : 1.5) * (0.85 + rng() * 0.3);
    growBranches(woody, foliage, rng, base, dir, len, trunkR * 0.5, trunkR * 0.34, 5, 2, 0.85);
  }
}

/** 针叶（冷杉）：主干 + 多层轮生枝 + 枝端针叶簇，中央细 spindle 防空洞 */
function buildConifer(woody, foliage, rng) {
  const totalH = 4.0;
  const trunkR = 0.12;
  woody.push(tint(branchSegment(new THREE.Vector3(0, 0, 0), UP, totalH * 0.44, trunkR * 0.5, trunkR, 6), TRUNK_COLOR));
  // 中央细纺锤（绿，作为树体核心，避免层间透空）
  const core = new THREE.ConeGeometry(0.26, totalH * 0.92, 6);
  core.translate(0, totalH * 0.5, 0);
  foliage.push(tint(core, LEAF_COLOR));
  const tiers = 6;
  for (let k = 0; k < tiers; k++) {
    const f = k / (tiers - 1);
    const ty = totalH * 0.34 + f * totalH * 0.6;
    const tierR = (1 - f) * 1.35 + 0.45;
    const nB = 5 + Math.floor(rng() * 3);
    for (let i = 0; i < nB; i++) {
      const a = (i / nB) * Math.PI * 2 + rng() * 0.4 + k * 0.5;
      const dir = new THREE.Vector3(Math.cos(a), 0.12 + rng() * 0.12, Math.sin(a)).normalize();
      const blen = tierR * (0.86 + rng() * 0.22);
      woody.push(tint(branchSegment(new THREE.Vector3(0, ty, 0), dir, blen, 0.055, 0.028, 4), TRUNK_COLOR));
      const end = new THREE.Vector3(0, ty, 0).addScaledVector(dir, blen);
      addNeedleSpray(foliage, end, dir, rng, 0.4 + tierR * 0.12);
    }
  }
  addNeedleSpray(foliage, new THREE.Vector3(0, totalH * 0.95, 0), UP, rng, 0.42);
}

/** 针叶簇：枝端一束交叉针叶片（贴针叶贴图，竖直条纹读作松针，而非圆球） */
function addNeedleSpray(parts, center, dir, rng, r) {
  const q = new THREE.Quaternion().setFromUnitVectors(
    UP, dir.clone().lerp(UP, 0.55).normalize()
  );
  for (let i = 0; i < 2; i++) {
    const g = new THREE.PlaneGeometry(r * 0.95, r * 1.7);
    g.rotateY((i / 2) * Math.PI);
    g.applyQuaternion(q);
    g.translate(center.x, center.y, center.z);
    parts.push(tint(g, LEAF_COLOR));
  }
}

/** 棕榈：分段微曲树干 + 放射下垂的长叶（扁锥叶），去掉圆球冠 */
function buildPalm(woody, foliage, rng) {
  const totalH = 4.7;
  const segs = 6;
  const r0 = 0.16;
  let prev = new THREE.Vector3(0, 0, 0);
  let dir = new THREE.Vector3(0.02, 1, 0).normalize();
  for (let i = 0; i < segs; i++) {
    const len = totalH / segs;
    woody.push(tint(branchSegment(prev, dir, len, r0 * (1 - i / segs * 0.5), r0 * (1 - (i + 1) / segs * 0.5), 6), TRUNK_COLOR));
    prev = prev.clone().addScaledVector(dir, len);
    dir = new THREE.Vector3(0.04 * (i - 2), 1, 0.03 * Math.sin(i)).normalize();
  }
  const top = prev;
  const nF = 9 + Math.floor(rng() * 3);
  for (let i = 0; i < nF; i++) {
    const a = (i / nF) * Math.PI * 2 + rng() * 0.3;
    // 放射外伸并带下垂：先抬高再压低，模拟成熟棕榈叶下垂
    const up = 0.30 + rng() * 0.18;
    const droop = 0.55 + rng() * 0.35;
    const dir2 = new THREE.Vector3(Math.cos(a) * droop, up - droop * 0.5, Math.sin(a) * droop).normalize();
    const flen = 2.1 + rng() * 0.8;
    // 扁长叶片：平面沿 dir2 外伸（贴棕榈叶贴图，羽状轮廓）
    const blade = new THREE.PlaneGeometry(0.62, flen);
    const q = new THREE.Quaternion().setFromUnitVectors(UP, dir2);
    blade.applyQuaternion(q);
    blade.translate(top.x + dir2.x * flen * 0.5, top.y + dir2.y * flen * 0.5, top.z + dir2.z * flen * 0.5);
    foliage.push(tint(blade, LEAF_COLOR));
  }
  // 顶部几片短而上扬的嫩叶
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + 0.4;
    const dir2 = new THREE.Vector3(Math.cos(a), 0.7, Math.sin(a)).normalize();
    const blade = new THREE.PlaneGeometry(0.42, 1.2);
    const q = new THREE.Quaternion().setFromUnitVectors(UP, dir2);
    blade.applyQuaternion(q);
    blade.translate(top.x + dir2.x * 0.6, top.y + dir2.y * 0.6, top.z + dir2.z * 0.6);
    foliage.push(tint(blade, LEAF_COLOR));
  }
}

/**
 * 生成一棵树（4 种类型）：
 *   0 针叶（冷杉，轮生枝+针叶簇）  1 阔叶（高裸干+外伸主枝+枝端叶簇）
 *   2 雨林（更宽冠）               3 棕榈（曲干+放射下垂长叶）
 * @returns {{ woody: THREE.BufferGeometry, foliage: THREE.BufferGeometry }}
 */
export function treeGeometry(type) {
  const rng = mulberry32(1000 + type * 97 + 7);
  const woody = [];
  const foliage = [];
  if (type === 0) buildConifer(woody, foliage, rng);
  else if (type === 3) buildPalm(woody, foliage, rng);
  else buildBroadleaf(woody, foliage, rng, type);
  const wGeo = mergeGeometries(woody, false);
  const fGeo = mergeGeometries(foliage, false);
  wGeo.computeVertexNormals();
  fGeo.computeVertexNormals();
  return { woody: wGeo, foliage: fGeo };
}
