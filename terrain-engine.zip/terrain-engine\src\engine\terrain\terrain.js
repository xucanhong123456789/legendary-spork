// ============================================================
// terrain.js - 重建管线编排
// 2D 图 -> 识读 -> 水文 -> 侵蚀雕刻 -> 水面重算 -> 生态分层 -> TerrainResult
// 这是引擎对外的主函数；不依赖 DOM / three，可直接放进 Web Worker。
// ============================================================
import { read2DMap, slopeField, distanceField, boxBlur, DATUM } from './readMap.js';
import { analyzeHydrology } from './hydrology.js';
import { sculptTerrain } from './erosion.js';
import { buildBiomes } from './biome.js';
import { saturate, clamp } from '../geo/noise.js';

export const DEFAULT_OPTIONS = {
  mode: 'semantic',
  relief: 1.0,
  detail: 1.0,
  erosion: 0.75,
  riverCut: 0.8,
  veg: 1.0,
  preset: 'temperate',
  snowLine: null,
  seed: 1337,
  seaLevel: DATUM.sea,
  maxTrees: 22000,
};

/**
 * @param {object} source { rgba: Uint8ClampedArray, w, h } 或 { fields } 已识读的场
 * @param {object} options 见 DEFAULT_OPTIONS
 * @param {function} onProgress (stage:string, ratio:number) => void
 */
export function buildTerrain(source, options = {}, onProgress = null) {
  const t0 = (typeof performance !== 'undefined' ? performance.now() : Date.now());
  const opt = { ...DEFAULT_OPTIONS, ...options };
  const report = (stage, r) => { if (onProgress) onProgress(stage, r); };

  report('识读 2D 地图', 0.06);
  const readOpt = { ...opt, ...(source.readOpt || {}) };
  const fields = source.fields
    ? source.fields
    : read2DMap(source.rgba, source.w, source.h, opt.mode, readOpt);
  const W = fields.meta.w;
  const H = fields.meta.h;
  const seaLevel = opt.seaLevel ?? DATUM.sea;

  report('分析水文：填洼 / D8 流向 / 汇流累积', 0.22);
  const hydro0 = analyzeHydrology(fields.height, W, H, {
    seaLevel, water: fields.water,
    riverThreshold: opt.riverThreshold,
  });

  report('水力侵蚀：雨滴雕刻沟壑与冲积扇', 0.42);
  const dem = Float32Array.from(fields.height);
  sculptTerrain(dem, hydro0, {
    W, H,
    erosion: opt.erosion,
    riverCut: opt.riverCut,
    seed: opt.seed,
    seaLevel,
    water: fields.water,
  });

  report('重算水面：海洋 / 湖泊 / 河网', 0.66);
  const hydro = analyzeHydrology(dem, W, H, {
    seaLevel, water: fields.water,
    riverThreshold: opt.riverThreshold,
  });
  // 河网光晕：让细窄河道在地表色上形成连续的河谷带
  hydro.riverSoft = boxBlur(hydro.river, W, H, 1, 1);

  // 地形变了，坡度与湿度也要跟着更新
  fields.height = dem;
  fields.slope = slopeField(dem, W, H);
  const wetMask = new Float32Array(W * H);
  for (let i = 0; i < hydro.waterMask.length; i++) wetMask[i] = hydro.waterMask[i] ? 1 : 0;
  fields.dist = distanceField(wetMask, W, H);
  let dMax = 1;
  for (let i = 0; i < fields.dist.length; i++) {
    if (fields.dist[i] < 1e8 && fields.dist[i] > dMax) dMax = fields.dist[i];
  }
  for (let i = 0; i < fields.dist.length; i++) {
    if (fields.dist[i] >= 1e8) fields.dist[i] = dMax;
    fields.moisture[i] = saturate(fields.moisture[i] * 0.72 + Math.exp(-fields.dist[i] / (W * 0.13 + 1)) * 0.28);
  }

  report('划分生态带并散布植被', 0.82);
  const biomes = buildBiomes(fields, hydro, {
    preset: opt.preset,
    snowLine: opt.snowLine,
    treeLine: opt.treeLine,
    veg: opt.veg,
    seed: opt.seed,
    maxTrees: opt.maxTrees,
  });

  let peak = 0;
  let low = 1;
  let land = 0;
  for (let i = 0; i < dem.length; i++) {
    if (dem[i] > peak) peak = dem[i];
    if (dem[i] < low) low = dem[i];
    if (dem[i] >= seaLevel) land++;
  }

  const elapsed = (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0;
  report('完成', 1);

  return {
    W, H, dem, fields, hydro, biomes,
    options: opt,
    stats: {
      elapsed: Math.round(elapsed),
      seaLevel,
      peak,
      lowest: low,
      landRatio: land / dem.length,
      seaCells: hydro.stats.seaCells,
      riverCells: hydro.stats.riverCells,
      riverKm: hydro.stats.riverKm,
      lakes: hydro.stats.lakeCount,
      maxFlow: hydro.stats.maxFlow,
      trees: biomes.stats.trees,
      bushes: biomes.stats.bushes,
      rocks: biomes.stats.rocks,
    },
  };
}

/** 双线性采样世界高程（0..1 归一化坐标） */
export function heightAt(result, u, v) {
  const { W, H, dem } = result;
  const fx = clamp(u, 0, 1) * (W - 1);
  const fy = clamp(v, 0, 1) * (H - 1);
  const x0 = Math.floor(fx);
  const y0 = Math.floor(fy);
  const x1 = Math.min(W - 1, x0 + 1);
  const y1 = Math.min(H - 1, y0 + 1);
  const tx = fx - x0;
  const ty = fy - y0;
  const a = dem[y0 * W + x0];
  const b = dem[y0 * W + x1];
  const c = dem[y1 * W + x0];
  const d = dem[y1 * W + x1];
  return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
}

/** 导出给下游的网格分辨率建议（按机器性能取 256 / 384 / 512） */
export function recommendMeshSegments(W, H, quality = 'high') {
  const cap = quality === 'low' ? 192 : quality === 'medium' ? 288 : 384;
  return Math.min(cap, Math.max(96, Math.round(Math.min(W, H))));
}
