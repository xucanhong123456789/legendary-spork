import { sampleField, SAMPLE_PALETTE } from '../src/demo/terrainSamples.js';
import { buildTerrain } from '../src/engine/terrain/terrain.js';

const W = Number(process.argv[2] || 256), H = W;
const kind = process.argv[3] || 'continent';
const mode = process.argv[4] || 'semantic';

const rgba = new Uint8ClampedArray(W * H * 4);
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  const f = sampleField(kind, x / (W - 1), y / (H - 1));
  const c = SAMPLE_PALETTE[f.cls] || SAMPLE_PALETTE.plain;
  const o = (y * W + x) * 4;
  rgba[o] = c[0]; rgba[o + 1] = c[1]; rgba[o + 2] = c[2]; rgba[o + 3] = 255;
}

const stages = [];
const r = buildTerrain({ rgba, w: W, h: H }, {
  mode, seed: 1337, erosion: 0.75, riverCut: 0.8, veg: 1, preset: 'temperate',
}, (s, p) => stages.push(s + ' ' + Math.round(p * 100) + '%'));

console.log('stages:', stages.join(' | '));
console.log('stats:', JSON.stringify(r.stats));
console.log('trees:', r.biomes.trees.count, 'bushes:', r.biomes.bushes.count, 'rocks:', r.biomes.rocks.count);
console.log('bands:', r.biomes.stats.bands.join(','));

// ASCII 概览：地形 + 水
const N = 32;
for (let y = 0; y < N; y++) {
  let line = '';
  for (let x = 0; x < N * 2; x++) {
    const i = Math.round(y / (N - 1) * (H - 1)) * W + Math.round(x / (N * 2 - 1) * (W - 1));
    const wm = r.hydro.waterMask[i];
    const h = r.dem[i];
    line += wm === 1 ? '~' : wm === 2 ? 'o' : wm === 3 ? '=' : h < 0.23 ? '.' : h < 0.35 ? ':' : h < 0.5 ? '+' : h < 0.68 ? '#' : h < 0.84 ? 'A' : '^';
  }
  console.log(line);
}

let bad = 0;
for (let i = 0; i < r.dem.length; i++) if (!Number.isFinite(r.dem[i]) || r.dem[i] < 0 || r.dem[i] > 1) bad++;
if (bad) throw new Error('NaN/out-of-range dem cells: ' + bad);
if (r.stats.trees < 10) throw new Error('no trees generated');
if (r.stats.riverCells < 5) throw new Error('no river generated');
console.log('PIPELINE PASS');
