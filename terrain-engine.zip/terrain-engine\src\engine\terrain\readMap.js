// ============================================================
// readMap.js - 2D 地图识读层（纯数据，不依赖 three / DOM）
// semantic 语义色块 / height 灰度高度图 / hybrid 双通道 / painted 手绘聚类
// 输出 { height, water, moisture, cls, dist, slope, meta }
// ============================================================
import { clamp, saturate, lerp, smoothstep, fbm2, valueNoise2, mulberry32 } from '../geo/noise.js';

export const DATUM = { sea: 0.18, beach: 0.205, snow: 0.86, treeLine: 0.70, rockSlope: 0.55 };
export const SEA = DATUM.sea;

/** 语义色板：RGB 与 demo/terrainSamples.js 的样例配色严格一致 */
export const SEMANTIC_PALETTE = [
  { cls: 'deepSea',    color: [ 20,  46,  78], h: 0.050, w: 1.00, wet: 1 },
  { cls: 'ocean',      color: [ 40,  84, 116], h: 0.140, w: 1.00, wet: 1 },
  { cls: 'shallows',   color: [ 72, 132, 148], h: 0.172, w: 0.95, wet: 1 },
  { cls: 'beach',      color: [216, 204, 164], h: 0.198, w: 0.35, wet: 0 },
  { cls: 'grass',      color: [136, 152,  96], h: 0.300, w: 0.55, wet: 0 },
  { cls: 'forest',     color: [ 78, 104,  66], h: 0.365, w: 0.80, wet: 0 },
  { cls: 'rainforest', color: [ 54,  92,  54], h: 0.345, w: 0.95, wet: 0 },
  { cls: 'wetland',    color: [107, 125,  74], h: 0.212, w: 0.92, wet: 1 },
  { cls: 'hills',      color: [146, 134,  96], h: 0.445, w: 0.45, wet: 0 },
  { cls: 'mountain',   color: [124, 112,  98], h: 0.600, w: 0.25, wet: 0 },
  { cls: 'rock',       color: [148, 142, 134], h: 0.665, w: 0.15, wet: 0 },
  { cls: 'snow',       color: [236, 240, 242], h: 0.885, w: 0.05, wet: 0 },
  { cls: 'river',      color: [ 70, 118, 146], h: 0.176, w: 1.00, wet: 1 },
  { cls: 'lake',       color: [ 62, 106, 132], h: 0.176, w: 1.00, wet: 1 },
];

export const CLASS_NAMES = SEMANTIC_PALETTE.map((p) => p.cls);
export const CLASS_ELEVATION = Object.fromEntries(SEMANTIC_PALETTE.map((p) => [p.cls, p.h]));
export const WET_CLASSES = new Set(SEMANTIC_PALETTE.filter((p) => p.wet).map((p) => p.cls));

/** 感知加权最近色匹配，返回色板下标 */
export function nearestClass(r, g, b, palette = SEMANTIC_PALETTE) {
  let best = 0;
  let bestD = Infinity;
  for (let i = 0; i < palette.length; i++) {
    const c = palette[i].color;
    const dr = r - c[0];
    const dg = g - c[1];
    const db = b - c[2];
    const d = dr * dr * 0.30 + dg * dg * 0.59 + db * db * 0.11;
    if (d < bestD) { bestD = d; best = i; }
  }
  return best;
}

/** 可分离盒式模糊：滑动窗口 O(N)，多次迭代近似高斯；边缘钳制 */
export function boxBlur(src, w, h, radius, passes = 2) {
  const a = Float32Array.from(src);
  const b = new Float32Array(src.length);
  const r = Math.max(1, radius | 0);
  const win = r * 2 + 1;
  for (let p = 0; p < passes; p++) {
    for (let y = 0; y < h; y++) {
      const row = y * w;
      let sum = 0;
      for (let k = -r; k <= r; k++) sum += a[row + clamp(k, 0, w - 1)];
      for (let x = 0; x < w; x++) {
        b[row + x] = sum / win;
        sum += a[row + clamp(x + r + 1, 0, w - 1)] - a[row + clamp(x - r, 0, w - 1)];
      }
    }
    for (let x = 0; x < w; x++) {
      let sum = 0;
      for (let k = -r; k <= r; k++) sum += b[clamp(k, 0, h - 1) * w + x];
      for (let y = 0; y < h; y++) {
        a[y * w + x] = sum / win;
        sum += b[clamp(y + r + 1, 0, h - 1) * w + x] - b[clamp(y - r, 0, h - 1) * w + x];
      }
    }
  }
  return a;
}

/** 8 邻域倒角距离变换（正反双扫描近似欧氏距离） */
export function distanceField(mask, w, h) {
  const N = w * h;
  const INF = 1e9;
  const d = new Float32Array(N);
  for (let i = 0; i < N; i++) d[i] = mask[i] > 0.5 ? 0 : INF;
  const D = 1;
  const DD = 1.4142;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      let v = d[i];
      if (x > 0) v = Math.min(v, d[i - 1] + D);
      if (y > 0) v = Math.min(v, d[i - w] + D);
      if (x > 0 && y > 0) v = Math.min(v, d[i - w - 1] + DD);
      if (x < w - 1 && y > 0) v = Math.min(v, d[i - w + 1] + DD);
      d[i] = v;
    }
  }
  for (let y = h - 1; y >= 0; y--) {
    for (let x = w - 1; x >= 0; x--) {
      const i = y * w + x;
      let v = d[i];
      if (x < w - 1) v = Math.min(v, d[i + 1] + D);
      if (y < h - 1) v = Math.min(v, d[i + w] + D);
      if (x < w - 1 && y < h - 1) v = Math.min(v, d[i + w + 1] + DD);
      if (x > 0 && y < h - 1) v = Math.min(v, d[i + w - 1] + DD);
      d[i] = v;
    }
  }
  return d;
}

/** 局部坡度（中心差分，0..1） */
export function slopeField(hf, w, h) {
  const out = new Float32Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const xm = x > 0 ? i - 1 : i;
      const xp = x < w - 1 ? i + 1 : i;
      const ym = y > 0 ? i - w : i;
      const yp = y < h - 1 ? i + w : i;
      const dx = (hf[xp] - hf[xm]) * 0.5;
      const dy = (hf[yp] - hf[ym]) * 0.5;
      out[i] = Math.min(1, Math.sqrt(dx * dx + dy * dy) * 26);
    }
  }
  return out;
}

/** 手绘美术图：RGB k-means 得到有限色板 */
function kmeansPalette(rgba, N, k = 9, iters = 9) {
  const rnd = mulberry32(9137);
  const centers = [];
  const stride = Math.max(1, Math.floor(N / 24000));
  for (let j = 0; j < k; j++) {
    const o = Math.floor(rnd() * N) * 4;
    centers.push([rgba[o], rgba[o + 1], rgba[o + 2]]);
  }
  const acc = new Float64Array(k * 4);
  for (let it = 0; it < iters; it++) {
    acc.fill(0);
    for (let i = 0; i < N; i += stride) {
      const o = i * 4;
      let best = 0;
      let bd = Infinity;
      for (let c = 0; c < k; c++) {
        const C = centers[c];
        const dr = rgba[o] - C[0];
        const dg = rgba[o + 1] - C[1];
        const db = rgba[o + 2] - C[2];
        const d = dr * dr + dg * dg + db * db;
        if (d < bd) { bd = d; best = c; }
      }
      acc[best * 4] += rgba[o];
      acc[best * 4 + 1] += rgba[o + 1];
      acc[best * 4 + 2] += rgba[o + 2];
      acc[best * 4 + 3] += 1;
    }
    for (let c = 0; c < k; c++) {
      if (acc[c * 4 + 3] > 0) {
        centers[c][0] = acc[c * 4] / acc[c * 4 + 3];
        centers[c][1] = acc[c * 4 + 1] / acc[c * 4 + 3];
        centers[c][2] = acc[c * 4 + 2] / acc[c * 4 + 3];
      }
    }
  }
  return centers;
}

/* ============================================================
   主入口
   ============================================================ */
/**
 * @param {Uint8ClampedArray} rgba
 * @param {number} w
 * @param {number} h
 * @param {string} mode semantic | height | hybrid | painted
 * @param {object} opt { relief, detail, seed, seaLevel, palette }
 */
export function read2DMap(rgba, w, h, mode = 'semantic', opt = {}) {
  const N = w * h;
  const palette = opt.palette || SEMANTIC_PALETTE;
  const relief = typeof opt.relief === 'number' ? opt.relief : 1;
  const detail = typeof opt.detail === 'number' ? opt.detail : 1;
  const seaLevel = typeof opt.seaLevel === 'number' ? opt.seaLevel : SEA;
  const seed = (opt.seed | 0) || 1337;

  const lum = new Float32Array(N);
  const cls = new Uint8Array(N);
  const water = new Float32Array(N);
  const hgt = new Float32Array(N);
  // 双通道时亮度可以来自另一张高度图，颜色仍取自 rgba
  const lumSrc = opt.lumaRgba || rgba;

  // pass 1: 亮度直方图拉伸。高度图常常只用了 30%~70% 灰阶
  let lmin = 1;
  let lmax = 0;
  for (let i = 0; i < N; i++) {
    const o = i * 4;
    const l = (0.299 * lumSrc[o] + 0.587 * lumSrc[o + 1] + 0.114 * lumSrc[o + 2]) / 255;
    lum[i] = l;
    if (l < lmin) lmin = l;
    if (l > lmax) lmax = l;
  }
  if (lmax - lmin < 0.04) { lmin = 0; lmax = 1; }
  const lRange = Math.max(1e-4, lmax - lmin);

  // 手绘模式：先聚类，再按「簇的明暗 + 是否偏蓝」推断每簇的高程台阶
  let paintedC = null;
  let clusterH = null;
  if (mode === 'painted') {
    paintedC = kmeansPalette(rgba, N, 9, 9);
    const order = paintedC
      .map((c, i) => ({
        i,
        y: 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2],
        blue: c[2] > c[0] * 1.18 && c[2] > c[1] * 1.05,
      }))
      .sort((a, b) => a.y - b.y);
    clusterH = new Float32Array(order.length);
    order.forEach((o, rank) => {
      clusterH[o.i] = o.blue ? 0.075 : 0.19 + (rank / (order.length - 1)) * 0.70;
    });
  }

  // pass 2: 分类 + 基础高程
  for (let i = 0; i < N; i++) {
    const o = i * 4;
    const r = rgba[o];
    const g = rgba[o + 1];
    const b = rgba[o + 2];
    const ln = clamp((lum[i] - lmin) / lRange, 0, 1);
    const ci = nearestClass(r, g, b, palette);
    const P = palette[ci];
    cls[i] = ci;
    const isWet = WET_CLASSES.has(P.cls);

    let h0;
    if (mode === 'height') {
      h0 = ln;
      water[i] = ln * 0.94 < seaLevel ? 1 : 0;
    } else if (mode === 'hybrid') {
      // 亮度是骨架；类别只做小幅语义修正，避免色块把山削成台阶
      h0 = ln * 0.86 + P.h * 0.14;
      water[i] = isWet || h0 < seaLevel ? 1 : 0;
    } else if (mode === 'painted') {
      let bi = 0;
      let bd = Infinity;
      for (let c = 0; c < paintedC.length; c++) {
        const cc = paintedC[c];
        const dr = r - cc[0];
        const dg = g - cc[1];
        const db = b - cc[2];
        const d = dr * dr + dg * dg + db * db;
        if (d < bd) { bd = d; bi = c; }
      }
      h0 = clusterH[bi];
      water[i] = h0 < seaLevel ? 1 : 0;
    } else {
      // semantic：类别给骨，明度给块内微起伏
      h0 = P.h + (ln - 0.5) * 0.055;
      water[i] = isWet ? 1 : 0;
    }
    hgt[i] = h0;
  }

  // pass 3: 台阶连续化。语义色的离散高程必须抹成连续坡面，
  // 否则 3D 里就是一层层梯田；水区单独压回平缓海床
  const radius = Math.max(2, Math.round(Math.min(w, h) / 110));
  const passes = mode === 'semantic' || mode === 'painted' ? 4 : 1;
  const smooth = boxBlur(hgt, w, h, radius, passes);
  const waterSmooth = boxBlur(water, w, h, Math.max(1, radius >> 1), 1);
  for (let i = 0; i < N; i++) {
    const t = smoothstep(0.34, 0.72, waterSmooth[i]);
    const seabed = seaLevel - 0.02 - (1 - smooth[i]) * 0.10;
    hgt[i] = lerp(smooth[i], seabed, t * 0.82);
    water[i] = saturate(waterSmooth[i] * 1.12 - 0.06);
  }

  // pass 4: 分形细节 + 山脊（山地更强，水面不加）
  const nx = w / 64;
  const ny = h / 64;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const dry = 1 - water[i];
      if (dry < 0.02) continue;
      const u = x / w;
      const v = y / h;
      const mountain = smoothstep(0.34, 0.66, hgt[i]);
      const fine = fbm2(u * nx + seed * 0.017, v * ny + 11.3, 5) - 0.5;
      const ridge = fbm2(u * nx * 0.42 + 31.7, v * ny * 0.42 + 5.9, 4) - 0.5;
      const micro = valueNoise2(u * nx * 5.3 + 7.1, v * ny * 5.3 + 2.7) - 0.5;
      const amp = (0.012 + mountain * 0.055) * detail * relief;
      hgt[i] += dry * (fine * amp + ridge * mountain * 0.030 * detail + micro * amp * 0.28);
    }
  }

  // pass 5: 起伏缩放（以海平面为锚，避免整体漂移）
  if (Math.abs(relief - 1) > 0.001) {
    for (let i = 0; i < N; i++) {
      const d = hgt[i] - seaLevel;
      hgt[i] = seaLevel + d * (d > 0 ? relief : 0.72);
    }
  }
  for (let i = 0; i < N; i++) hgt[i] = saturate(hgt[i]);

  // pass 6: 湿度 / 水体距离 / 坡度
  const wetMask = new Float32Array(N);
  for (let i = 0; i < N; i++) wetMask[i] = water[i] > 0.55 ? 1 : 0;
  const dist = distanceField(wetMask, w, h);
  let dMax = 1;
  for (let i = 0; i < N; i++) if (dist[i] < 1e8 && dist[i] > dMax) dMax = dist[i];
  for (let i = 0; i < N; i++) if (dist[i] >= 1e8) dist[i] = dMax;

  const slope = slopeField(hgt, w, h);
  const moisture = new Float32Array(N);
  const falloff = Math.max(4, w * 0.13);
  for (let i = 0; i < N; i++) {
    const x = i % w;
    const y = (i / w) | 0;
    const near = Math.exp(-dist[i] / falloff);
    const classW = palette[cls[i]] ? palette[cls[i]].w : 0.5;
    const noise = (fbm2(x * 0.045 + seed * 0.01, y * 0.045 + 8.3, 3) - 0.5) * 0.22;
    const altDry = smoothstep(0.55, 0.92, hgt[i]) * 0.18;
    moisture[i] = saturate(0.10 + near * 0.62 + classW * 0.30 + noise - slope[i] * 0.34 - altDry);
  }

  return {
    height: hgt,
    water,
    moisture,
    cls,
    dist,
    slope,
    meta: { w, h, mode, seaLevel, relief, detail, seed, classes: palette.map((p) => p.cls) },
  };
}
