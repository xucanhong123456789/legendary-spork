import { smoothstep, smootherstep, saturate, lerp, valueNoise2, fbm2, ridged2 } from '../engine/geo/noise.js';

export const SAMPLE_PALETTE = {
  deep: [20, 46, 78],
  ocean: [40, 84, 116],
  shallow: [72, 132, 148],
  beach: [216, 204, 164],
  plain: [136, 152, 96],
  forest: [78, 104, 66],
  jungle: [54, 92, 54],
  hill: [146, 134, 96],
  mountain: [124, 112, 98],
  scree: [148, 142, 134],
  snow: [236, 240, 242],
  river: [70, 118, 146],
  lake: [62, 106, 132],
};

export const SEA_LEVEL_SAMPLE = 0.18;

const SEA = SEA_LEVEL_SAMPLE;

function clamp01(x) {
  return x < 0 ? 0 : x > 1 ? 1 : x;
}

export function makeSampleMap(kind, size) {
  const S = size || 1024;
  const canvas = document.createElement('canvas');
  canvas.width = S;
  canvas.height = S;
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(S, S);
  const px = img.data;
  const height = new Float32Array(S * S);
  let peak = 0;

  for (let y = 0; y < S; y++) {
    const v = y / (S - 1);
    for (let x = 0; x < S; x++) {
      const u = x / (S - 1);
      const f = sampleField(kind, u, v);
      const idx = y * S + x;
      height[idx] = f.h;
      if (f.h > peak) peak = f.h;
      const c = SAMPLE_PALETTE[f.cls] || SAMPLE_PALETTE.plain;
      px[idx * 4] = c[0];
      px[idx * 4 + 1] = c[1];
      px[idx * 4 + 2] = c[2];
      px[idx * 4 + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return { canvas, height, meta: { kind, size: S, peak } };
}

/* ---------------- 例图 1: 温带高纬峡湾 ---------------- */
function fieldFjord(u, v) {
  // 海岸线在 0.86 附近蜿蜒：u < coast 为海，u > coast 为陆
  const coast = 0.865 + Math.sin(v * 6.3) * 0.030 + Math.sin(v * 17.1 + 1.4) * 0.012;
  const shelf = 1 - smoothstep(0.0, 0.42, coast - u);
  let h = SEA - 0.085 * shelf;

  // 海岸山脉：贴着海岸线内侧隆起的一条山链
  const chainX = coast - 0.10 + Math.sin(v * 4.1 + 0.6) * 0.035;
  const dChain = (u - chainX) / 0.115;
  const chain = Math.exp(-dChain * dChain * 1.8) * smoothstep(1.0, 0.55, Math.abs(dChain));
  h += chain * (0.16 + ridged2(u * 3.4 + 4.2, v * 3.8 + 1.3, 4) * 0.46);

  // 内陆逐渐转为高原缓丘
  h += smoothstep(coast, coast - 0.45, u) * fbm2(u * 5 + 9, v * 5 + 2, 4) * 0.12;

  // 峡湾：三条垂直于海岸的窄长水道，切到海平面以下
  for (let i = 0; i < 3; i++) {
    const y0 = 0.13 + i * 0.36;
    const t = v - (y0 + Math.sin(u * 7.0 + i * 2.0) * 0.010);
    const wobble = Math.cos(u * 5.0 + i * 1.0) * 0.006;
    const w = 0.014 + i * 0.004;
    const tube = 1 - smoothstep(w * 0.55, w * 1.5, Math.abs(t + wobble));
    const reach = smoothstep(0.62, 0.99, u);
    h = lerp(h, SEA - 0.048, tube * reach);
  }

  // 冰斗湖：山脉内部一处圆坑，蓄水
  const lx = (u - 0.795) * 1.55;
  const ly = v - 0.335;
  h -= (1 - smoothstep(0.010, 0.030, Math.hypot(lx, ly))) * 0.030;

  return { h: clamp01(h), cls: classifyLayer(h, 0.5, 0.5) };
}

/* ---------------- 例图 2: 河口三角洲 ---------------- */
function fieldDelta(u, v) {
  const vv = v - 0.06;

  // 北侧丘陵：河流的源头
  let h = SEA + 0.030 + smootherstep(0.86, 1.02, vv) * 0.185;
  h += ridged2(u * 5.0 + 2.2, vv * 12.0 + 6.1, 4) * 0.055 * smootherstep(0.82, 1.0, vv);

  // 主河道自北向南微微摆动，越往下游越向两侧张开（分汊扇）
  const mainX = 0.50 + 0.055 * Math.sin(vv * 5.4 + 0.3);
  for (let b = 0; b < 5; b++) {
    const spread = (b - 2) * 0.085 * smootherstep(0.30, 0.98, vv);
    const cx = mainX + spread + 0.012 * Math.sin(vv * (17 + b * 5) + b * 2.3);
    const halfW = 0.0042 + Math.pow(saturate(vv), 1.7) * 0.026;
    const d = Math.abs(u - cx);
    const carve = (1 - smoothstep(halfW * 0.5, halfW * 1.5, d)) * smootherstep(0.30, 0.86, vv);
    h = lerp(h, SEA - 0.020 - vv * 0.012, carve * (0.85 - b * 0.08));
  }

  // 冲积平原：非常平，越靠海越低
  h -= 0.075 * pow(saturate(vv), 1.35) * (0.55 + 0.45 * smoothstep(mainX - 0.30, mainX, u));

  h += (fbm2(u * 14 + 3, vv * 14 + 7, 4) - 0.5) * 0.016;

  // 海洋
  h = lerp(h, SEA - 0.045 - (vv - 0.74) * 0.20, smootherstep(0.74, 0.99, vv));
  return { h: clamp01(h), cls: classifyLayer(h, 0.72, 0.92) };
}

function pow(a, b) { return Math.pow(a, b); }

function spread_of(u, cx, vv) {
  return 0;
}
/* ---------------- 例图 3: 开阔大陆 ---------------- */
function fieldContinent(u, v) {
  const coast = 0.30 + Math.sin(v * 4.6 + 0.5) * 0.085 + Math.sin(v * 12.1) * 0.020;
  const land = smoothstep(coast - 0.03, coast + 0.10, u);

  let h = SEA + land * (0.10 + fbm2(u * 4 + 2, v * 4 + 9, 5) * 0.34);

  const chainX = 0.60 + Math.sin(v * 3.4) * 0.075 + Math.sin(v * 8.0) * 0.020;
  const dChain = (u - chainX) / 0.135;
  const chain = Math.exp(-dChain * dChain) * ridged2(u * 2.6 + 5.1, v * 3.0 + 2.4, 5);
  h += chain * 1.15 * land * smootherstep(0.0, 0.8, v);
   const bx = (u - 0.78) * 1.4;
  const by = v - 0.52;
  const basin = Math.exp(-(bx * bx + by * by) * 9.0);
  h -= basin * 0.16 * land;

  h += (fbm2(u * 26, v * 26, 4) - 0.5) * 0.030;

  const lakes = [[0.795, 0.455, 0.052], [0.735, 0.545, 0.034]];
  for (const L of lakes) {
    const dx = u - L[0];
    const dy = v - L[1];
    const r = Math.hypot(dx * 1.25, dy) / L[2];
    h -= smoothstep(1.25, 0.35, r) * 0.045;
  }

  h = lerp(h, SEA - 0.09 - smoothstep(coast, 0.0, u) * 0.135, 1 - land);

  return { h: clamp01(h), cls: classifyLayer(clamp01(h), 0.5, 0.5) };
}

/* ---------------- 例图 4: 热带火山岛 ---------------- */
function fieldIsland(u, v) {
  const cx = 0.46;
  const cy = 0.50;
  const dx = u - cx;
  const dy = (v - cy) * 1.06;
  const r = Math.hypot(dx, dy);
  const ang = Math.atan2(dy, dx);

  const edge = 0.335 + Math.sin(ang * 3.0 + 0.8) * 0.030 + Math.sin(ang * 7.0) * 0.012;
  const dome = 1 - smoothstep(0.02, edge, r);
  const cone = Math.pow(saturate(1 - r / 0.20), 2.1) * 0.55;
  let h = SEA + dome * 0.24 + cone;

  const crater = 1 - smoothstep(0.012, 0.042, r);
  h -= crater * 0.055;
  h += (1 - smoothstep(0.042, 0.085, r)) * 0.030;

  for (let f = 0; f < 9; f++) {
    const fa = f * 0.698 + Math.sin(f * 11.3) * 0.4;
    const cux = Math.cos(fa);
    const cuy = Math.sin(fa);
    const along = dx * cux + dy * cuy;
    if (along < 0.05 || along > 0.42) continue;
    const perp = Math.abs(-dx * cuy + dy * cux);
    const w = 0.008 + along * 0.024;
    h -= (1 - smoothstep(0, w, perp)) * 0.026 * smoothstep(0.42, 0.20, along);
  }

  // lagoon ring
  const ring = Math.abs(r - edge - 0.045);
  h -= (1 - smoothstep(0, 0.030, ring)) * 0.035;

  h += (fbm2(u * 22 + 5, v * 22 + 1, 4) - 0.5) * 0.035 * saturate(dome);
  h = lerp(h, SEA - 0.14, smootherstep(edge + 0.02, edge + 0.30, r));

  return { h: clamp01(h), cls: classifyLayer(clamp01(h), 0.78, 0.98) };
}

/** 派发到具体地貌生成器 */
export function sampleField(kind, u, v) {
  if (kind === 'delta') return fieldDelta(u, v);
  if (kind === 'continent') return fieldContinent(u, v);
  if (kind === 'island') return fieldIsland(u, v);
  return fieldFjord(u, v);
}

/** 按高程 / 湿度决定地表类别（例图用简化规则） */
function classifyLayer(h, moisture, temp) {
  if (h < 0.120) return 'deep';
  if (h < 0.176) return 'ocean';
  if (h < 0.184) return 'shallow';
  if (h < 0.200) return 'beach';
  if (h > 0.900) return 'snow';
  if (h > 0.660) return 'mountain';
  if (h > 0.450) return 'hill';
  if (moisture > 0.600 && temp > 0.650) return 'jungle';
  if (moisture > 0.445) return 'forest';
  return 'plain';
}
