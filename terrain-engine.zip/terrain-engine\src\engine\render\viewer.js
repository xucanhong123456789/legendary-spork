// ============================================================
// viewer.js - three.js 三维视口
// LOD 地形网格 + 地表反照率贴图 + 水面着色器 + GPU 实例化植被
// + 大气天空 / 分层雾 / 日照阴影 / 轨道相机
// 对引擎是可选层：算法核心不依赖它，可替换成任意渲染后端。
// ============================================================
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { makeSkyMaterial, makeWaterMaterial } from './shaders.js';
import { clamp, saturate, mulberry32 } from '../geo/noise.js';
import { boxBlur } from '../terrain/readMap.js';
import { treeGeometry, TRUNK_COLOR, LEAF_COLOR } from './treeFactory.js';
import { makeLeafTexture, makeNeedleTexture, makeFrondTexture } from './leafTexture.js';

const S = 120;       // 世界边长
const HS = 26;       // 高程缩放

/** 从 (W,H) 场里按归一化坐标取双线性值 */
function sample(field, W, H, u, v) {
  const fx = clamp(u, 0, 1) * (W - 1);
  const fy = clamp(v, 0, 1) * (H - 1);
  const x0 = Math.floor(fx);
  const y0 = Math.floor(fy);
  const x1 = Math.min(W - 1, x0 + 1);
  const y1 = Math.min(H - 1, y0 + 1);
  const tx = fx - x0;
  const ty = fy - y0;
  const a = field[y0 * W + x0];
  const b = field[y0 * W + x1];
  const c = field[y1 * W + x0];
  const d = field[y1 * W + x1];
  return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
}

function makeGrid(seg, fill) {
  const n = (seg + 1) * (seg + 1);
  const pos = new Float32Array(n * 3);
  const uv = new Float32Array(n * 2);
  const idx = new Uint32Array(seg * seg * 6);
  for (let j = 0; j <= seg; j++) {
    for (let i = 0; i <= seg; i++) {
      const k = j * (seg + 1) + i;
      const u = i / seg;
      const v = j / seg;
      const p = fill(u, v, k);
      pos[k * 3] = (u - 0.5) * S;
      pos[k * 3 + 1] = p.y;
      pos[k * 3 + 2] = (v - 0.5) * S;
      uv[k * 2] = u;
      uv[k * 2 + 1] = v;
    }
  }
  let t = 0;
  for (let j = 0; j < seg; j++) {
    for (let i = 0; i < seg; i++) {
      const a = j * (seg + 1) + i;
      const b = a + 1;
      const c = a + seg + 1;
      const d = c + 1;
      idx[t++] = a; idx[t++] = c; idx[t++] = b;
      idx[t++] = b; idx[t++] = c; idx[t++] = d;
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setIndex(new THREE.BufferAttribute(idx, 1));
  return { geometry: g, pos, uv };
}

/** 地图四周的地质剖面裙边：把方形高度场变成一块有厚度的地景模型 */
function makeSkirt(dem, W, H, seg, bottomY) {
  const perEdge = seg + 1;
  const total = 4 * perEdge * 2;
  const pos = new Float32Array(total * 3);
  const idx = new Uint32Array(4 * seg * 6);
  const edges = [
    (t) => [t, 0],
    (t) => [1, t],
    (t) => [1 - t, 1],
    (t) => [0, 1 - t],
  ];
  let p = 0;
  let base = 0;
  let q = 0;
  for (let e = 0; e < 4; e++) {
    for (let k = 0; k <= seg; k++) {
      const [u, v] = edges[e](k / seg);
      const x = (u - 0.5) * S;
      const z = (v - 0.5) * S;
      pos[p++] = x; pos[p++] = sample(dem, W, H, u, v) * HS; pos[p++] = z;
      pos[p++] = x; pos[p++] = bottomY; pos[p++] = z;
    }
    for (let k = 0; k < seg; k++) {
      const a = base + k * 2;
      idx[q++] = a; idx[q++] = a + 1; idx[q++] = a + 2;
      idx[q++] = a + 1; idx[q++] = a + 3; idx[q++] = a + 2;
    }
    base += perEdge * 2;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setIndex(new THREE.BufferAttribute(idx, 1));
  g.computeVertexNormals();
  return g;
}

function albedoTexture(rgb, W, H) {
  const data = new Uint8Array(W * H * 4);
  for (let i = 0; i < W * H; i++) {
    data[i * 4] = rgb[i * 3];
    data[i * 4 + 1] = rgb[i * 3 + 1];
    data[i * 4 + 2] = rgb[i * 3 + 2];
    data[i * 4 + 3] = 255;
  }
  const tex = new THREE.DataTexture(data, W, H, THREE.RGBAFormat, THREE.UnsignedByteType);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.generateMipmaps = true;
  tex.anisotropy = 4;
  tex.needsUpdate = true;
  return tex;
}

function maskTexture(mask, W, H) {
  const tex = new THREE.DataTexture(mask, W, H, THREE.RedFormat, THREE.UnsignedByteType);
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;
  tex.unpackAlignment = 1;
  tex.needsUpdate = true;
  return tex;
}

/** 给几何体加顶点色（树干棕、树冠白，instanceColor 再乘上去） */
function tint(geo, color) {
  const g = geo.index ? geo.toNonIndexed() : geo;
  const n = g.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    arr[i * 3] = color[0];
    arr[i * 3 + 1] = color[1];
    arr[i * 3 + 2] = color[2];
  }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}


export class TerrainViewer {
  constructor(container) {
    this.container = container;
    this.renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.18;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0xb9cbd0, 0.0026);

    this.camera = new THREE.PerspectiveCamera(46, 1, 0.5, 1400);
    this.camera.position.set(78, 52, 92);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.set(0, 5, 0);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.minDistance = 22;
    this.controls.maxDistance = 330;
    this.controls.maxPolarAngle = Math.PI * 0.485;
    this.controls.update();

    // 天空穹顶
    this.skyMat = makeSkyMaterial();
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(600, 32, 20), this.skyMat);
    this.sky.frustumCulled = false;
    this.scene.add(this.sky);

    // 光照
    this.hemi = new THREE.HemisphereLight(0xa9c7dd, 0x4a4335, 1.05);
    this.scene.add(this.hemi);
    this.ambient = new THREE.AmbientLight(0xffffff, 0.16);
    this.scene.add(this.ambient);
    this.sun = new THREE.DirectionalLight(0xffe0b5, 2.3);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const sc = this.sun.shadow.camera;
    sc.left = -95; sc.right = 95; sc.top = 95; sc.bottom = -95;
    sc.near = 1; sc.far = 420;
    this.sun.shadow.bias = -0.0006;
    this.sun.shadow.normalBias = 0.035;
    this.scene.add(this.sun, this.sun.target);

    // 体积光近似：太阳方向的加法混合光晕
    this.glowMat = new THREE.SpriteMaterial({
      map: makeGlowTexture(), color: 0xffcf92, transparent: true,
      blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.0,
    });
    this.glow = new THREE.Sprite(this.glowMat);
    this.glow.scale.set(150, 150, 1);
    this.scene.add(this.glow);

    this.root = new THREE.Group();
    this.scene.add(this.root);
    this.terrainMesh = null;
    this.waterMesh = null;
    this.vegetation = [];
    this.terrainMat = null;
    this.waterMat = null;
    this.albedoTex = null;
    this.albedoNoSnowTex = null;
    this.normalMat = new THREE.MeshNormalMaterial({ flatShading: false });
    this.showNormals = false;
    this.result = null;
    this.layers = { terrain: true, snow: true, water: true, forest: true, relief: true };
    this.clock = new THREE.Clock();

    this._onResize = () => this.resize();
    window.addEventListener('resize', this._onResize);
    this.resize();
    this.setAtmosphere({ sun: 28, haze: 0.8, cloud: 0.6, bloom: true, godrays: false });

    this._loop = () => {
      this.raf = requestAnimationFrame(this._loop);
      const t = this.clock.getElapsedTime();
      if (this.waterMat) this.waterMat.uniforms.uTime.value = t;
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
    };
    this._loop();
  }

  resize() {
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  /** 构建/替换整个三维世界 */
  setTerrain(result, quality = 'high') {
    this.disposeWorld();
    this.result = result;
    const { W, H, dem, hydro, biomes } = result;
    const seg = Math.min(quality === 'low' ? 192 : quality === 'medium' ? 256 : 352, Math.max(96, Math.min(W, H)));

    // ---- 地形 ----
    const grid = makeGrid(seg, (u, v) => ({ y: sample(dem, W, H, u, v) * HS }));
    grid.geometry.computeVertexNormals();
    this.albedoTex = albedoTexture(biomes.albedo, W, H);
    this.albedoNoSnowTex = albedoTexture(biomes.albedoNoSnow, W, H);
    this.terrainMat = new THREE.MeshStandardMaterial({
      map: this.layers.snow ? this.albedoTex : this.albedoNoSnowTex,
      roughness: 0.96,
      metalness: 0.0,
      side: THREE.FrontSide,
    });
    this.terrainMesh = new THREE.Mesh(grid.geometry, this.terrainMat);
    this.terrainMesh.receiveShadow = true;
    this.terrainMesh.castShadow = false;
    this.terrainMesh.name = 'Terrain';
    this.root.add(this.terrainMesh);

    const skirt = new THREE.Mesh(
      makeSkirt(dem, W, H, seg, result.stats.seaLevel * HS - 4.4),
      new THREE.MeshStandardMaterial({ color: 0x2d2b24, roughness: 1, metalness: 0, side: THREE.DoubleSide })
    );
    skirt.name = 'Skirt';
    this.root.add(skirt);

    // ---- 水面：一张跟随 surface 场的网格 + mask 裁剪 ----
    const maskF = new Float32Array(W * H);
    const sea = result.stats.seaLevel;
    for (let i = 0; i < W * H; i++) {
      const wm = hydro.waterMask[i];
      // 海 / 湖生成真实水面；河道由地表河槽着色表现，避免细窄水面网格产生锯齿
      maskF[i] = (wm === 1 || wm === 2) ? 1 : 0;
    }
    const soft = boxBlur(maskF, W, H, 1, 1);
    const mask = new Uint8Array(W * H);
    for (let i = 0; i < W * H; i++) mask[i] = Math.round(saturate(soft[i] * 1.35) * 255);
    const maskTex = maskTexture(mask, W, H);

    const wgrid = makeGrid(seg, (u, v) => {
      const x = Math.round(u * (W - 1));
      const y = Math.round(v * (H - 1));
      const i = y * W + x;
      const yv = maskF[i]
        ? hydro.surface[i] * HS + 0.035
        : sea * HS - 0.03;
      return { y: yv };
    });
    const n = (seg + 1) * (seg + 1);
    const aMask = new Float32Array(n);
    const aDepth = new Float32Array(n);
    for (let j = 0; j <= seg; j++) {
      for (let i = 0; i <= seg; i++) {
        const k = j * (seg + 1) + i;
        const u = i / seg;
        const v = j / seg;
        aMask[k] = sample(maskF, W, H, u, v);
        const x = Math.round(u * (W - 1));
        const y = Math.round(v * (H - 1));
        const q = y * W + x;
        aDepth[k] = maskF[q] ? Math.max(0, hydro.surface[q] - dem[q]) : 0;
      }
    }
    wgrid.geometry.setAttribute('aMask', new THREE.BufferAttribute(aMask, 1));
    wgrid.geometry.setAttribute('aDepth', new THREE.BufferAttribute(aDepth, 1));
    wgrid.geometry.computeVertexNormals();
    this.waterMat = makeWaterMaterial({
      uMaskTex: { value: maskTex },
      uTexel: { value: new THREE.Vector2(1 / W, 1 / H) },
    });
    this.waterMesh = new THREE.Mesh(wgrid.geometry, this.waterMat);
    this.waterMesh.renderOrder = 2;
    this.waterMesh.name = 'Water';
    this.root.add(this.waterMesh);

    // ---- 图幅外的延伸海域：复用同一套水面着色器，消除菱形色差边界 ----
    // 中间挖空 120x120，与主水面网格完全不重叠，避免共面深度冲突
    const shape = new THREE.Shape();
    shape.moveTo(-450, -450);
    shape.lineTo(450, -450);
    shape.lineTo(450, 450);
    shape.lineTo(-450, 450);
    shape.closePath();
    const hole = new THREE.Path();
    hole.moveTo(-S / 2, -S / 2);
    hole.lineTo(-S / 2, S / 2);
    hole.lineTo(S / 2, S / 2);
    hole.lineTo(S / 2, -S / 2);
    hole.closePath();
    shape.holes.push(hole);
    const outerGeo = new THREE.ShapeGeometry(shape);
    outerGeo.rotateX(-Math.PI / 2);
    const nOuter = outerGeo.attributes.position.count;
    outerGeo.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(nOuter * 2).fill(0.5), 2));
    outerGeo.setAttribute('aMask', new THREE.BufferAttribute(new Float32Array(nOuter).fill(1), 1));
    outerGeo.setAttribute('aDepth', new THREE.BufferAttribute(new Float32Array(nOuter).fill(0.13), 1));
    const whiteMask = new THREE.DataTexture(new Uint8Array([255]), 1, 1, THREE.RedFormat);
    whiteMask.needsUpdate = true;
    whiteMask.unpackAlignment = 1;
    const outerMat = makeWaterMaterial();
    outerMat.uniforms = {
      ...this.waterMat.uniforms,
      uMaskTex: { value: whiteMask },
      uFoam: { value: 0 },
      uTexel: { value: new THREE.Vector2(1 / 900, 1 / 900) },
    };
    this.outerSea = new THREE.Mesh(outerGeo, outerMat);
    this.outerSea.position.y = result.stats.seaLevel * HS + 0.012;
    this.outerSea.renderOrder = 1;
    this.outerSea.name = 'OuterSea';
    this.root.add(this.outerSea);

    // ---- 实例化植被 ----
    this.buildVegetation(biomes, W, H);

    this.setAtmosphere(this.atmo || {});
    this.applyLayers();
    this.resize();
    return this.getStats();
  }

  buildVegetation(biomes, W, H) {
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    const groups = [[], [], [], []];
    const t = biomes.trees;
    for (let k = 0; k < t.count; k++) groups[t.type[k]].push(k);

    // 叶冠贴图：针叶 / 阔叶(含雨林) / 棕榈 各一套，alpha 镂空让叶冠读作真实叶片而非圆球
    const texNeedle = makeNeedleTexture();
    const texLeaf = makeLeafTexture();
    const texFrond = makeFrondTexture();
    const leafMatFor = (tex) => new THREE.MeshStandardMaterial({
      color: 0xffffff, vertexColors: true, map: tex, alphaTest: 0.5,
      transparent: false, roughness: 0.86, metalness: 0, side: THREE.DoubleSide,
    });
    // 每种树对应一套叶材质 / 叶阴影深度材质（叶形阴影）
    const leafMats = [leafMatFor(texNeedle), leafMatFor(texLeaf), leafMatFor(texLeaf), leafMatFor(texFrond)];
    const leafDepth = leafMats.map((m) => new THREE.MeshDepthMaterial({
      depthPacking: THREE.RGBADepthPacking, map: m.map, alphaTest: 0.5,
    }));
    // 木本材质：用几何自带棕色顶点色，不随叶色染色
    const woodMat = new THREE.MeshStandardMaterial({
      color: 0xffffff, vertexColors: true, roughness: 0.92,
      metalness: 0, flatShading: false, side: THREE.FrontSide,
    });
    const TREE_GEO = [treeGeometry(0), treeGeometry(1), treeGeometry(2), treeGeometry(3)];
    let treeCount = 0;
    for (let type = 0; type < 4; type++) {
      const list = groups[type];
      if (!list.length) continue;
      const { woody, foliage } = TREE_GEO[type];
      const wMesh = new THREE.InstancedMesh(woody, woodMat, list.length);
      const fMesh = new THREE.InstancedMesh(foliage, leafMats[type], list.length);
      fMesh.customDepthMaterial = leafDepth[type];
      wMesh.name = 'Trees-' + type + '-wood';
      fMesh.name = 'Trees-' + type + '-leaf';
      for (let n = 0; n < list.length; n++) {
        const k = list[n];
        const u = t.pos[k * 3] / (W - 1);
        const v = t.pos[k * 3 + 1] / (H - 1);
        const y = t.pos[k * 3 + 2] * HS;
        dummy.position.set((u - 0.5) * S, y - 0.12, (v - 0.5) * S);
        const s = 1.05;
        dummy.scale.set(t.scale[k * 3] * s, t.scale[k * 3 + 1] * s, t.scale[k * 3 + 2] * s);
        dummy.rotation.set(0, (k * 2.399963) % (Math.PI * 2), 0);
        dummy.updateMatrix();
        wMesh.setMatrixAt(n, dummy.matrix);
        fMesh.setMatrixAt(n, dummy.matrix);
        color.setRGB(t.color[k * 3], t.color[k * 3 + 1], t.color[k * 3 + 2]);
        fMesh.setColorAt(n, color);
      }
      wMesh.instanceMatrix.needsUpdate = true;
      fMesh.instanceMatrix.needsUpdate = true;
      if (fMesh.instanceColor) fMesh.instanceColor.needsUpdate = true;
      wMesh.castShadow = true; wMesh.receiveShadow = false; wMesh.frustumCulled = false;
      fMesh.castShadow = true; fMesh.receiveShadow = false; fMesh.frustumCulled = false;
      this.vegetation.push(wMesh, fMesh);
      this.root.add(wMesh, fMesh);
      treeCount += list.length;
    }
    this.treeCount = treeCount;

    // 灌木：几簇交叉叶片片拼成丛状（贴叶片贴图，叶形轮廓而非圆球）
    const b = biomes.bushes;
    if (b.count) {
      const brng = mulberry32(555);
      const bparts = [];
      const clumps = 4;
      for (let c = 0; c < clumps; c++) {
        const cx = (brng() - 0.5) * 0.5;
        const cy = (brng() - 0.2) * 0.4;
        const cz = (brng() - 0.5) * 0.5;
        const size = 0.5 + brng() * 0.3;
        for (let p = 0; p < 3; p++) {
          const g = new THREE.PlaneGeometry(size, size);
          g.rotateY((p / 3) * Math.PI);
          g.translate(cx, cy, cz);
          bparts.push(tint(g, LEAF_COLOR));
        }
      }
      const geo = mergeGeometries(bparts, false);
      geo.computeVertexNormals();
      const mat = new THREE.MeshStandardMaterial({
        color: 0xffffff, vertexColors: true, map: texLeaf, alphaTest: 0.5,
        transparent: false, roughness: 1, side: THREE.DoubleSide,
      });
      const mesh = new THREE.InstancedMesh(geo, mat, b.count);
      mesh.customDepthMaterial = new THREE.MeshDepthMaterial({
        depthPacking: THREE.RGBADepthPacking, map: texLeaf, alphaTest: 0.5,
      });
      mesh.name = 'Bushes';
      for (let k = 0; k < b.count; k++) {
        const u = b.pos[k * 3] / (W - 1);
        const v = b.pos[k * 3 + 1] / (H - 1);
        dummy.position.set((u - 0.5) * S, b.pos[k * 3 + 2] * HS + 0.15, (v - 0.5) * S);
        dummy.scale.set(b.scale[k * 3] * 1.3, b.scale[k * 3 + 1] * 1.1, b.scale[k * 3 + 2] * 1.3);
        dummy.rotation.set(0, k * 1.77, 0);
        dummy.updateMatrix();
        mesh.setMatrixAt(k, dummy.matrix);
        color.setRGB(b.color[k * 3], b.color[k * 3 + 1], b.color[k * 3 + 2]);
        mesh.setColorAt(k, color);
      }
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      mesh.castShadow = true; mesh.frustumCulled = false;
      this.vegetation.push(mesh);
      this.root.add(mesh);
    }

    // 碎石
    const r = biomes.rocks;
    if (r.count) {
      const geo = new THREE.DodecahedronGeometry(0.55, 0);
      const mat = new THREE.MeshStandardMaterial({ color: 0x8a857c, roughness: 1, flatShading: true });
      const mesh = new THREE.InstancedMesh(geo, mat, r.count);
      mesh.name = 'Rocks';
      for (let k = 0; k < r.count; k++) {
        const u = r.pos[k * 3] / (W - 1);
        const v = r.pos[k * 3 + 1] / (H - 1);
        dummy.position.set((u - 0.5) * S, r.pos[k * 3 + 2] * HS + 0.1, (v - 0.5) * S);
        const s = r.scale[k];
        dummy.scale.set(s, s * 0.62, s * 0.9);
        dummy.rotation.set(k * 0.7, k * 1.3, k * 0.4);
        dummy.updateMatrix();
        mesh.setMatrixAt(k, dummy.matrix);
      }
      mesh.instanceMatrix.needsUpdate = true;
      mesh.frustumCulled = false;
      this.vegetation.push(mesh);
      this.root.add(mesh);
    }
  }

  /** 大气参数（角度 / 雾 / 云 / 泛光 / 体积光） */
  setAtmosphere(a = {}) {
    const prev = this.atmo || {};
    this.atmo = { ...prev, ...a };
    const sun = typeof a.sun === 'number' ? a.sun : prev.sun ?? 28;
    const haze = typeof a.haze === 'number' ? a.haze : prev.haze ?? 0.8;
    const cloud = typeof a.cloud === 'number' ? a.cloud : prev.cloud ?? 0.6;
    const bloom = a.bloom ?? prev.bloom ?? true;
    const godrays = a.godrays ?? prev.godrays ?? false;
    const waters = a.waters ?? prev.waters ?? true;
    const trees = a.trees ?? prev.trees ?? true;

    const elevation = THREE.MathUtils.degToRad(clamp(sun, 2, 85));
    const dir = new THREE.Vector3(Math.cos(elevation) * 0.72, Math.sin(elevation), Math.cos(elevation) * 0.48).normalize();
    this.sun.position.copy(dir).multiplyScalar(180);
    this.sun.target.position.set(0, 0, 0);
    const warmth = 1 - saturate(sun / 70);
    const sunColor = new THREE.Color().setRGB(1.0, 0.92 - warmth * 0.10, 0.84 - warmth * 0.18);
    this.sun.color.copy(sunColor);
    this.sun.intensity = 1.45 + (sun / 85) * 1.25;
    this.hemi.intensity = 0.72 + (sun / 85) * 0.55;

    const top = new THREE.Color().setRGB(0.14 + warmth * 0.10, 0.34 + warmth * 0.02, 0.58 - warmth * 0.10);
    const horizon = new THREE.Color().setRGB(0.72 + warmth * 0.12, 0.78 - warmth * 0.06, 0.80 - warmth * 0.18);
    this.skyMat.uniforms.uTop.value.copy(top);
    this.skyMat.uniforms.uHorizon.value.copy(horizon);
    this.skyMat.uniforms.uGround.value.setRGB(0.52, 0.57 - warmth * 0.04, 0.54 - warmth * 0.12);
    this.skyMat.uniforms.uSunDir.value.copy(dir);
    this.skyMat.uniforms.uSunColor.value.copy(sunColor);
    this.skyMat.uniforms.uSunElevation.value = Math.sin(elevation);
    this.skyMat.uniforms.uCloud.value = cloud;

    const density = 0.0011 + haze * 0.0020;
    const fogColor = horizon.clone().lerp(new THREE.Color(0x6f8fa8), 0.55);
    this.scene.fog.density = density;
    this.scene.fog.color.copy(fogColor);
    if (this.waterMat) {
      this.waterMat.uniforms.uFogColor.value.copy(fogColor);
      this.waterMat.uniforms.uFogDensity.value = density;
      this.waterMat.uniforms.uSky.value.setRGB(0.30, 0.50, 0.70);
      this.waterMat.uniforms.uSunDir.value.copy(dir);
      this.waterMat.uniforms.uSunColor.value.copy(sunColor);
      this.waterMat.uniforms.uSunGlow.value = bloom ? 1.25 : 0.85;
      this.waterMat.uniforms.uWave.value = waters ? 1 : 0.08;
    }
    this.renderer.toneMappingExposure = bloom ? 1.18 + warmth * 0.10 : 1.02;
    this.glowMat.opacity = godrays ? 0.34 + warmth * 0.24 : 0;
    this.glow.position.copy(dir).multiplyScalar(330);
    this.glow.visible = godrays;
    this.sun.castShadow = this.layers.relief !== false;

    this.layers.water = waters;
    this.layers.forest = trees;
    this.applyLayers();
  }

  setLayer(name, visible) {
    this.layers[name] = visible;
    this.applyLayers();
  }

  applyLayers() {
    if (this.terrainMesh) {
      this.terrainMesh.visible = this.layers.terrain !== false;
      if (this.terrainMat) {
        this.terrainMat.map = this.layers.snow === false ? this.albedoNoSnowTex : this.albedoTex;
        this.terrainMat.needsUpdate = true;
      }
    }
    if (this.waterMesh) this.waterMesh.visible = this.layers.water !== false;
    if (this.outerSea) this.outerSea.visible = this.layers.water !== false;
    for (const m of this.vegetation) m.visible = this.layers.forest !== false;
    this.sun.castShadow = this.layers.relief !== false;
  }

  setWireframe(on) {
    if (this.terrainMat) this.terrainMat.wireframe = on;
  }

  setNormals(on) {
    this.showNormals = on;
    if (this.terrainMesh) this.terrainMesh.material = on ? this.normalMat : this.terrainMat;
  }

  setVoxel(on) {
    if (this.terrainMat) {
      this.terrainMat.flatShading = on;
      this.terrainMat.needsUpdate = true;
    }
  }

  resetView() {
    this.camera.position.set(78, 52, 92);
    this.controls.target.set(0, 5, 0);
    this.controls.update();
  }

  orbit(dx, dy) {
    const off = this.camera.position.clone().sub(this.controls.target);
    const sph = new THREE.Spherical().setFromVector3(off);
    sph.theta -= dx;
    sph.phi = clamp(sph.phi - dy, 0.08, Math.PI * 0.485);
    off.setFromSpherical(sph);
    this.camera.position.copy(this.controls.target).add(off);
    this.controls.update();
  }

  screenshot() {
    this.renderer.render(this.scene, this.camera);
    return this.renderer.domElement.toDataURL('image/png');
  }

  getStats() {
    let verts = 0;
    let tris = 0;
    let trees = this.treeCount || 0;
    if (this.terrainMesh) {
      verts += this.terrainMesh.geometry.attributes.position.count;
      tris += this.terrainMesh.geometry.index.count / 3;
    }
    if (this.waterMesh) {
      verts += this.waterMesh.geometry.attributes.position.count;
      tris += this.waterMesh.geometry.index.count / 3;
    }
    for (const m of this.vegetation) {
      if (/Trees|Bushes|Rocks/.test(m.name) && m.count) {
        const g = m.geometry;
        const t = g.index ? g.index.count / 3 : g.attributes.position.count / 3;
        tris += t * m.count;
      }
    }
    return { verts: Math.round(verts), tris: Math.round(tris), trees };
  }

  /** 导出用的场景对象（不含天空/灯光） */
  exportRoot() { return this.root; }

  disposeWorld() {
    for (const child of [...this.root.children]) {
      this.root.remove(child);
      if (child.geometry) child.geometry.dispose();
      if (child.material && child.material !== this.normalMat) {
        const mats = Array.isArray(child.material) ? child.material : [child.material];
        for (const m of mats) {
          if (child.name === 'OuterSea' && m.uniforms && m.uniforms.uMaskTex) {
            m.uniforms.uMaskTex.value.dispose();
          }
          m.dispose();
        }
      }
    }
    if (this.albedoTex) this.albedoTex.dispose();
    if (this.albedoNoSnowTex) this.albedoNoSnowTex.dispose();
    this.vegetation = [];
    this.terrainMesh = null;
    this.waterMesh = null;
    this.outerSea = null;
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this._onResize);
    this.disposeWorld();
    this.controls.dispose();
    this.renderer.dispose();
  }
}

function makeGlowTexture() {
  const size = 128;
  const data = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const dx = (x - size / 2) / (size / 2);
      const dy = (y - size / 2) / (size / 2);
      const d = Math.sqrt(dx * dx + dy * dy);
      const a = Math.pow(Math.max(0, 1 - d), 3.2);
      const i = (y * size + x) * 4;
      data[i] = 255; data[i + 1] = 220; data[i + 2] = 170;
      data[i + 3] = Math.round(a * 255);
    }
  }
  const tex = new THREE.DataTexture(data, size, size, THREE.RGBAFormat, THREE.UnsignedByteType);
  tex.needsUpdate = true;
  return tex;
}
