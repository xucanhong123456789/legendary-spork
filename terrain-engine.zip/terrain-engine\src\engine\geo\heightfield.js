// ============================================================
// heightfield.js - 高程场 + 地貌类别场（引擎的公共数据格式）
// 所有 2D 输入最终都被归一化为这两种平面栅格
// ============================================================

export const CLASS = {
  DEEP: 0,      // 深海
  OCEAN: 1,     // 海洋
  SHALLOW: 2,   // 浅滩 / 礁
  BEACH: 3,     // 沙滩 / 滩涂
  PLAIN: 4,     // 平原（草甸、农田）
  FOREST: 5,    // 温带 / 针阔林
  JUNGLE: 6,    // 热带雨林
  HILL: 7,      // 丘陵 / 缓坡
  MOUNTAIN: 8,  // 山地（草坡、裸岩混合）
  SCREE: 9,     // 裸岩 / 碎石坡 / 岩壁
  SNOW: 10,     // 雪线以上
  RIVER: 11,    // 河道
  LAKE: 12,     // 内陆湖泊
};

export const CLASS_NAMES = [
  '深海', '海洋', '浅滩', '沙滩', '平原', '森林', '雨林',
  '丘陵', '山地', '裸岩', '雪线', '河流', '湖泊',
];

export const CLASS_COUNT = 13;

/** 地貌类别 -> 调色板基色 (sRGB 0-255) */
export const CLASS_COLORS = [
  [ 26,  46,  66], // DEEP
  [ 38,  74,  98], // OCEAN
  [ 78, 116, 122], // SHALLOW
  [204, 190, 152], // BEACH
  [150, 156, 102], // PLAIN
  [ 96, 120,  78], // FOREST
  [ 74, 108,  62], // JUNGLE
  [128, 126,  96], // HILL
  [124, 118, 108], // MOUNTAIN
  [142, 140, 138], // SCREE
  [232, 236, 240], // SNOW
  [ 86, 138, 152], // RIVER
  [ 72, 118, 134], // LAKE
];

/** 水体判定 */
export function isWaterClass(c) {
  return c === CLASS.DEEP || c === CLASS.OCEAN || c === CLASS.SHALLOW ||
    c === CLASS.RIVER || c === CLASS.LAKE;
}

/* ============================================================
   HeightField
   ============================================================ */
export class HeightField {
  constructor(w, h) {
    this.w = w | 0;
    this.h = h | 0;
    this.data = new Float32Array(this.w * this.h);
    this.min = 0;
    this.max = 1;
  }

  get(x, y) {
    x = x < 0 ? 0 : x >= this.w ? this.w - 1 : x;
    y = y < 0 ? 0 : y >= this.h ? this.h - 1 : y;
    return this.data[y * this.w + x];
  }

  set(x, y, v) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    this.data[y * this.w + x] = v;
  }

  /** 双线性采样（像素坐标可为小数） */
  samplePixel(fx, fy) {
    const x0 = Math.max(0, Math.min(this.w - 1, Math.floor(fx)));
    const y0 = Math.max(0, Math.min(this.h - 1, Math.floor(fy)));
    const x1 = Math.min(this.w - 1, x0 + 1);
    const y1 = Math.min(this.h - 1, y0 + 1);
    const tx = Math.min(1, Math.max(0, fx - x0));
    const ty = Math.min(1, Math.max(0, fy - y0));
    const d = this.data;
    const w = this.w;
    const a = d[y0 * w + x0];
    const b = d[y0 * w + x1];
    const c = d[y1 * w + x0];
    const e = d[y1 * w + x1];
    return (a + (b - a) * tx) * (1 - ty) + (c + (e - c) * tx) * ty;
  }

  /** 归一化 UV 采样 [0,1] */
  sampleUV(u, v) {
    return this.samplePixel(u * (this.w - 1), v * (this.h - 1));
  }

  clone() {
    const f = new HeightField(this.w, this.h);
    f.data.set(this.data);
    f.min = this.min;
    f.max = this.max;
    return f;
  }

  fill(v) {
    this.data.fill(v);
    return this;
  }

  /** 归一化到 [0,1] */
  normalize() {
    const d = this.data;
    let mn = Infinity;
    let mx = -Infinity;
    for (let i = 0; i < d.length; i++) {
      const v = d[i];
      if (v < mn) mn = v;
      if (v > mx) mx = v;
    }
    const r = mx - mn || 1;
    for (let i = 0; i < d.length; i++) d[i] = (d[i] - mn) / r;
    this.min = 0;
    this.max = 1;
    return this;
  }
  /** 可分离 3x3 高斯模糊（边缘钳制） */
  blur(passes = 1) {
    const w = this.w;
    const h = this.h;
    const kernel = [0.25, 0.5, 0.25];
    for (let p = 0; p < passes; p++) {
      const src = this.data;
      const tmp = new Float32Array(src.length);
      for (let y = 0; y < h; y++) {
        const row = y * w;
        for (let x = 0; x < w; x++) {
          const xm = x > 0 ? x - 1 : 0;
          const xp = x < w - 1 ? x + 1 : w - 1;
          tmp[row + x] = src[row + xm] * kernel[0] + src[row + x] * kernel[1] + src[row + xp] * kernel[2];
        }
      }
      const dst = new Float32Array(src.length);
      for (let y = 0; y < h; y++) {
        const ym = (y > 0 ? y - 1 : 0) * w;
        const yp = (y < h - 1 ? y + 1 : h - 1) * w;
        const row = y * w;
        for (let x = 0; x < w; x++) {
          dst[row + x] = tmp[ym + x] * kernel[0] + tmp[row + x] * kernel[1] + tmp[yp + x] * kernel[2];
        }
      }
      this.data = dst;
    }
    return this;
  }

  stats() {
    let mn = Infinity;
    let mx = -Infinity;
    let sum = 0;
    const d = this.data;
    for (let i = 0; i < d.length; i++) {
      const v = d[i];
      if (v < mn) mn = v;
      if (v > mx) mx = v;
      sum += v;
    }
    this.min = mn;
    this.max = mx;
    return { min: mn, max: mx, mean: sum / d.length };
  }

  /** 输出灰度 ImageData（用于高度图导出 / 预览） */
  toImageData() {
    const img = new ImageData(this.w, this.h);
    const px = img.data;
    const d = this.data;
    for (let i = 0, n = d.length; i < n; i++) {
      const g = Math.round(Math.max(0, Math.min(1, d[i])) * 255);
      px[i * 4] = g;
      px[i * 4 + 1] = g;
      px[i * 4 + 2] = g;
      px[i * 4 + 3] = 255;
    }
    return img;
  }
}

/* ============================================================
   ClassField
   ============================================================ */
export class ClassField {
  constructor(w, h) {
    this.w = w | 0;
    this.h = h | 0;
    this.data = new Uint8Array(this.w * this.h);
  }

  get(x, y) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return 0;
    return this.data[y * this.w + x];
  }

  set(x, y, v) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    this.data[y * this.w + x] = v | 0;
  }

  clone() {
    const c = new ClassField(this.w, this.h);
    c.data.set(this.data);
    return c;
  }
}
