import { sampleField, SAMPLE_PALETTE } from '../src/demo/terrainSamples.js';
import { read2DMap, SEMANTIC_PALETTE } from '../src/engine/terrain/readMap.js';

const W = 128, H = 128;
function rgbaFor(kind) {
  const p = new Uint8ClampedArray(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const f = sampleField(kind, x / (W - 1), y / (H - 1));
    const c = SAMPLE_PALETTE[f.cls] || SAMPLE_PALETTE.plain;
    const o = (y * W + x) * 4;
    p[o] = c[0]; p[o + 1] = c[1]; p[o + 2] = c[2]; p[o + 3] = 255;
  }
  return p;
}
for (const kind of ['fjord', 'delta', 'continent', 'island']) {
  const px = rgbaFor(kind);
  for (const mode of ['semantic', 'height', 'hybrid', 'painted']) {
    const r = read2DMap(px, W, H, mode, { relief: 1, detail: 1 });
    let mn = 1, mx = 0, sum = 0, sea = 0, bad = 0;
    for (let i = 0; i < r.height.length; i++) {
      const v = r.height[i];
      if (!Number.isFinite(v)) bad++;
      mn = Math.min(mn, v); mx = Math.max(mx, v); sum += v;
      if (v < 0.18) sea++;
    }
    console.log(kind.padEnd(10), mode.padEnd(9), 'min', mn.toFixed(3), 'max', mx.toFixed(3), 'mean', (sum / r.height.length).toFixed(3), 'sea%', (100 * sea / r.height.length).toFixed(1), 'NaN', bad);
    if (bad || mx < 0.3) throw new Error('bad field ' + kind + '/' + mode);
  }
}
console.log('PALETTE', SEMANTIC_PALETTE.length, 'classes');
console.log('PROBE PASS');
