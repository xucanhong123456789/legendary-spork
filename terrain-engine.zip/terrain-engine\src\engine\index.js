// ============================================================
// Terrain Weaver - 2D 地图 -> 3D 地形重建引擎 · 公共 API
// 桌面工具可只导入算法核心（不含 three），也可直接挂载 TerrainViewer。
// ============================================================

// 算法核心（纯数据，可放进 Web Worker）
export { read2DMap, SEMANTIC_PALETTE, CLASS_NAMES, CLASS_ELEVATION, WET_CLASSES, DATUM, SEA } from './terrain/readMap.js';
export { boxBlur, distanceField, slopeField, nearestClass } from './terrain/readMap.js';
export { analyzeHydrology, flowToImageData } from './terrain/hydrology.js';
export { hydraulicErosion, carveRiverValleys, thermalErosion, coastalSmoothing, sculptTerrain } from './terrain/erosion.js';
export { buildBiomes, BIOME_PRESETS, BAND, BAND_NAMES } from './terrain/biome.js';
export { buildTerrain, DEFAULT_OPTIONS, heightAt, recommendMeshSegments } from './terrain/terrain.js';
export { HeightField, ClassField, CLASS, CLASS_NAMES as CLASS_CN, CLASS_COLORS, CLASS_COUNT } from './geo/heightfield.js';
export * from './geo/noise.js';

// 渲染与导出（浏览器环境）
export { TerrainViewer } from './render/viewer.js';
export { makeSkyMaterial, makeWaterMaterial } from './render/shaders.js';
export * from './export/exporters.js';
