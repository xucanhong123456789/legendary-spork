// ============================================================
// erosion.js - 地貌雕刻
// 1) 粒子水力侵蚀：雨滴顺坡流动，按携沙能力侵蚀/沉积，形成沟壑与冲积扇
// 2) 河道下切：按汇流强度把河床切成 V 型谷，两岸形成天然堤
// 3) 热侵蚀：超过休止角的陡崖塌落成碎石坡
// 4) 海岸磨蚀：浪击带压平并堆出沙滩
// ============================================================
import { clamp, saturate, smoothstep, mulberry32, fbm2 } from '../geo/noise.js';
import { boxBlur } from './readMap.js';

/** 双线性采样高度 + 梯度 */
function sampleHG(dem, W, H, px, py) {
  const x0 = Math.floor(px);
  const y0 = Math.floor(py);
  const tx = px - x0;
  const ty = py - y0;
  const cx0 = clamp(x0, 0, W - 1);
  const cx1 = clamp(x0 + 1, 0, W - 1);
  const cy0 = clamp(y0, 0, H - 1);
  const cy1 = clamp(y0 + 1, 0, H - 1);
  const h00 = dem[cy0 * W + cx0];
  const h10 = dem[cy0 * W + cx1];
  const h01 = dem[cy1 * W + cx0];
  const h11 = dem[cy1 * W + cx1];
  const gx = (h10 - h00) * (1 - ty) + (h11 - h01) * ty;
  const gy = (h01 - h00) * (1 - tx) + (h11 - h10) * tx;
  const h = h00 * (1 - tx) * (1 - ty) + h10 * tx * (1 - ty) + h01 * (1 - tx) * ty + h11 * tx * ty;
  return { h, gx, gy, x0, y0, tx, ty };
}

/** 预计算侵蚀刷（半径内按距离加权） */
function makeBrush(radius) {
  const off = [];
  let total = 0;
  for (let y = -radius; y <= radius; y++) {
    for (let x = -radius; x <= radius; x++) {
      const d = Math.sqrt(x * x + y * y);
      if (d > radius) continue;
      const w = 1 - d / (radius + 0.5);
      off.push({ x, y, w });
      total += w;
    }
  }
  for (const o of off) o.w /= total;
  return off;
}

/**
 * 粒子水力侵蚀（原地修改 dem）
 * @param {Float32Array} dem
 * @param {object} opt { W,H, strength, seed, seaLevel, water }
 */
export function hydraulicErosion(dem, opt) {
  const W = opt.W;
  const H = opt.H;
  const N = W * H;
  const strength = clamp(opt.strength ?? 0.7, 0, 1);
  const seaLevel = opt.seaLevel ?? 0.18;
  const water = opt.water;
  const rnd = mulberry32((opt.seed | 0) || 2024);
  const brush = makeBrush(Math.max(2, Math.round(Math.min(W, H) / 180)));
  const droplets = Math.round(N * (0.035 + strength * 0.16));
  const maxLife = 34;
  const inertia = 0.34;
  const capacityFactor = 3.4;
  const minCapacity = 0.008;
  const erodeSpeed = 0.28 + strength * 0.34;
  const depositSpeed = 0.22;
  const evaporate = 0.028;
  const gravity = 5.0;
  const scale = 0.9; // 0..1 高程单位下的侵蚀幅度系数

  for (let d = 0; d < droplets; d++) {
    let px = rnd() * (W - 2) + 1;
    let py = rnd() * (H - 2) + 1;
    let dx = 0;
    let dy = 0;
    let speed = 1;
    let wet = 1;
    let sediment = 0;

    for (let life = 0; life < maxLife; life++) {
      const nodeX = Math.floor(px);
      const nodeY = Math.floor(py);
      const s = sampleHG(dem, W, H, px, py);
      // 水下不做侵蚀（海床由海浪磨蚀处理）
      if (s.h < seaLevel - 0.004) break;

      dx = dx * inertia - s.gx * (1 - inertia);
      dy = dy * inertia - s.gy * (1 - inertia);
      const len = Math.hypot(dx, dy);
      if (len < 1e-6) break;
      dx /= len;
      dy /= len;
      px += dx;
      py += dy;
      if (px < 1 || py < 1 || px >= W - 2 || py >= H - 2) break;

      const s2 = sampleHG(dem, W, H, px, py);
      const dh = s2.h - s.h;
      const capacity = Math.max(-dh * speed * wet * capacityFactor, minCapacity) * scale;

      if (sediment > capacity || dh > 0) {
        // 沉积：爬坡或流速下降时把泥沙卸下
        const amount = dh > 0
          ? Math.min(dh, sediment)
          : (sediment - capacity) * depositSpeed;
        sediment -= amount;
        const i0 = clamp(nodeY, 0, H - 1) * W + clamp(nodeX, 0, W - 1);
        dem[i0] += amount * (1 - s.tx) * (1 - s.ty);
        const i1 = i0 + 1;
        if (i1 < N) dem[i1] += amount * s.tx * (1 - s.ty);
        const i2 = i0 + W;
        if (i2 < N) dem[i2] += amount * (1 - s.tx) * s.ty;
        const i3 = i2 + 1;
        if (i3 < N) dem[i3] += amount * s.tx * s.ty;
      } else {
        // 侵蚀：从刷子覆盖的像元按比例挖走，受局部落差限制
        const amount = Math.min((capacity - sediment) * erodeSpeed, -dh) * scale;
        let taken = 0;
        const bx = Math.floor(px);
        const by = Math.floor(py);
        for (const o of brush) {
          const x = bx + o.x;
          const y = by + o.y;
          if (x < 0 || y < 0 || x >= W || y >= H) continue;
          const i = y * W + x;
          const take = Math.min(dem[i] - seaLevel * 0.25, amount * o.w);
          if (take > 0) { dem[i] -= take; taken += take; }
        }
        sediment += taken;
      }
      speed = Math.sqrt(Math.max(0, speed * speed - dh * gravity));
      wet *= 1 - evaporate;
      if (wet < 0.02) break;
    }
  }
  void water;
  return dem;
}

/** 河道下切 + 天然堤：让河流真正嵌进地形，而不是浮在表面 */
export function carveRiverValleys(dem, hydro, opt) {
  const W = opt.W;
  const H = opt.H;
  const N = W * H;
  const cut = clamp(opt.riverCut ?? 0.8, 0, 1);
  const seaLevel = opt.seaLevel ?? 0.18;
  if (cut <= 0) return dem;

  // 用河宽场做一次扩散，得到「河谷影响范围」
  const influence = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    if (hydro.river[i] > 0) influence[i] = hydro.river[i];
  }
  const blurred = boxBlur(influence, W, H, Math.max(2, Math.round(Math.min(W, H) / 90)), 2);
  for (let y = 1; y < H - 1; y++) {
    for (let x = 1; x < W - 1; x++) {
      const i = y * W + x;
      if (hydro.ocean[i]) continue;
      const core = hydro.river[i];
      const halo = blurred[i];
      if (core <= 0 && halo < 0.012) continue;
      // 谷底深切，越靠下游越宽；水面以下不切
      const depth = Math.min(0.055, (0.010 + core * 0.052) * cut);
      const floor = seaLevel - 0.012;
      const target = Math.max(floor, dem[i] - depth * smoothstep(0, 0.5, core + halo * 0.6));
      dem[i] = target;
      // 天然堤：紧邻河道的外侧略微堆高
      if (core <= 0 && halo > 0.05 && halo < 0.34) {
        dem[i] += halo * 0.010 * cut;
      }
    }
  }
  return dem;
}

/** 热侵蚀：超过休止角的坡面塌落，避免针状尖峰 */
export function thermalErosion(dem, W, H, iterations = 5, talus = 0.011, amount = 0.35) {
  const N = W * H;
  const delta = new Float32Array(N);
  const nb = [1, -1, W, -W];
  for (let it = 0; it < iterations; it++) {
    delta.fill(0);
    for (let y = 1; y < H - 1; y++) {
      for (let x = 1; x < W - 1; x++) {
        const i = y * W + x;
        let lowest = -1;
        let maxDiff = talus;
        for (let d = 0; d < 4; d++) {
          const j = i + nb[d];
          const diff = dem[i] - dem[j];
          if (diff > maxDiff) { maxDiff = diff; lowest = j; }
        }
        if (lowest >= 0) {
          const move = (maxDiff - talus) * amount * 0.25;
          delta[i] -= move;
          delta[lowest] += move;
        }
      }
    }
    for (let i = 0; i < N; i++) dem[i] += delta[i];
  }
  return dem;
}

/** 海岸磨蚀：浪击带压平海床、在岸线堆出沙滩 */
export function coastalSmoothing(dem, W, H, seaLevel, water) {
  const N = W * H;
  const shore = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    const d = Math.abs(dem[i] - seaLevel);
    shore[i] = d < 0.035 ? 1 - d / 0.035 : 0;
  }
  const blurred = boxBlur(shore, W, H, 2, 1);
  const tmp = Float32Array.from(dem);
  for (let i = 0; i < N; i++) {
    if (blurred[i] < 0.02) continue;
    const t = blurred[i] * 0.45;
    // 海床一侧轻微淤平
    if (dem[i] < seaLevel) dem[i] = dem[i] * (1 - t) + (seaLevel - 0.026) * t;
  }
  void tmp;
  void water;
  return dem;
}

/** 组合雕刻流程 */
export function sculptTerrain(dem, hydro, opt) {
  const p = opt || {};
  const W = p.W;
  const H = p.H;
  hydraulicErosion(dem, {
    W, H, strength: p.erosion ?? 0.7, seed: p.seed,
    seaLevel: p.seaLevel, water: p.water,
  });
  carveRiverValleys(dem, hydro, {
    W, H, riverCut: p.riverCut ?? 0.8, seaLevel: p.seaLevel,
  });
  thermalErosion(dem, W, H, 4, 0.013, 0.32);
  coastalSmoothing(dem, W, H, p.seaLevel ?? 0.18, p.water);
  // 侵蚀可能把局部推到 [0,1] 之外
  for (let i = 0; i < dem.length; i++) dem[i] = saturate(dem[i]);
  return dem;
}
