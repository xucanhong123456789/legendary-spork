// ============================================================
// shaders.js - 大气天空 + 水面着色器
// 远山泛蓝、日照金边、水面菲涅尔反射、波光、岸边泡沫
// ============================================================
import * as THREE from 'three';

export const SKY_VERT = `
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

export const SKY_FRAG = `
precision highp float;
varying vec3 vDir;
uniform vec3 uTop;
uniform vec3 uHorizon;
uniform vec3 uGround;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunElevation;
uniform float uCloud;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}
float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
             mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p) {
  float s = 0.0;
  float a = 0.5;
  for (int i = 0; i < 5; i++) {
    s += noise(p) * a;
    p *= 2.03;
    a *= 0.5;
  }
  return s;
}

void main() {
  vec3 d = normalize(vDir);
  float up = clamp(d.y, -1.0, 1.0);
  float t = pow(clamp(up * 1.35 + 0.10, 0.0, 1.0), 0.62);
  vec3 col = mix(uHorizon, uTop, t);
  // 地平线以下渐入地面雾色
  col = mix(uGround, col, smoothstep(-0.16, 0.02, up));

  // 太阳盘 + 大气辉光
  float sd = max(dot(d, normalize(uSunDir)), 0.0);
  float glow = pow(sd, 90.0) * 0.85 + pow(sd, 9.0) * 0.20;
  col += uSunColor * glow * (0.45 + 0.55 * smoothstep(-0.05, 0.30, uSunElevation));
  float disk = smoothstep(0.99965, 0.99992, sd);
  col += uSunColor * disk * 2.2;

  // 高层云：把方向投影到水平面，做低频 fbm
  if (up > 0.015) {
    vec2 cp = d.xz / max(up + 0.18, 0.22);
    float n = fbm(cp * 1.35 + vec2(0.0, 0.0));
    float n2 = fbm(cp * 3.1 + vec2(4.7, 1.3));
    float cloud = smoothstep(0.50, 0.74, n * 0.72 + n2 * 0.28) * uCloud;
    cloud *= smoothstep(0.02, 0.28, up);
    vec3 cloudCol = mix(vec3(0.58, 0.62, 0.66), vec3(0.98, 0.95, 0.88), 0.55 + 0.45 * sd);
    col = mix(col, cloudCol, cloud * 0.62);
  }
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

export function makeSkyMaterial() {
  return new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      uTop: { value: new THREE.Color(0x2e5c86) },
      uHorizon: { value: new THREE.Color(0xb9cbd0) },
      uGround: { value: new THREE.Color(0x8d9a90) },
      uSunDir: { value: new THREE.Vector3(0.6, 0.35, 0.4).normalize() },
      uSunColor: { value: new THREE.Color(0xffd9a0) },
      uSunElevation: { value: 0.5 },
      uCloud: { value: 0.6 },
      uTime: { value: 0 },
    },
    vertexShader: SKY_VERT,
    fragmentShader: SKY_FRAG,
  });
}

/* ---------------- 水面 ---------------- */

export const WATER_VERT = `
attribute float aMask;
attribute float aDepth;
varying vec2 vUv;
varying vec3 vWorld;
varying float vMask;
varying float vDepth;
void main() {
  vUv = uv;
  vMask = aMask;
  vDepth = aDepth;
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

export const WATER_FRAG = `
precision highp float;
varying vec2 vUv;
varying vec3 vWorld;
varying float vMask;
varying float vDepth;
uniform sampler2D uMaskTex;
uniform vec2 uTexel;
uniform vec3 uDeep;
uniform vec3 uShallow;
uniform vec3 uSky;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uTime;
uniform float uWave;
uniform float uFoam;
uniform float uOpacity;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform float uSunGlow;

float waveHeight(vec2 p, float t) {
  float a = sin(p.x * 0.62 + t * 1.15) * 0.55;
  float b = sin(p.y * 0.87 - t * 0.93 + p.x * 0.21) * 0.32;
  float c = sin((p.x + p.y) * 1.93 + t * 1.75) * 0.13;
  float d = sin(p.x * 3.7 - p.y * 2.9 - t * 2.3) * 0.06;
  return a + b + c + d;
}

void main() {
  if (vMask < 0.35) discard;
  vec2 m = vec2(texture2D(uMaskTex, vUv).r);
  if (m.x < 0.12) discard;

  vec2 p = vWorld.xz;
  float t = uTime;
  float e = 0.055;
  float h = waveHeight(p, t);
  float hx = waveHeight(p + vec2(e, 0.0), t);
  float hz = waveHeight(p + vec2(0.0, e), t);
  vec3 n = normalize(vec3(-(hx - h) / e * 0.06 * uWave, 1.0, -(hz - h) / e * 0.06 * uWave));

  vec3 V = normalize(cameraPosition - vWorld);
  vec3 L = normalize(uSunDir);
  float ndv = max(dot(n, V), 0.0);
  float fres = pow(1.0 - ndv, 3.2);

  // 深浅：只做轻微色调变化，避免海床分区在开阔海面形成直线色块
  float shallow = 0.10 + 0.26 * (1.0 - clamp(vDepth * 9.0, 0.0, 1.0));
  vec3 base = mix(uDeep, uShallow, shallow);
  // 波峰微微提亮
  base *= 1.02 + h * 0.055 * uWave;

  vec3 col = mix(base, uSky, fres * 0.30);
  vec3 H = normalize(L + V);
  float spec = pow(max(dot(n, H), 0.0), 120.0);
  float sparkle = pow(max(dot(n, H), 0.0), 620.0) * 1.2;
  col += uSunColor * (spec * 0.55 + sparkle * 0.85) * uSunGlow;

  // 岸边泡沫：mask 的边缘梯度
  float l = texture2D(uMaskTex, vUv - vec2(uTexel.x, 0.0)).r;
  float r = texture2D(uMaskTex, vUv + vec2(uTexel.x, 0.0)).r;
  float u = texture2D(uMaskTex, vUv + vec2(0.0, uTexel.y)).r;
  float d = texture2D(uMaskTex, vUv - vec2(0.0, uTexel.y)).r;
  float edge = clamp(abs(l - r) + abs(u - d), 0.0, 1.0);
  float foam = smoothstep(0.22, 0.95, edge) * uFoam;
  foam += smoothstep(0.75, 0.98, sin(p.x * 5.5 + p.y * 3.7 + t * 2.2) * 0.5 + 0.5) * shallow * 0.15 * uFoam;
  col = mix(col, vec3(0.90, 0.94, 0.92), clamp(foam, 0.0, 0.72));

  // 与场景 FogExp2 一致的距离雾，让远海融入天际
  float dist = length(cameraPosition - vWorld);
  float fogF = 1.0 - exp(-uFogDensity * uFogDensity * dist * dist);
  col = mix(col, uFogColor, clamp(fogF * 0.55, 0.0, 0.62));

  gl_FragColor = vec4(col, uOpacity);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

export function makeWaterMaterial(uniforms = {}) {
  return new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    uniforms: {
      uMaskTex: { value: null },
      uTexel: { value: new THREE.Vector2(1 / 256, 1 / 256) },
      uDeep: { value: new THREE.Color(0x0e3557) },
      uShallow: { value: new THREE.Color(0x3c96ab) },
      uSky: { value: new THREE.Color(0x74a8c8) },
      uSunDir: { value: new THREE.Vector3(0.6, 0.35, 0.4).normalize() },
      uSunColor: { value: new THREE.Color(0xffe0ae) },
      uTime: { value: 0 },
      uWave: { value: 1 },
      uFoam: { value: 1 },
      uOpacity: { value: 0.97 },
      uFogColor: { value: new THREE.Color(0xb9cbd0) },
      uFogDensity: { value: 0.0026 },
      uSunGlow: { value: 1 },
      ...uniforms,
    },
    vertexShader: WATER_VERT,
    fragmentShader: WATER_FRAG,
  });
}
