// ============================================================
// exporters.js - 交付格式
// GLB（地形 + 水面 + 实例化植被）/ 高度图 PNG / 地貌分层 PNG
// / 浮点高度场 BIN / 场景 JSON
// ============================================================
import * as THREE from 'three';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { CLASS_COLORS } from '../geo/heightfield.js';

function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function downloadCanvas(canvas, filename) {
  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      if (blob) saveBlob(blob, filename);
      resolve(blob);
    }, 'image/png');
  });
}

/** 高程场 -> 8bit 灰度 PNG（同时保留可选的水面掩膜叠加） */
export function heightToCanvas(result, overlayWater = false) {
  const { W, H, dem, hydro } = result;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const ctx = c.getContext('2d');
  const img = ctx.createImageData(W, H);
  for (let i = 0; i < W * H; i++) {
    const g = Math.round(Math.max(0, Math.min(1, dem[i])) * 255);
    const o = i * 4;
    if (overlayWater && hydro.waterMask[i]) {
      img.data[o] = 40;
      img.data[o + 1] = 96;
      img.data[o + 2] = 140;
    } else {
      img.data[o] = g;
      img.data[o + 1] = g;
      img.data[o + 2] = g;
    }
    img.data[o + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

/** 生态带 / 类别分层图 */
export function classToCanvas(result) {
  const { W, H, biomes, hydro } = result;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const ctx = c.getContext('2d');
  const img = ctx.createImageData(W, H);
  const bandColors = [
    [30, 70, 110], [216, 202, 162], [96, 118, 88], [140, 154, 100],
    [82, 108, 70], [58, 92, 68], [128, 138, 106], [152, 156, 112],
    [122, 116, 110], [236, 240, 242],
  ];
  for (let i = 0; i < W * H; i++) {
    const o = i * 4;
    let col = bandColors[biomes.band[i]] || CLASS_COLORS[4];
    if (hydro.waterMask[i] === 3) col = [86, 138, 152];
    else if (hydro.waterMask[i] === 2) col = [72, 118, 134];
    else if (hydro.waterMask[i] === 1) col = [30, 70, 110];
    img.data[o] = col[0];
    img.data[o + 1] = col[1];
    img.data[o + 2] = col[2];
    img.data[o + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

/** 原始 float32 高度场（小端，行优先），供 Unity / Unreal / WorldMachine 读取 */
export function exportHeightRaw(result, filename = 'heightfield_f32.bin') {
  const buf = new ArrayBuffer(result.dem.length * 4 + 12);
  const view = new DataView(buf);
  view.setUint32(0, result.W, true);
  view.setUint32(4, result.H, true);
  view.setFloat32(8, result.stats.seaLevel, true);
  new Float32Array(buf, 12).set(result.dem);
  saveBlob(new Blob([buf], { type: 'application/octet-stream' }), filename);
}

/** 场景 JSON：参数、统计、水系、生态带、植被点（可复现） */
export function exportSceneJSON(result, filename = 'terrain_scene.json') {
  const t = result.biomes.trees;
  const treeSample = [];
  const stride = Math.max(1, Math.ceil(t.count / 4000));
  for (let k = 0; k < t.count; k += stride) {
    treeSample.push([
      +t.pos[k * 3].toFixed(2), +t.pos[k * 3 + 1].toFixed(2),
      +t.pos[k * 3 + 2].toFixed(4), t.type[k],
    ]);
  }
  const data = {
    generator: 'Terrain Weaver / 2D-to-3D Reconstruction Engine',
    version: '0.1.0',
    grid: { width: result.W, height: result.H, worldSize: 120, heightScale: 26 },
    options: result.options,
    stats: result.stats,
    hydrology: result.hydro.stats,
    ecosystem: {
      preset: result.biomes.preset,
      snowLine: result.biomes.snowLine,
      bandCounts: result.biomes.stats.bands,
    },
    vegetation: { treeCount: t.count, sampleStride: stride, samples: treeSample },
  };
  saveBlob(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), filename);
  return data;
}

/**
 * 导出 GLB。ShaderMaterial 无法直接写入 glTF，
 * 因此水面用等价的 MeshPhysicalMaterial 替换，地形与植被保持原状。
 */
export function exportGLB(viewer, result, filename = 'terrain_world.glb', includeVegetation = true) {
  return new Promise((resolve, reject) => {
    const group = new THREE.Group();
    group.name = 'TerrainWorld';

    if (viewer.terrainMesh && viewer.terrainMesh.visible) {
      const mat = viewer.terrainMat.clone();
      mat.wireframe = false;
      const mesh = new THREE.Mesh(viewer.terrainMesh.geometry, mat);
      mesh.name = 'Terrain';
      group.add(mesh);
    }
    if (viewer.waterMesh && viewer.waterMesh.visible) {
      const mat = new THREE.MeshPhysicalMaterial({
        color: 0x3d7f96,
        roughness: 0.16,
        metalness: 0.08,
        transparent: true,
        opacity: 0.78,
        side: THREE.DoubleSide,
      });
      const mesh = new THREE.Mesh(viewer.waterMesh.geometry, mat);
      mesh.name = 'Water';
      group.add(mesh);
    }
    if (includeVegetation) {
      for (const m of viewer.vegetation) {
        if (m.visible && m.count) group.add(m.clone());
      }
    }

    const exporter = new GLTFExporter();
    exporter.parse(
      group,
      (out) => {
        saveBlob(new Blob([out], { type: 'model/gltf-binary' }), filename);
        resolve(out.byteLength);
      },
      (err) => reject(err),
      { binary: true, onlyVisible: true, includeCustomExtensions: true }
    );
  });
}

/** 一次性导出全部交付物 */
export async function exportAll(viewer, result, prefix = 'terrain') {
  const files = [];
  await downloadCanvas(heightToCanvas(result), `${prefix}_height.png`);
  files.push(`${prefix}_height.png`);
  await downloadCanvas(classToCanvas(result), `${prefix}_biomes.png`);
  files.push(`${prefix}_biomes.png`);
  exportHeightRaw(result, `${prefix}_height_f32.bin`);
  files.push(`${prefix}_height_f32.bin`);
  exportSceneJSON(result, `${prefix}_scene.json`);
  files.push(`${prefix}_scene.json`);
  try {
    const bytes = await exportGLB(viewer, result, `${prefix}_world.glb`, true);
    files.push(`${prefix}_world.glb (${(bytes / 1048576).toFixed(1)} MB)`);
  } catch (e) {
    try {
      const bytes = await exportGLB(viewer, result, `${prefix}_world.glb`, false);
      files.push(`${prefix}_world.glb 仅地形+水面 (${(bytes / 1048576).toFixed(1)} MB)`);
    } catch (e2) {
      files.push(`GLB 失败: ${e2 && e2.message ? e2.message : e2}`);
    }
  }
  return files;
}
