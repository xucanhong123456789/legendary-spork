// 无头截图：验证新树木几何（枝干细节 / 非圆球叶冠）
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import puppeteer from 'puppeteer-core';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.join(__dirname, '..', 'dist');
const OUT = path.join(__dirname, '..', 'preview');
fs.mkdirSync(OUT, { recursive: true });

const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.wasm': 'application/wasm', '.map': 'application/json',
};

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  const fp = path.join(DIST, p);
  if (!fp.startsWith(DIST) || !fs.existsSync(fp)) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(fp)] || 'application/octet-stream' });
  fs.createReadStream(fp).pipe(res);
});

await new Promise((r) => server.listen(0, r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}`;
console.log('serving dist on', base);

const browser = await puppeteer.launch({
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  headless: 'new',
  args: [
    '--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu-sandbox',
    '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
    '--window-size=1280,820', '--hide-scrollbars',
  ],
});

async function shoot(name, sample, biome, captureTypes) {
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 820, deviceScaleFactor: 1 });
  const errs = [];
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  page.on('pageerror', (e) => errs.push('PAGEERR ' + e.message));
  await page.goto(`${base}/?debug&sample=${sample}&biome=${biome}`, { waitUntil: 'load' });
  await new Promise((r) => setTimeout(r, 2600)); // 等管线 + 渲染

  const canvas = await page.$('#viewport canvas');
  if (captureTypes && captureTypes.length) {
    for (const type of captureTypes) {
      const ok = await page.evaluate((t) => {
        const v = window.TerrainWeaver && window.TerrainWeaver.viewer;
        if (!v) return 'noviewer';
        let target = null;
        for (const m of v.vegetation) {
          if (m.name === `Trees-${t}-leaf` && m.count > 0) { target = m; break; }
        }
        if (!target) return 'notype';
        const a = target.instanceMatrix.array;
        const x = a[12], y = a[13], z = a[14];
        // 不同树型取合适的距离与目标高度，完整看清单株
        const cfg = { 0: [9.5, 2.3], 1: [9.5, 2.5], 2: [10, 2.8], 3: [12, 3.6] }[t] || [9.5, 2.5];
        const d = cfg[0], th = cfg[1];
        v.camera.position.set(x + d, y + th + d * 0.12, z + d);
        v.controls.target.set(x, y + th, z);
        v.controls.update();
        return 'ok';
      }, type);
      if (ok !== 'ok') { console.log(`  [${biome}/${type}] skip: ${ok}`); continue; }
      await new Promise((r) => setTimeout(r, 450));
      const file = path.join(OUT, `${name}_type${type}.png`);
      await canvas.screenshot({ path: file });
      console.log(`  saved ${path.basename(file)}`);
    }
  } else {
    await canvas.screenshot({ path: path.join(OUT, `${name}_overview.png`) });
    console.log(`  saved ${name}_overview.png`);
  }
  if (errs.length) console.log('  CONSOLE ERRORS:', errs.slice(0, 5));
  await page.close();
}

console.log('temperate...');
await shoot('temperate', 'continent', 'temperate', [1, 0]); // 阔叶 + 针叶
console.log('tropical...');
await shoot('tropical', 'island', 'tropical', [3, 2]);      // 棕榈 + 雨林

// ---- 独立树木展厅：四种树同框 + 逐株近景 ----
console.log('gallery...');
{
  const devPort = process.env.DEV_PORT || 5178;
  const page = await browser.newPage();
  await page.setViewport({ width: 1360, height: 820, deviceScaleFactor: 1 });
  const errs = [];
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  page.on('pageerror', (e) => errs.push('PAGEERR ' + e.message));
  await page.goto(`http://127.0.0.1:${devPort}/test/tree-gallery.html`, { waitUntil: 'load' });
  await new Promise((r) => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(OUT, 'gallery_all.png') });
  console.log('  saved gallery_all.png');
  const xs = await page.evaluate(() => window.__gal && window.__gal.treeX);
  if (xs) {
    for (let t = 0; t < 4; t++) {
      const ok = await page.evaluate((idx) => {
        const g = window.__gal; if (!g) return 'nogal';
        const x = g.treeX[idx];
        g.camera.position.set(x + 6.2, 4.2, 9.5);
        g.controls.target.set(x, 3.0, 0);
        g.controls.update();
        return 'ok';
      }, t);
      if (ok !== 'ok') { console.log(`  [gallery/${t}] skip: ${ok}`); continue; }
      await new Promise((r) => setTimeout(r, 400));
      await page.screenshot({ path: path.join(OUT, `gallery_type${t}.png`) });
      console.log(`  saved gallery_type${t}.png`);
    }
  }
  if (errs.length) console.log('  GALLERY ERRORS:', errs.slice(0, 5));
  await page.close();
}

// ---- 真实地形森林全景（验证叶片贴图在场景尺度下的表现 + 叶形阴影）----
console.log('scene overview...');
{
  const page = await browser.newPage();
  await page.setViewport({ width: 1360, height: 820, deviceScaleFactor: 1 });
  const errs = [];
  page.on('console', (m) => { if (m.type() === 'error' && !/404/.test(m.text())) errs.push(m.text()); });
  page.on('pageerror', (e) => errs.push('PAGEERR ' + e.message));
  await page.goto(`${base}/?sample=continent&biome=temperate`, { waitUntil: 'load' });
  await new Promise((r) => setTimeout(r, 2800));
  await (await page.$('#viewport canvas')).screenshot({ path: path.join(OUT, 'scene_forest.png') });
  console.log('  saved scene_forest.png');
  if (errs.length) console.log('  SCENE ERRORS:', errs.slice(0, 5));
  await page.close();
}

await browser.close();
server.close();
console.log('DONE');
