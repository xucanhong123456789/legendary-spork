// ============================================================
// main.js - 编辑器外壳
// 源图导入 / 四通道切换 / 参数联动 / 三维预览 / 导出交付
// ============================================================
import * as THREE from 'three';
import { TerrainViewer } from '../engine/render/viewer.js';
import { buildTerrain } from '../engine/terrain/terrain.js';
import { BAND_NAMES, BIOME_PRESETS } from '../engine/terrain/biome.js';
import { exportAll } from '../engine/export/exporters.js';
import { makeSampleMap } from './terrainSamples.js';

const $ = (id) => document.getElementById(id);
const SAMPLE_KINDS = ['continent', 'fjord', 'delta', 'island'];
const SAMPLE_LABELS = { continent: '开阔大陆', fjord: '温带峡湾', delta: '河口三角洲', island: '热带火山岛' };
const MODE_HINT = {
  semantic: '按约定色识别地貌：深蓝=深海、蓝=浅水、砂=沙滩、绿=平原、墨绿=森林、灰=岩石、白=雪。引擎据此反推海平面与山势。',
  height: '像素亮度即海拔。自动做直方图拉伸，按高程推演水系、坡度与生态带。',
  hybrid: '亮度定地形骨架，颜色定地表覆盖。拖入两张图时，第一张作高度图、第二张作地表色图。',
  painted: '对任意手绘彩色地图做 k-means 聚类，按色块明暗推断高程，鲁棒性略低但最自由。',
};
const PRESET_HINT = {
  temperate: '温带大陆：针阔混交林、宽阔河谷、雪线较高，适合大多数中土风格世界。',
  alpine: '高山雪原：雪线下压、林线降低，裸岩与冰川地貌占比更高。',
  tropical: '热带海岛：雨林密冠、棕榈海岸、几乎无积雪，湿度普遍偏高。',
  karst: '岩溶高原：石灰岩裸坡、稀疏植被、盆地与孤峰，树木明显减少。',
};

const state = {
  mode: 'semantic',
  kind: 'continent',
  preset: 'temperate',
  voxel: false,
  size: 384,
  primary: null,
  secondary: null,
  result: null,
  generating: false,
};

const viewer = new TerrainViewer($('viewport'));
const qp = new URLSearchParams(location.search);
let toastTimer = null;
let regenTimer = null;

function toast(msg, ms = 2600) {
  const el = $('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), ms);
}

function setLoading(on, step = '') {
  const el = $('loading');
  if (on) {
    el.classList.add('show');
    $('loadBar').style.width = '8%';
    $('loadStep').textContent = step || '初始化渲染管线…';
    requestAnimationFrame(() => { $('loadBar').style.width = '88%'; });
  } else {
    $('loadBar').style.width = '100%';
    setTimeout(() => el.classList.remove('show'), 260);
  }
  $('statusText').textContent = on ? '生成中…' : '就绪';
  document.querySelector('.live').classList.toggle('busy', on);
}

const nextFrame = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

/* ---------------- 源图 ---------------- */
function drawTo(canvas, size) {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(canvas, 0, 0, size, size);
  return ctx.getImageData(0, 0, size, size);
}

function showThumb(canvas) {
  const thumb = $('thumb');
  const ctx = thumb.getContext('2d');
  const s = 512;
  thumb.width = s;
  thumb.height = s;
  ctx.clearRect(0, 0, s, s);
  const scale = Math.min(s / canvas.width, s / canvas.height);
  const w = canvas.width * scale;
  const h = canvas.height * scale;
  ctx.drawImage(canvas, (s - w) / 2, (s - h) / 2, w, h);
  $('thumbBadge').textContent = `${canvas.width}×${canvas.height}`;
}

function loadSample(kind) {
  state.kind = kind;
  state.primary = makeSampleMap(kind, 768).canvas;
  state.secondary = null;
  showThumb(state.primary);
  $('palName').textContent = 'TOLKIEN';
  toast(`已载入示例：${SAMPLE_LABELS[kind]}`);
  regenerate();
}

async function fileToCanvas(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.src = url;
    await img.decode();
    const c = document.createElement('canvas');
    c.width = img.naturalWidth;
    c.height = img.naturalHeight;
    c.getContext('2d').drawImage(img, 0, 0);
    return c;
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function handleFiles(files) {
  const imgs = [...files].filter((f) => f.type.startsWith('image/'));
  if (!imgs.length) { toast('请选择 PNG / JPG 图片'); return; }
  const canvases = [];
  for (const f of imgs.slice(0, 2)) canvases.push(await fileToCanvas(f));
  state.primary = canvases[0];
  state.secondary = canvases[1] || null;
  showThumb(state.primary);
  if (state.secondary) {
    setMode('hybrid');
    toast('已载入两张图：第一张作高度图，第二张作地表色图，自动切到双通道');
  } else {
    toast(`已载入 ${imgs[0].name}`);
  }
  regenerate();
}

/* ---------------- 生成 ---------------- */
function buildSource() {
  const img = drawTo(state.primary, state.size);
  const src = { rgba: img.data, w: state.size, h: state.size, readOpt: {} };
  if (state.mode === 'hybrid' && state.secondary) {
    const surf = drawTo(state.secondary, state.size);
    src.rgba = surf.data;
    src.readOpt = { lumaRgba: img.data };
  }
  return src;
}

function readParams() {
  const num = (id) => Number($(id).value);
  const p = {
    mode: state.mode,
    relief: num('rRelief'),
    erosion: num('rErosion'),
    riverCut: num('rRiver'),
    veg: num('rVeg'),
    detail: num('rDetail'),
    preset: state.preset,
    snowLine: num('rSnow') / 100,
    treeLine: 0.34 + (num('rTundra') / 100) * 0.52,
    seed: 1337,
  };
  const bandBias = (num('rAlpine') + num('rBoreal') + num('rForest') + num('rGrass')) / 400;
  p.veg *= 0.65 + bandBias * 0.70;
  return p;
}

async function regenerate() {
  if (state.generating || !state.primary) return;
  state.generating = true;
  setLoading(true, '识读 2D 地图 / 反解地貌…');
  await nextFrame();
  try {
    const t0 = performance.now();
    const result = buildTerrain(buildSource(), readParams(), (s) => {
      $('loadStep').textContent = s + '…';
    });
    state.result = result;

    if (state.voxel) quantize(result);
    const stats = viewer.setTerrain(result);
    viewer.setVoxel(state.voxel);
    viewer.setAtmosphere({
      sun: Number($('rSun').value),
      haze: Number($('rHaze').value),
      cloud: Number($('rCloud').value),
      bloom: $('tBloom').checked,
      godrays: $('tGodrays').checked,
      waters: $('tWaters').checked,
      trees: $('tTrees').checked,
    });

    const elapsed = Math.round(performance.now() - t0);
    $('statVerts').textContent = stats.verts.toLocaleString();
    $('statTris').textContent = (stats.tris / 1000).toFixed(0) + 'K';
    $('statTrees').textContent = stats.trees.toLocaleString();
    $('statTime').textContent = (Math.max(elapsed, result.stats.elapsed) / 1000).toFixed(2) + 's';
    $('infoSea').textContent = result.stats.seaLevel.toFixed(3);
    $('infoPeak').textContent = result.stats.peak.toFixed(3);
    $('infoRiver').textContent = result.stats.riverKm.toFixed(1) + ' km';
    $('infoLake').textContent = String(result.stats.lakes);
    $('biomeHint').textContent = PRESET_HINT[state.preset];
    document.querySelectorAll('#pipe .node').forEach((n) => n.classList.add('active'));
    setLoading(false);
    toast(`重建完成 · ${result.stats.trees.toLocaleString()} 株树木 · ${result.stats.lakes} 个湖泊 · ${elapsed} ms`, 3200);
  } catch (e) {
    console.error(e);
    setLoading(false);
    toast('生成失败：' + (e && e.message ? e.message : e), 5000);
  } finally {
    state.generating = false;
  }
}

/** 体素模式：把高程量化成台阶，树与水面随之对齐 */
function quantize(result) {
  const levels = 26;
  const { W, H, dem } = result;
  for (let i = 0; i < dem.length; i++) dem[i] = Math.round(dem[i] * levels) / levels;
  const t = result.biomes.trees;
  for (let k = 0; k < t.count; k++) {
    const x = Math.min(W - 1, Math.max(0, Math.round(t.pos[k * 3])));
    const y = Math.min(H - 1, Math.max(0, Math.round(t.pos[k * 3 + 1])));
    t.pos[k * 3 + 2] = dem[y * W + x];
  }
}

function scheduleRegen() {
  clearTimeout(regenTimer);
  regenTimer = setTimeout(regenerate, 420);
}

/* ---------------- UI 绑定 ---------------- */
function setMode(mode) {
  state.mode = mode;
  document.querySelectorAll('#modeSeg button, .tabs button').forEach((b) => {
    b.classList.toggle('on', b.dataset.mode === mode);
  });
  $('modeHint').textContent = MODE_HINT[mode];
}

document.querySelectorAll('#modeSeg button, .tabs button').forEach((b) => {
  b.addEventListener('click', () => { setMode(b.dataset.mode); regenerate(); });
});

document.querySelectorAll('#biomeSeg button').forEach((b) => {
  b.addEventListener('click', () => {
    document.querySelectorAll('#biomeSeg button').forEach((x) => x.classList.remove('on'));
    b.classList.add('on');
    state.preset = b.dataset.biome;
    $('biomeHint').textContent = PRESET_HINT[state.preset];
    regenerate();
  });
});

document.querySelectorAll('#modeTabs button').forEach((b) => {
  b.addEventListener('click', () => {
    document.querySelectorAll('#modeTabs button').forEach((x) => x.classList.remove('on'));
    b.classList.add('on');
    state.voxel = b.dataset.mode === 'voxel';
    toast(state.voxel ? '体素地形：高程量化为台阶' : '标准地形：连续高程');
    regenerate();
  });
});

const sliders = [
  ['rRelief', 'vRelief', (v) => v.toFixed(2), true],
  ['rErosion', 'vErosion', (v) => v < 0.3 ? '弱' : v < 0.7 ? '中' : '强', true],
  ['rRiver', 'vRiver', (v) => v < 0.3 ? '弱' : v < 0.7 ? '中' : '强', true],
  ['rVeg', 'vVeg', (v) => v.toFixed(2), true],
  ['rDetail', 'vDetail', (v) => v.toFixed(2), true],
  ['rSun', 'vSun', (v) => v.toFixed(0) + '°', false],
  ['rHaze', 'vHaze', (v) => v.toFixed(2), false],
  ['rCloud', null, null, false],
  ['rSnow', 'vSnow', (v) => '高度 ' + v, true],
  ['rTundra', null, null, true],
  ['rAlpine', null, null, true],
  ['rBoreal', null, null, true],
  ['rForest', null, null, true],
  ['rGrass', null, null, true],
];
for (const [id, out, fmt, heavy] of sliders) {
  const el = $(id);
  if (!el) continue;
  el.addEventListener('input', () => {
    if (out) $(out).textContent = fmt(Number(el.value));
    if (!heavy) applyAtmosphere();
    else scheduleRegen();
  });
}

function applyAtmosphere() {
  viewer.setAtmosphere({
    sun: Number($('rSun').value),
    haze: Number($('rHaze').value),
    cloud: Number($('rCloud').value),
    bloom: $('tBloom').checked,
    godrays: $('tGodrays').checked,
    waters: $('tWaters').checked,
    trees: $('tTrees').checked,
  });
}
for (const id of ['tWaters', 'tTrees', 'tGodrays', 'tBloom']) {
  $(id).addEventListener('change', applyAtmosphere);
}

const layerMap = {
  lTerrain: 'terrain', lSnow: 'snow', lWater: 'water',
  lForest: 'forest', lRelief: 'relief',
};
Object.entries(layerMap).forEach(([id, name]) => {
  $(id).addEventListener('change', (e) => viewer.setLayer(name, e.target.checked));
});

$('tWire').addEventListener('click', (e) => {
  const on = !e.currentTarget.classList.contains('on');
  e.currentTarget.classList.toggle('on', on);
  viewer.setWireframe(on);
});
$('tNormal').addEventListener('click', (e) => {
  const on = !e.currentTarget.classList.contains('on');
  e.currentTarget.classList.toggle('on', on);
  viewer.setNormals(on);
});
$('tReset').addEventListener('click', () => viewer.resetView());

function doShot() {
  const url = viewer.screenshot();
  const a = document.createElement('a');
  a.href = url;
  a.download = 'terrain_weaver_shot.png';
  a.click();
  toast('视口截图已保存');
}
$('tShot').addEventListener('click', doShot);
$('btnSnap').addEventListener('click', doShot);
$('btnCloseHint').addEventListener('click', () => {
  const h = $('hud-br');
  h.style.display = h.style.display === 'none' ? '' : 'none';
});

$('btnSample').addEventListener('click', () => {
  const i = (SAMPLE_KINDS.indexOf(state.kind) + 1) % SAMPLE_KINDS.length;
  loadSample(SAMPLE_KINDS[i]);
});
$('btnOpenFile').addEventListener('click', () => $('fileInput').click());
$('fileInput').addEventListener('change', (e) => { handleFiles(e.target.files); e.target.value = ''; });
$('btnRegen').addEventListener('click', regenerate);

$('btnExport').addEventListener('click', async () => {
  if (!state.result) { toast('请先生成地形'); return; }
  toast('正在打包交付物…');
  try {
    const files = await exportAll(viewer, state.result, 'terrain_weaver');
    toast('已导出：' + files.join(' · '), 5000);
  } catch (e) {
    toast('导出失败：' + (e && e.message ? e.message : e), 5000);
  }
});

const wrap = $('thumbWrap');
wrap.addEventListener('click', () => $('fileInput').click());
['dragenter', 'dragover'].forEach((ev) => wrap.addEventListener(ev, (e) => {
  e.preventDefault(); wrap.classList.add('drag');
}));
['dragleave', 'drop'].forEach((ev) => wrap.addEventListener(ev, (e) => {
  e.preventDefault(); wrap.classList.remove('drag');
}));
wrap.addEventListener('drop', (e) => handleFiles(e.dataTransfer.files));
window.addEventListener('dragover', (e) => e.preventDefault());
window.addEventListener('drop', (e) => e.preventDefault());

window.addEventListener('keydown', (e) => {
  const k = e.key;
  if (k === 'ArrowLeft') viewer.orbit(-0.08, 0);
  else if (k === 'ArrowRight') viewer.orbit(0.08, 0);
  else if (k === 'ArrowUp') viewer.orbit(0, -0.06);
  else if (k === 'ArrowDown') viewer.orbit(0, 0.06);
  else return;
  e.preventDefault();
});

/* ---------------- 视口拾取：显示所在生态带 ---------------- */
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
let hoverPending = false;
$('viewport').addEventListener('pointermove', (e) => {
  if (!state.result || hoverPending) return;
  hoverPending = true;
  requestAnimationFrame(() => {
    hoverPending = false;
    const rect = $('viewport').getBoundingClientRect();
    pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, viewer.camera);
    const mesh = viewer.terrainMesh;
    if (!mesh) return;
    const hit = raycaster.intersectObject(mesh, false)[0];
    const card = $('treeHint');
    if (!hit || !hit.uv) { card.style.display = 'none'; return; }
    const r = state.result;
    const x = Math.min(r.W - 1, Math.max(0, Math.round(hit.uv.x * (r.W - 1))));
    const y = Math.min(r.H - 1, Math.max(0, Math.round(hit.uv.y * (r.H - 1))));
    const i = y * r.W + x;
    const band = r.biomes.band[i];
    $('treeTitle').textContent = BAND_NAMES[band];
    $('treeDesc').textContent =
      `海拔 ${r.dem[i].toFixed(3)} · 湿度 ${r.fields.moisture[i].toFixed(2)} · 坡度 ${r.fields.slope[i].toFixed(2)}` +
      (r.hydro.waterMask[i] ? ' · 水体' : '');
    card.style.display = 'block';
  });
});
$('viewport').addEventListener('pointerleave', () => { $('treeHint').style.display = 'none'; });

/* ---------------- 启动 ---------------- */
if (location.search.includes('debug')) {
  const m = qp.get('mode');
  if (m && MODE_HINT[m]) state.mode = m;
  const b = qp.get('biome');
  if (b && BIOME_PRESETS[b]) state.preset = b;
}
setMode(state.mode);
$('biomeHint').textContent = PRESET_HINT[state.preset];
const startSample = location.search.includes('debug') && SAMPLE_LABELS[qp.get('sample')]
  ? qp.get('sample') : 'continent';
loadSample(startSample);

// 无头自检：定时把运行时诊断写到 title
if (location.search.includes('debug')) {
  setInterval(() => {
    const list = window.__diagnostics || [];
    let extra = '';
    try {
      const w = viewer.waterMesh;
      if (w && state.result) {
        const md = viewer.waterMat.uniforms.uMaskTex.value.image.data;
        let white = 0;
        for (let i = 0; i < md.length; i++) if (md[i] > 200) white++;
        const am = w.geometry.attributes.aMask;
        let amax = 0;
        for (let i = 0; i < am.count; i += 51) amax = Math.max(amax, am.getX(i));
        const py = w.geometry.attributes.position;
        let ymin = 1e9; let ymax = -1e9;
        for (let i = 0; i < py.count; i += 51) {
          const y = py.getY(i);
          ymin = Math.min(ymin, y); ymax = Math.max(ymax, y);
        }
        extra = ` water visible=${w.visible} maskWhite=${white} aMaskMax=${amax.toFixed(2)} waterY=${ymin.toFixed(1)}..${ymax.toFixed(1)} seaCells=${state.result.stats.seaCells} drawTris=${viewer.renderer.info.render.triangles}`;
      }
    } catch (e) { extra = ' diagErr ' + e.message; }
    document.title = `DIAG ${list.length} |${extra}| ${window.__exportResult || ''} | ${list.slice(0, 3).join(' || ').slice(0, 380)}`;
  }, 400);
  if (qp.get('flatWater')) {
    setTimeout(() => {
      viewer.waterMat.uniforms.uWave.value = 0;
      viewer.waterMat.uniforms.uFoam.value = 0;
      if (viewer.outerSea) {
        viewer.outerSea.material.uniforms.uWave.value = 0;
        viewer.outerSea.material.uniforms.uFoam.value = 0;
      }
    }, 1500);
  }
  if (qp.get('hide')) {
    setTimeout(() => {
      const targets = qp.get('hide').split(',');
      if (targets.includes('outer') && viewer.outerSea) viewer.outerSea.visible = false;
      if (targets.includes('water') && viewer.waterMesh) viewer.waterMesh.visible = false;
      if (targets.includes('skirt')) {
        const s = viewer.root.getObjectByName('Skirt');
        if (s) s.visible = false;
      }
      window.__hidden = targets.join(',');
    }, 1600);
  }
  if (qp.get('export') === '1' && !window.__exportDone) {
    window.__exportDone = true;
    setTimeout(async () => {
      try {
        const files = await exportAll(viewer, state.result, 'selftest');
        window.__exportResult = 'EXPORT_OK ' + files.join(' / ');
      } catch (e) {
        window.__exportResult = 'EXPORT_ERR ' + (e && e.message ? e.message : e);
      }
    }, 2500);
  }
}

// 暴露给宿主工具（Electron / Tauri 壳可通过 window.TerrainWeaver 调用）
window.TerrainWeaver = {
  viewer,
  getResult: () => state.result,
  regenerate,
  loadSample,
  handleFiles,
  setMode,
  state,
};
