// -*- coding: utf-8 -*-
// 九年级上学期数学学习工作台 —— 应用逻辑（纯静态，零依赖）
(function () {
  'use strict';

  var STORE = 'jy_math_v1';

  var DB = null;
  var MC = window.MATH_CONTENT;
  var state = { view: 'dashboard', session: null };

  // ---------------- 工具函数 ----------------
  function nowISO() { return new Date().toISOString(); }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function todayKey() { var d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function esc(s) {
    s = (s == null ? '' : '' + s);
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function fmtDate(iso) {
    if (!iso) return '';
    var d = new Date(iso);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function toast(msg) {
    var t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast show';
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.className = 'toast'; }, 1800);
  }

  // 归一化填空题答案：去空格、统一符号
  function norm(s) {
    return (s == null ? '' : '' + s)
      .trim().toLowerCase()
      .replace(/\s/g, '')
      .replace(/²/g, '^2')
      .replace(/[－−—]/g, '-')
      .replace(/[×*]/g, '*')
      .replace(/[（]/g, '(')
      .replace(/[）]/g, ')')
      .replace(/[，]/g, ',')
      .replace(/[＝]/g, '=');
  }
  function numEq(a, b) {
    var x = parseFloat(a), y = parseFloat(b);
    if (isFinite(x) && isFinite(y) && Math.abs(x - y) < 1e-6) return true;
    return false;
  }
  function ansRight(user, ans) {
    if (user == null) return false;
    var u = norm(user), a = norm(ans);
    if (u === a) return true;
    if (numEq(user, ans)) return true;
    // 多值答案（逗号分隔）按集合比较
    if (a.indexOf(',') >= 0) {
      var au = u.split(',').sort(), aa = a.split(',').sort();
      if (au.length === aa.length && au.every(function (v, i) { return v === aa[i] || numEq(v, aa[i]); })) return true;
    }
    return false;
  }

  // ---------------- 存储 ----------------
  function defaultDB() {
    return {
      meta: { owner: '同学', grade: '九年级', created: nowISO(), updated: nowISO() },
      settings: { theme: 'light', name: '同学' },
      progress: {},     // pointId -> {r,w}
      mistakes: [],     // {id,pointId,pointName,chapterName,q,userAns,correctAns,tip,addedAt,status}
      quizRuns: [],     // {date,score,total,rate}
      schoolProg: {},   // chapterId -> 'none'|'doing'|'done'
      streak: {}        // 'YYYY-MM-DD' -> 1
    };
  }
  function loadDB() {
    try {
      var s = localStorage.getItem(STORE);
      if (s) DB = JSON.parse(s);
    } catch (e) { DB = null; }
    if (!DB) DB = defaultDB();
    if (!DB.progress) DB.progress = {};
    if (!DB.mistakes) DB.mistakes = [];
    if (!DB.quizRuns) DB.quizRuns = [];
    if (!DB.schoolProg) DB.schoolProg = {};
    if (!DB.streak) DB.streak = {};
    if (!DB.settings) DB.settings = { theme: 'light', name: '同学' };
    if (!DB.meta) DB.meta = { owner: '同学', grade: '九年级', created: nowISO(), updated: nowISO() };
  }
  function saveDB() {
    DB.updated = nowISO();
    try { localStorage.setItem(STORE, JSON.stringify(DB)); } catch (e) { toast('保存失败：存储空间不足'); }
  }

  // ---------------- 进度 / 掌握度 ----------------
  // 等级：0 未学 / 1 不懂 / 2 半懂 / 3 会了 / 4 很熟
  function levelOf(p) {
    if (!p) return 0;
    var r = p.r || 0, w = p.w || 0;
    if (r === 0 && w === 0) return 0;
    if (w === 0) return r >= 3 ? 4 : 3;
    if (r === 0) return 1;
    return r >= w ? 2 : 1;
  }
  var LV_NAME = ['未学', '不懂', '半懂', '会了', '很熟'];
  var LV_CLS = ['lv0', 'lv1', 'lv2', 'lv3', 'lv4'];
  function chip(lv) { return '<span class="chip ' + LV_CLS[lv] + '">' + LV_NAME[lv] + '</span>'; }

  function allPoints() {
    var out = [];
    MC.chapters.forEach(function (ch) {
      ch.points.forEach(function (pt) {
        out.push({ ch: ch, pt: pt });
      });
    });
    return out;
  }
  function pointById(id) {
    var r = null;
    allPoints().forEach(function (x) { if (x.pt.id === id) r = x; });
    return r;
  }
  function drillsOfPoint(pt) { return pt.drills || []; }
  function flattenDrills(scope) {
    var refs = [];
    MC.chapters.forEach(function (ch) {
      ch.points.forEach(function (pt) {
        var include = false;
        if (scope === 'all') include = true;
        else if (scope && scope.indexOf('pt:') === 0) include = (scope === 'pt:' + pt.id);
        else include = (scope === ch.id);
        if (include) {
          (pt.drills || []).forEach(function (dr) {
            refs.push({ chapterId: ch.id, chapterName: ch.name, pointId: pt.id, pointName: pt.name, drill: dr });
          });
        }
      });
    });
    return refs;
  }
  function pickRandom(arr, n) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a.slice(0, Math.min(n, a.length));
  }

  // ---------------- 学习打卡 ----------------
  function markActive() {
    var k = todayKey();
    if (!DB.streak[k]) { DB.streak[k] = 1; saveDB(); }
  }
  function streakDays() {
    var n = 0;
    var d = new Date();
    // 若今天还没学，从昨天起算连续
    if (!DB.streak[todayKey()]) d.setDate(d.getDate() - 1);
    while (true) {
      var k = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
      if (DB.streak[k]) { n++; d.setDate(d.getDate() - 1); }
      else break;
    }
    return n;
  }

  // ---------------- 导航 ----------------
  var NAV = [
    { g: '学习', items: [['dashboard', '今日引导'], ['library', '概念库'], ['practice', '习题练习']] },
    { g: '攻克', items: [['mistakes', '错题本'], ['errors', '常见错误']] },
    { g: '成长', items: [['progress', '学习进度'], ['quiz', '测验']] },
    { g: '工具', items: [['settings', '设置']] }
  ];
  function ROUTER() { return {
    dashboard: vDashboard, library: vLibrary, practice: vPractice,
    mistakes: vMistakes, errors: vErrors, progress: vProgress,
    quiz: vQuiz, settings: vSettings
  }; }

  function D_go(view) { state.view = view; state.session = null; render(); }

  // ---------------- 渲染骨架 ----------------
  function navHTML() {
    var h = '<div class="brand"><div class="brand-logo">数</div><div class="brand-txt"><b>九年级数学</b><span>上学期 · 学习工作台</span></div></div><nav class="nav">';
    NAV.forEach(function (grp) {
      h += '<div class="nav-grp">' + grp.g + '</div>';
      grp.items.forEach(function (it) {
        var id = it[0], name = it[1];
        h += '<button class="nav-item' + (state.view === id ? ' active' : '') + '" data-act="go" data-view="' + id + '">' + name + '</button>';
      });
    });
    h += '</nav>';
    return h;
  }

  function render() {
    var wasOpen = document.body.classList && document.body.classList.contains('menu-open');
    document.body.className = (DB.settings.theme === 'dark') ? 'theme-dark' : 'theme-light';
    if (wasOpen) document.body.classList.add('menu-open');
    var app = document.getElementById('app');
    app.innerHTML =
      '<aside class="sidebar">' + navHTML() +
      '<div class="side-foot">已掌握 <b id="footMastered">0</b> / ' + allPoints().length + ' 知识点</div>' +
      '</aside>' +
      '<main class="main"><header class="topbar">' +
      '<button class="menu-btn" data-act="toggle-menu">☰</button>' +
      '<div class="top-title">' + pageTitle() + '</div>' +
      '<div class="top-right"><span class="who">' + esc(DB.settings.name) + '</span>' +
      '<button class="icon-btn" data-act="theme-toggle" title="切换主题">' + (DB.settings.theme === 'dark' ? '☀' : '🌙') + '</button></div>' +
      '</header><section class="view" id="view">' + (ROUTER()[state.view] || vDashboard)() + '</section></main>' +
      '<div class="scrim" data-act="toggle-menu"></div>';
    var fm = document.getElementById('footMastered');
    if (fm) fm.textContent = masteredCount();
    bindOnce();
  }

  function pageTitle() {
    var t = '';
    NAV.forEach(function (g) { g.items.forEach(function (it) { if (it[0] === state.view) t = it[1]; }); });
    return t || '九年级数学学习工作台';
  }
  function masteredCount() {
    var n = 0;
    allPoints().forEach(function (x) { if (levelOf(DB.progress[x.pt.id]) >= 3) n++; });
    return n;
  }

  // ---------------- 视图：今日引导 ----------------
  function vDashboard() {
    var total = allPoints().length;
    var mastered = masteredCount();
    var started = allPoints().filter(function (x) { var p = DB.progress[x.pt.id]; return p && (p.r || p.w); }).length;
    var rate = overallRate();
    var doneCh = 0;
    MC.chapters.forEach(function (ch) { if (DB.schoolProg[ch.id] === 'done') doneCh++; });
    var streak = streakDays();
    var next = nextAction();

    return '' +
      '<div class="hero">' +
      '<h1>你好，' + esc(DB.settings.name) + ' 👋</h1>' +
      '<p>九年级上学期数学 · 共 ' + MC.chapters.length + ' 章 ' + total + ' 个知识点。今天，我们从一步开始。</p>' +
      '</div>' +
      '<div class="stat-row">' +
      statCard('已掌握', mastered + ' / ' + total, 'lv' + (mastered === total ? 4 : 3)) +
      statCard('已学习', started + ' 个', '') +
      statCard('正确率', (rate * 100).toFixed(0) + '%', rate >= 0.8 ? 'lv3' : 'lv2') +
      statCard('连续学习', streak + ' 天', streak > 0 ? 'lv4' : 'lv0') +
      '</div>' +
      '<div class="card next-card"><div class="next-label">建议下一步</div>' +
      '<div class="next-action">' + next.html + '</div>' +
      '<div class="btn-row">' + next.btns + '</div></div>' +
      '<div class="card"><h3>章节进度</h3>' + chapterProgressHTML() + '</div>';
  }
  function statCard(label, val, cls) {
    return '<div class="stat ' + cls + '"><div class="stat-val">' + val + '</div><div class="stat-label">' + label + '</div></div>';
  }
  function chapterProgressHTML() {
    var h = '<div class="chp-list">';
    MC.chapters.forEach(function (ch) {
      var pts = ch.points;
      var mas = pts.filter(function (p) { return levelOf(DB.progress[p.id]) >= 3; }).length;
      var st = DB.schoolProg[ch.id] || 'none';
      var stTxt = { none: '未学', doing: '在学', done: '学完' }[st];
      h += '<div class="chp-row" data-act="go" data-view="library" data-chap="' + ch.id + '">' +
        '<div class="chp-name">' + ch.no + ' ' + ch.name + '</div>' +
        '<div class="chp-bar"><div class="chp-bar-in" style="width:' + (mas / pts.length * 100) + '%"></div></div>' +
        '<div class="chp-meta"><span>' + mas + '/' + pts.length + '</span><span class="tag tag-' + st + '">' + stTxt + '</span></div>' +
        '</div>';
    });
    h += '</div>';
    return h;
  }
  function overallRate() {
    var r = 0, w = 0;
    Object.keys(DB.progress).forEach(function (k) { r += DB.progress[k].r || 0; w += DB.progress[k].w || 0; });
    if (r + w === 0) return 0;
    return r / (r + w);
  }
  function nextAction() {
    // 简单策略：优先推荐未掌握的、已学但未掌握的知识点练习
    var weak = allPoints().filter(function (x) { return levelOf(DB.progress[x.pt.id]) >= 1 && levelOf(DB.progress[x.pt.id]) <= 2; });
    if (weak.length) {
      var x = weak[0];
      return {
        html: '巩固「' + x.pt.name + '」（' + x.ch.name + '）还有薄弱点，做几道题吧。',
        btns: '<button class="btn primary" data-act="practice-start" data-scope="pt:' + x.pt.id + '">去练习</button>'
      };
    }
    var unstarted = allPoints().filter(function (x) { var p = DB.progress[x.pt.id]; return !p || (!p.r && !p.w); });
    if (unstarted.length) {
      var y = unstarted[0];
      return {
        html: '新知识点「' + y.pt.name + '」还没开始，先看看概念讲解。',
        btns: '<button class="btn primary" data-act="go" data-view="library">打开概念库</button>'
      };
    }
    return {
      html: '太棒了，所有知识点都练过了！来一场测验检验一下吧。',
      btns: '<button class="btn primary" data-act="go" data-view="quiz">开始测验</button>'
    };
  }

  // ---------------- 视图：概念库 ----------------
  function vLibrary() {
    var h = '<div class="card intro-card"><p>点击章节展开知识点。每个知识点都包含 <b>概念详解</b>、<b>解题步骤演示</b> 和 <b>常见错误分析</b>。看完讲解，点「练一练」即时检验。</p></div>';
    MC.chapters.forEach(function (ch) {
      h += '<details class="chp-detail" open><summary><span class="chp-no">' + ch.no + '</span>' + ch.name +
        '<span class="chp-sum">' + ch.summary + '</span></summary>';
      ch.points.forEach(function (pt) {
        var lv = levelOf(DB.progress[pt.id]);
        h += '<details class="pt-detail"><summary><span class="pt-name">' + pt.name + '</span>' + chip(lv) + '</summary>';
        h += '<div class="pt-body">';
        h += '<div class="sec"><div class="sec-h">📘 概念详解</div><div class="sec-b">' + pt.explain + '</div></div>';
        if (pt.key && pt.key.length) {
          h += '<div class="sec"><div class="sec-h">🔑 要点口诀</div><div class="sec-b"><ul class="keys">' +
            pt.key.map(function (k) { return '<li>' + esc(k) + '</li>'; }).join('') + '</ul></div></div>';
        }
        if (pt.examples && pt.examples.length) {
          h += '<div class="sec"><div class="sec-h">🧮 解题步骤演示</div>';
          pt.examples.forEach(function (eg, i) {
            h += '<div class="eg"><div class="eg-q">' + (i + 1) + '. ' + eg.q + '</div><ol class="steps">';
            eg.steps.forEach(function (s) { h += '<li>' + esc(s) + '</li>'; });
            h += '</ol><div class="eg-ans">答：' + esc(eg.ans) + '</div></div>';
          });
          h += '</div>';
        }
        if (pt.errors && pt.errors.length) {
          h += '<div class="sec err-sec"><div class="sec-h">⚠ 常见错误分析</div>';
          pt.errors.forEach(function (e) {
            h += '<div class="err"><div class="err-w"><b>错：</b>' + esc(e.wrong) + '</div>' +
              '<div class="err-y"><b>因：</b>' + esc(e.why) + '</div>' +
              '<div class="err-r"><b>正：</b>' + esc(e.right) + '</div></div>';
          });
          h += '</div>';
        }
        h += '<div class="pt-actions"><button class="btn small" data-act="practice-start" data-scope="pt:' + pt.id + '">练一练（' + (pt.drills ? pt.drills.length : 0) + ' 题）</button></div>';
        h += '</div>'; // pt-body
      });
      h += '</details>';
    });
    return h;
  }

  // ---------------- 视图：习题练习 / 测验（共用 session） ----------------
  function vPractice() {
    if (state.session && state.session.mode === 'practice') return sessionHTML();
    var h = '<div class="card"><h3>选择练习范围</h3><p class="muted">系统会从对应范围抽取题目，作答后即时给出分步解析与易错提醒。</p><div class="scope-row">';
    h += '<button class="chip-btn" data-act="practice-start" data-scope="all">全部知识点</button>';
    MC.chapters.forEach(function (ch) {
      h += '<button class="chip-btn" data-act="practice-start" data-scope="' + ch.id + '">' + ch.no + ' ' + ch.name + '</button>';
    });
    h += '</div></div>';
    var weak = allPoints().filter(function (x) { var l = levelOf(DB.progress[x.pt.id]); return l >= 1 && l <= 2; });
    if (weak.length) {
      h += '<div class="card"><h3>⚡ 薄弱点速练</h3><div class="scope-row">';
      weak.slice(0, 6).forEach(function (x) {
        h += '<button class="chip-btn warn" data-act="practice-start" data-scope="pt:' + x.pt.id + '">' + x.pt.name + '</button>';
      });
      h += '</div></div>';
    }
    return h;
  }
  function vQuiz() {
    if (state.session && state.session.mode === 'quiz') return sessionHTML();
    var rate = overallRate();
    return '<div class="card"><h3>综合测验</h3>' +
      '<p class="muted">系统随机抽取 10 道题（含选择、填空），覆盖全册。完成后给出得分、正确率与逐题解析，并计入学习记录。</p>' +
      '<div class="btn-row"><button class="btn primary" data-act="quiz-start">开始 10 题测验</button></div>' +
      (DB.quizRuns.length ? '<div class="recent-runs"><h4>最近成绩</h4>' + recentRunsHTML() + '</div>' : '') +
      '</div>';
  }
  function recentRunsHTML() {
    var h = '<table class="run-tbl"><tr><th>日期</th><th>得分</th><th>正确率</th></tr>';
    DB.quizRuns.slice(-5).reverse().forEach(function (r) {
      h += '<tr><td>' + fmtDate(r.date) + '</td><td>' + r.score + '/' + r.total + '</td><td>' + (r.rate * 100).toFixed(0) + '%</td></tr>';
    });
    h += '</table>';
    return h;
  }

  function startSession(mode, scope) {
    var refs = flattenDrills(scope);
    if (!refs.length) { toast('该范围暂无可练习题目'); return; }
    var n = mode === 'quiz' ? Math.min(10, refs.length) : Math.min(6, refs.length);
    var q = pickRandom(refs, n);
    state.session = { mode: mode, refs: q, idx: 0, sel: null, input: '', submitted: false, correct: null, results: [] };
    render();
  }

  function sessionHTML() {
    var s = state.session;
    if (s.done) return quizResultHTML();
    var ref = s.refs[s.idx];
    var dr = ref.drill;
    var total = s.refs.length;
    var pct = Math.round((s.idx) / total * 100);
    var h = '<div class="card sess-card">';
    h += '<div class="sess-head"><span class="sess-tag">' + (s.mode === 'quiz' ? '测验' : '练习') + '</span>' +
      '<span class="sess-prog">第 ' + (s.idx + 1) + ' / ' + total + ' 题</span>' +
      '<span class="sess-from">' + ref.chapterName + ' · ' + ref.pointName + '</span></div>';
    h += '<div class="prog-line"><div class="prog-line-in" style="width:' + pct + '%"></div></div>';
    h += '<div class="q-text">' + esc(dr.q) + '</div>';

    if (dr.type === 'choice') {
      h += '<div class="opts">';
      dr.options.forEach(function (op) {
        var letter = op.charAt(0);
        var cls = 'opt';
        if (s.submitted) {
          if (letter === dr.ans) cls += ' ok';
          else if (letter === s.sel) cls += ' bad';
        } else if (s.sel === letter) cls += ' sel';
        h += '<button class="' + cls + '" ' + (s.submitted ? 'disabled' : 'data-act="opt-pick" data-opt="' + letter + '"') + '>' + esc(op) + '</button>';
      });
      h += '</div>';
    } else {
      h += '<div class="fill-wrap">';
      if (!s.submitted) {
        h += '<input class="fill-input" id="fillInput" placeholder="输入答案，如 2 或 x=2" value="' + esc(s.input) + '" />';
      } else {
        h += '<div class="fill-show">你的答案：<b class="' + (s.correct ? 'ok-t' : 'bad-t') + '">' + esc(s.input || '（空）') + '</b></div>';
      }
      h += '</div>';
    }

    if (!s.submitted) {
      h += '<div class="btn-row"><button class="btn primary" data-act="session-submit">提交答案</button>' +
        '<button class="btn ghost" data-act="session-quit">退出</button></div>';
    } else {
      h += '<div class="feedback ' + (s.correct ? 'fb-ok' : 'fb-bad') + '">' +
        (s.correct ? '✅ 答对啦！' : '❌ 再接再厉') + '</div>';
      h += '<div class="sol"><div class="sol-h">解题步骤</div><ol class="steps">';
      dr.sol.forEach(function (st) { h += '<li>' + esc(st) + '</li>'; });
      h += '</ol><div class="sol-ans">参考答案：' + esc(dr.ans) + '</div></div>';
      if (!s.correct && dr.tip) h += '<div class="tip">💡 易错提醒：' + esc(dr.tip) + '</div>';
      if (s.mode === 'practice' && !s.correct) {
        h += '<div class="tip soft">已自动记入错题本，可在「错题本」里复习。</div>';
      }
      var last = (s.idx + 1 >= total);
      if (s.mode === 'quiz' && last) {
        h += '<div class="btn-row"><button class="btn primary" data-act="session-next">查看成绩</button></div>';
      } else if (last) {
        h += '<div class="btn-row"><button class="btn primary" data-act="session-next">完成本轮</button></div>';
      } else {
        h += '<div class="btn-row"><button class="btn primary" data-act="session-next">下一题</button></div>';
      }
    }
    h += '</div>';
    return h;
  }

  function sessionSubmit() {
    var s = state.session; if (!s || s.submitted) return;
    var ref = s.refs[s.idx];
    var dr = ref.drill;
    var userAns;
    if (dr.type === 'choice') {
      if (!s.sel) { toast('请先选择一个选项'); return; }
      userAns = s.sel;
    } else {
      if (!s.input || !s.input.trim()) { toast('请先填写答案'); return; }
      userAns = s.input.trim();
    }
    var ok = ansRight(userAns, dr.ans);
    s.submitted = true;
    s.correct = ok;
    // 更新进度
    var p = DB.progress[ref.pointId] || { r: 0, w: 0 };
    if (ok) p.r++; else p.w++;
    DB.progress[ref.pointId] = p;
    s.results.push({ pointId: ref.pointId, ok: ok });
    // 错题入库
    if (!ok) {
      DB.mistakes.push({
        id: 'm' + Date.now() + Math.random().toString(36).slice(2, 6),
        pointId: ref.pointId, pointName: ref.pointName, chapterName: ref.chapterName,
        q: dr.q, userAns: (dr.type === 'choice' ? s.sel + '. ' + dr.options.filter(function (o) { return o.charAt(0) === s.sel; })[0].slice(2) : s.input),
        correctAns: dr.ans, tip: dr.tip || '', addedAt: nowISO(), status: 'open'
      });
    }
    markActive();
    saveDB();
    render();
  }

  function sessionNext() {
    var s = state.session; if (!s) return;
    if (s.idx + 1 >= s.refs.length) {
      if (s.mode === 'quiz') {
        var score = s.results.filter(function (r) { return r.ok; }).length;
        var total = s.results.length;
        var run = { date: nowISO(), score: score, total: total, rate: total ? score / total : 0 };
        DB.quizRuns.push(run);
        if (DB.quizRuns.length > 50) DB.quizRuns = DB.quizRuns.slice(-50);
        saveDB();
        s.done = true;
        render();
      } else {
        // 练习完成
        s.done = true; s.practiceSummary = { ok: s.results.filter(function (r) { return r.ok; }).length, total: s.results.length };
        render();
      }
    } else {
      s.idx++;
      s.sel = null; s.input = ''; s.submitted = false; s.correct = null;
      render();
    }
  }

  function quizResultHTML() {
    var s = state.session;
    if (s.mode === 'quiz') {
      var score = s.results.filter(function (r) { return r.ok; }).length;
      var total = s.results.length;
      var rate = total ? score / total : 0;
      return '<div class="card result-card"><div class="result-emoji">' + (rate >= 0.9 ? '🏆' : rate >= 0.6 ? '💪' : '🌱') + '</div>' +
        '<h2>测验完成</h2><div class="result-score">' + score + ' / ' + total + '</div>' +
        '<div class="result-rate">正确率 ' + (rate * 100).toFixed(0) + '%</div>' +
        '<div class="btn-row"><button class="btn primary" data-act="go" data-view="progress">看学习进度</button>' +
        '<button class="btn ghost" data-act="go" data-view="dashboard">返回首页</button></div></div>';
    } else {
      var ok = s.practiceSummary.ok, tot = s.practiceSummary.total;
      return '<div class="card result-card"><div class="result-emoji">✅</div><h2>本轮练习完成</h2>' +
        '<div class="result-score">' + ok + ' / ' + tot + '</div>' +
        '<p class="muted">错题已自动记入错题本。' + (ok < tot ? '建议复习对应知识点的「常见错误分析」。' : '全部答对，掌握得不错！') + '</p>' +
        '<div class="btn-row"><button class="btn primary" data-act="practice-start" data-scope="all">再来一批</button>' +
        '<button class="btn ghost" data-act="go" data-view="mistakes">查看错题本</button></div></div>';
    }
  }

  // ---------------- 视图：错题本 ----------------
  function vMistakes() {
    if (!DB.mistakes.length) {
      return '<div class="card empty"><div class="empty-emoji">📭</div><h3>还没有错题</h3><p class="muted">做完练习后，答错的题目会自动出现在这里。加油，错题是提分的金矿！</p>' +
        '<button class="btn primary" data-act="go" data-view="practice">去做几道题</button></div>';
    }
    var open = DB.mistakes.filter(function (m) { return m.status === 'open'; });
    var h = '<div class="card"><div class="mm-head"><h3>错题本</h3><span class="muted">共 ' + DB.mistakes.length + ' 道，待攻克 ' + open.length + ' 道</span></div>' +
      '<div class="filter-row"><button class="chip-btn ' + (state._mfilter !== 'open' ? '' : 'on') + '" data-act="mm-filter" data-f="all">全部</button>' +
      '<button class="chip-btn ' + (state._mfilter === 'open' ? 'on' : '') + '" data-act="mm-filter" data-f="open">待攻克</button></div></div>';
    var list = state._mfilter === 'open' ? open : DB.mistakes;
    list.slice().reverse().forEach(function (m) {
      var x = pointById(m.pointId);
      var errHtml = '';
      if (x && x.pt.errors && x.pt.errors.length) {
        errHtml = '<div class="mm-err"><div class="sec-h">⚠ 常见错误分析</div>';
        x.pt.errors.forEach(function (e) {
          errHtml += '<div class="err"><div class="err-w"><b>错：</b>' + esc(e.wrong) + '</div>' +
            '<div class="err-y"><b>因：</b>' + esc(e.why) + '</div>' +
            '<div class="err-r"><b>正：</b>' + esc(e.right) + '</div></div>';
        });
        errHtml += '</div>';
      }
      h += '<details class="mm-item"><summary><span class="mm-q">' + esc(m.q) + '</span>' +
        '<span class="mm-tag">' + esc(m.chapterName) + ' · ' + esc(m.pointName) + '</span></summary>' +
        '<div class="mm-body">' +
        '<div class="mm-line bad">你的答案：' + esc(m.userAns) + '</div>' +
        '<div class="mm-line ok">正确答案：' + esc(m.correctAns) + '</div>' +
        (m.tip ? '<div class="tip">💡 ' + esc(m.tip) + '</div>' : '') +
        errHtml +
        '<div class="btn-row">' +
        '<button class="btn small" data-act="practice-start" data-scope="pt:' + m.pointId + '">重练此题</button>' +
        '<button class="btn small ghost" data-act="mm-del" data-id="' + m.id + '">删除</button>' +
        '</div></div></details>';
    });
    return h;
  }

  // ---------------- 视图：常见错误库 ----------------
  function vErrors() {
    var h = '<div class="card intro-card"><p>这里按知识点汇总了<strong>常见错误分析</strong>：典型错法、出错原因与正确做法。考前浏览一遍，避开高频雷区。</p></div>';
    MC.chapters.forEach(function (ch) {
      var any = ch.points.filter(function (p) { return p.errors && p.errors.length; });
      if (!any.length) return;
      h += '<details class="chp-detail" open><summary><span class="chp-no">' + ch.no + '</span>' + ch.name + '</summary>';
      ch.points.forEach(function (pt) {
        if (!pt.errors || !pt.errors.length) return;
        h += '<details class="pt-detail"><summary><span class="pt-name">' + pt.name + '</span><span class="err-count">' + pt.errors.length + ' 处易错</span></summary>';
        h += '<div class="pt-body"><div class="sec err-sec"><div class="sec-h">⚠ 常见错误分析</div>';
        pt.errors.forEach(function (e) {
          h += '<div class="err"><div class="err-w"><b>错：</b>' + esc(e.wrong) + '</div>' +
            '<div class="err-y"><b>因：</b>' + esc(e.why) + '</div>' +
            '<div class="err-r"><b>正：</b>' + esc(e.right) + '</div></div>';
        });
        h += '</div></div>';
      });
      h += '</details>';
    });
    return h;
  }

  // ---------------- 视图：学习进度 ----------------
  function vProgress() {
    var total = allPoints().length;
    var mastered = masteredCount();
    var rate = overallRate();
    // 章节平均掌握度
    var chapStats = MC.chapters.map(function (ch) {
      var pts = ch.points;
      var sum = pts.reduce(function (a, p) { return a + levelOf(DB.progress[p.id]); }, 0);
      return { ch: ch, avg: pts.length ? sum / pts.length : 0, mas: pts.filter(function (p) { return levelOf(DB.progress[p.id]) >= 3; }).length, total: pts.length };
    });
    var h = '<div class="card"><h3>总体情况</h3><div class="overview">' +
      donut(rate, '正确率') +
      '<div class="ov-stats">' +
      ovStat('掌握知识点', mastered + ' / ' + total) +
      ovStat('练习总次数', totalPractice()) +
      ovStat('连续学习', streakDays() + ' 天') +
      ovStat('测验次数', DB.quizRuns.length) +
      '</div></div></div>';

    h += '<div class="card"><h3>各章掌握度</h3><div class="bars">' +
      chapStats.map(function (s) {
        return '<div class="bar-row"><div class="bar-name">' + s.ch.no + ' ' + s.ch.name + '</div>' +
          '<div class="bar-track"><div class="bar-fill lv' + Math.round(s.avg) + '" style="width:' + (s.avg / 4 * 100) + '%"></div></div>' +
          '<div class="bar-val">' + s.mas + '/' + s.total + ' · ' + (s.avg / 4 * 100).toFixed(0) + '%</div></div>';
      }).join('') + '</div></div>';

    // 知识点明细 + 学校进度
    h += '<div class="card"><h3>知识点明细</h3><div class="pt-table">';
    chapStats.forEach(function (s) {
      h += '<div class="ptg-title">' + s.ch.no + ' ' + s.ch.name + '　' +
        '<span class="sch-set">学校进度：' +
        ['none', 'doing', 'done'].map(function (st) {
          var on = (DB.schoolProg[s.ch.id] || 'none') === st;
          var txt = { none: '未学', doing: '在学', done: '学完' }[st];
          return '<button class="mini ' + (on ? 'on tag-' + st : '') + '" data-act="sch-set" data-chap="' + s.ch.id + '" data-st="' + st + '">' + txt + '</button>';
        }).join('') + '</span></div>';
      s.ch.points.forEach(function (p) {
        var lv = levelOf(DB.progress[p.id]);
        var pr = DB.progress[p.id] || { r: 0, w: 0 };
        h += '<div class="ptg-row" data-act="practice-start" data-scope="pt:' + p.id + '">' +
          '<span class="ptg-name">' + p.name + '</span>' + chip(lv) +
          '<span class="ptg-rw">练 ' + (pr.r + pr.w) + ' 次 · 对 ' + (pr.r || 0) + ' / 错 ' + (pr.w || 0) + '</span></div>';
      });
    });
    h += '</div></div>';
    return h;
  }
  function totalPractice() {
    var n = 0; Object.keys(DB.progress).forEach(function (k) { n += (DB.progress[k].r || 0) + (DB.progress[k].w || 0); }); return n;
  }
  function ovStat(label, val) { return '<div class="ov-stat"><div class="ov-val">' + val + '</div><div class="ov-label">' + label + '</div></div>'; }
  function donut(rate, label) {
    var pct = Math.max(0, Math.min(1, rate));
    var r = 52, c = 2 * Math.PI * r;
    var off = c * (1 - pct);
    return '<svg class="donut" viewBox="0 0 140 140" width="140" height="140">' +
      '<circle cx="70" cy="70" r="' + r + '" fill="none" stroke="#e8edf3" stroke-width="14"/>' +
      '<circle cx="70" cy="70" r="' + r + '" fill="none" stroke="#3b82f6" stroke-width="14" stroke-linecap="round" stroke-dasharray="' + c + '" stroke-dashoffset="' + off + '" transform="rotate(-90 70 70)"/>' +
      '<text x="70" y="66" text-anchor="middle" class="donut-pct">' + (pct * 100).toFixed(0) + '%</text>' +
      '<text x="70" y="88" text-anchor="middle" class="donut-lab">' + label + '</text></svg>';
  }

  // ---------------- 视图：设置 ----------------
  function vSettings() {
    return '<div class="card"><h3>我的资料</h3>' +
      '<div class="form-row"><label>昵称</label><input id="setName" value="' + esc(DB.settings.name) + '" /></div>' +
      '<div class="form-row"><label>主题</label><button class="chip-btn" data-act="theme-toggle">' + (DB.settings.theme === 'dark' ? '🌙 深色' : '☀ 浅色') + '</button></div>' +
      '<div class="btn-row"><button class="btn primary" data-act="save-settings">保存</button></div></div>' +
      '<div class="card"><h3>数据备份</h3>' +
      '<p class="muted">导出会把全部学习进度、错题、测验记录保存为文件；导入可换设备恢复。</p>' +
      '<div class="btn-row">' +
      '<button class="btn" data-act="export">导出备份</button>' +
      '<button class="btn" data-act="import">导入备份</button>' +
      '<input type="file" id="importFile" accept="application/json" style="display:none" />' +
      '</div></div>' +
      '<div class="card danger"><h3>重置</h3>' +
      '<p class="muted">清空全部学习数据（不可恢复），请谨慎操作。</p>' +
      '<div class="btn-row"><button class="btn danger-btn" data-act="reset">清空全部数据</button></div></div>';
  }

  // ---------------- 事件绑定 ----------------
  function bindOnce() {
    // 移动端菜单
    var mb = document.querySelector('[data-act="toggle-menu"]');
  }

  function onClick(e) {
    var el = e.target.closest('[data-act]');
    if (!el) return;
    var act = el.getAttribute('data-act');
    var sid;
    switch (act) {
      case 'go':
        var v = el.getAttribute('data-view');
        var chap = el.getAttribute('data-chap');
        if (chap) state._libChap = chap;
        D_go(v);
        break;
      case 'toggle-menu':
        document.body.classList.toggle('menu-open');
        break;
      case 'theme-toggle':
        DB.settings.theme = (DB.settings.theme === 'dark') ? 'light' : 'dark';
        saveDB(); render();
        break;
      case 'practice-start':
        startSession('practice', el.getAttribute('data-scope'));
        break;
      case 'quiz-start':
        startSession('quiz', 'all');
        break;
      case 'opt-pick':
        if (state.session && !state.session.submitted) { state.session.sel = el.getAttribute('data-opt'); render(); }
        break;
      case 'session-submit':
        sessionSubmit();
        break;
      case 'session-next':
        sessionNext();
        break;
      case 'session-quit':
        if (confirm('确定退出当前' + (state.session && state.session.mode === 'quiz' ? '测验' : '练习') + '？进度已记录。')) { state.session = null; render(); }
        break;
      case 'mm-filter':
        state._mfilter = el.getAttribute('data-f') === 'open' ? 'open' : null;
        render();
        break;
      case 'mm-del':
        sid = el.getAttribute('data-id');
        DB.mistakes = DB.mistakes.filter(function (m) { return m.id !== sid; });
        saveDB(); render(); toast('已删除');
        break;
      case 'sch-set':
        var cid = el.getAttribute('data-chap'), stt = el.getAttribute('data-st');
        DB.schoolProg[cid] = stt; saveDB(); render();
        break;
      case 'save-settings':
        var nm = document.getElementById('setName');
        if (nm && nm.value.trim()) { DB.settings.name = nm.value.trim(); DB.meta.owner = nm.value.trim(); saveDB(); toast('已保存'); }
        break;
      case 'export':
        exportData();
        break;
      case 'import':
        var f = document.getElementById('importFile');
        if (f) f.click();
        break;
      case 'reset':
        if (confirm('确定清空全部学习数据？此操作不可恢复！')) { DB = defaultDB(); saveDB(); render(); toast('已重置'); }
        break;
    }
  }

  function onInput(e) {
    if (e.target && e.target.id === 'fillInput' && state.session && !state.session.submitted) {
      state.session.input = e.target.value;
    }
    if (e.target && e.target.id === 'importFile') {
      handleImport(e.target.files[0]);
    }
  }
  function onKey(e) {
    if (e.key === 'Enter' && e.target && e.target.id === 'fillInput' && state.session && !state.session.submitted) {
      sessionSubmit();
    }
  }

  function exportData() {
    var blob = new Blob([JSON.stringify(DB, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = '九年级数学学习数据_' + todayKey() + '.json';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast('已导出备份');
  }
  function handleImport(file) {
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var data = JSON.parse(reader.result);
        if (!data || typeof data !== 'object') throw new Error('格式错误');
        DB = Object.assign(defaultDB(), data);
        saveDB(); render(); toast('导入成功');
      } catch (e) { alert('导入失败：文件格式不正确'); }
    };
    reader.readAsText(file);
  }

  // ---------------- 启动 ----------------
  function init() {
    MC = window.MATH_CONTENT;
    loadDB();
    document.addEventListener('click', onClick);
    document.addEventListener('input', onInput);
    document.addEventListener('keydown', onKey);
    render();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
