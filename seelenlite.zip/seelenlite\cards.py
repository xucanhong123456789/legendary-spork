# -*- coding: utf-8 -*-
"""
SeelenLite - cards.py
把应用窗口「整体等比缩小」成桌面卡片，再从卡片放大回指定尺寸。

渲染用 DWM 缩略图（DwmRegisterThumbnail）——和 Win11 任务栏预览同一套机制：
源窗口保持原来的尺寸和布局，只是被按比例画进卡片里，
所以文字、按钮、图片是一起变小的，不会重排、不会挤成一团。

交互（一件动作只做一件事，互不改写）：
  · 双击窗口标题栏    -> 窗口收成卡片（整体缩小）
  · 悬停卡片          -> 预览放大（只影响显示，不改卡片尺寸）
  · 单击卡片          -> 放大到「设置」里的展开尺寸（默认半屏，不强制全屏）
  · 卡片标题栏 ×      -> 关闭窗口（先把窗口移回屏幕内，避免确认框跑到屏幕外）
  · 卡片标题栏 ⤢      -> 放大
  · 拖动卡片          -> 摆放位置；拖右下角 -> 调整卡片大小（松手即生效、就地固定）
  · 展开后自己拖窗口边缘 -> 自动记住这个应用的尺寸，下次还用这个大小

悬停有两个硬约束，避免「缩放逻辑乱跳」：
  1. 只有卡片真的在最前面（光标下面是它，而不是盖住它的窗口）才放大；
  2. 刚拖/缩完的卡片不会立刻自动放大，必须等光标离开再回来。
"""
import time

from PyQt5.QtCore import (Qt, QRect, QObject, QTimer, QEasingCurve,
                          QPropertyAnimation, QAbstractAnimation, pyqtSignal)
from PyQt5.QtGui import (QPainter, QColor, QPen, QBrush, QFont, QFontMetrics,
                         QPainterPath, QCursor)
from PyQt5.QtWidgets import QWidget, QMenu

import win32api as w
from core import icon_for_exe, exe_of

CARD_MIN_W, CARD_MIN_H = 240, 160
CARD_MAX_W = 760
TITLE_H = 28
CORNER = 22              # 右下角缩放热区（像素）
PAD = 6
BTN = 20
OFFSCREEN_X = -16000     # 源窗口停放位置：屏幕外，尺寸不变

MENU_QSS = """
QMenu { background:#1b1d24; color:#f2f3f7; border:1px solid #3a3d47;
        border-radius:8px; padding:6px; font-family:'Microsoft YaHei'; font-size:12px;}
QMenu::item { padding:6px 20px; border-radius:6px; }
QMenu::item:selected { background:#0a84ff; }
QMenu::separator { height:1px; background:#3a3d47; margin:5px 8px; }
"""


class CardWindow(QWidget):
    """一块桌面卡片：标题栏（图标 + 名称 + 放大/关闭）+ 窗口实时缩略图。"""

    expand_requested = pyqtSignal(int)
    close_requested = pyqtSignal(int)
    original_requested = pyqtSignal(int)
    snap_requested = pyqtSignal(int, str)
    geometry_changed = pyqtSignal(int, QRect)
    source_gone = pyqtSignal(int)

    def __init__(self, src_hwnd, title, rect, icon=None, parent=None,
                 hover_enabled=True, hover_scale=1.14, anim_enabled=True):
        super().__init__(parent)
        self.src = int(src_hwnd)
        self.title = title or ""
        self.icon = icon
        self.thumb = 0
        self._press = None
        self._dragging = False
        self._resizing = False
        self._hover_btn = ""
        self._last_expand = 0.0
        self._btn_expand = QRect()
        self._btn_close = QRect()

        # ---- 动画 / 悬停状态 ----
        self._base_geom = QRect(rect)   # 不悬停时的「静止几何」，动画都朝它收敛
        self._anim = None               # QPropertyAnimation
        self._hover_on = False          # 当前是否处于悬停放大态
        self._hover_locked = False      # 入场动画等期间锁住悬停，避免自己打自己
        self._hover_block = False       # 刚拖/缩完：光标离开前不自动放大
        self._press_base = QRect(rect)  # 按下瞬间的静止基准，单击时原样还回去
        self._hover_enabled = bool(hover_enabled)
        self._hover_scale = float(hover_scale or 1.14)
        self._anim_enabled = bool(anim_enabled)
        self._hover_timer = None


        # 卡片是桌面上的普通窗口，不置顶：
        # 别的应用窗口切到前面时就该把卡片盖住，卡片只在桌面层安静地待着。
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.setWindowTitle("SeelenLite-Card")
        self.setGeometry(rect)
        self.show()

        self._layout_buttons()
        self._register()
        self._apply()
        self._drop_topmost()

        # 悬停用轮询而不是 enterEvent/leaveEvent：
        # 卡片本身在放大/缩小时几何一直在变，enter/leave 会来回抖，
        # 轮询「光标是否落在卡片内」得到的是确定状态，不会自激。
        if self._hover_enabled:
            self._hover_timer = QTimer(self)
            self._hover_timer.setInterval(120)
            self._hover_timer.timeout.connect(self._sync_hover)
            self._hover_timer.start()

    # ---------------- 缩略图 ----------------
    def _drop_topmost(self):
        """兜底：确保卡片不带 WS_EX_TOPMOST，绝不钉在别的应用窗口上面。"""
        try:
            h = int(self.winId())
            if w.get_exstyle(h) & w.WS_EX_TOPMOST:
                w.set_pos(h, w.HWND_NOTOPMOST, 0, 0, 0, 0,
                          w.SWP_NOMOVE | w.SWP_NOSIZE | w.SWP_NOACTIVATE)
        except Exception:
            pass

    def is_topmost(self):
        try:
            return bool(w.get_exstyle(int(self.winId())) & w.WS_EX_TOPMOST)
        except Exception:
            return False

    def _register(self):
        if self.thumb:
            return
        self.thumb = w.thumbnail_register(int(self.winId()), self.src) or 0

    def _thumb_rect(self):
        return QRect(PAD, TITLE_H,
                     max(1, self.width() - PAD * 2),
                     max(1, self.height() - TITLE_H - PAD))

    def _apply(self):
        if not self.thumb:
            return
        r = self._thumb_rect()
        w.thumbnail_set(self.thumb, r.x(), r.y(), r.width(), r.height(), True)

    def _layout_buttons(self):
        y = (TITLE_H - BTN) // 2 + 1
        self._btn_close = QRect(max(0, self.width() - BTN - 7), y, BTN, BTN)
        self._btn_expand = QRect(max(0, self.width() - BTN * 2 - 11), y, BTN, BTN)

    def refresh(self):
        if not w.is_window(self.src):
            self.source_gone.emit(self.src)
            return
        self._register()
        self._apply()

    # ---------------- 动画 ----------------
    def stop_anim(self):
        """立即停止几何动画，用于拖拽 / 关闭等需要确定几何的时刻。"""
        a = self._anim
        if a is not None:
            self._anim = None
            try:
                a.stop()
                a.deleteLater()
            except Exception:
                pass
        self._hover_locked = False

    def animate_to(self, target, duration=260, on_done=None, lock_hover=False,
                   curve=None):
        """平滑移动到目标几何；duration<=0 或关闭动画时立即到位。

        curve 可按场景指定：悬停要「立刻响应、快速收住」（OutQuart），
        窗口⇄卡片要「起步缓、中段快、落点稳」（InOutCubic），
        比一刀切的 OutCubic 更像系统原生动画。
        """
        target = QRect(target)
        self.stop_anim()
        if duration <= 0 or not self._anim_enabled or target == self.geometry():
            self.setGeometry(target)
            if on_done is not None:
                try:
                    on_done()
                except Exception:
                    pass
            return
        self._hover_locked = bool(lock_hover)
        a = QPropertyAnimation(self, b"geometry", self)
        a.setDuration(int(duration))
        a.setStartValue(self.geometry())
        a.setEndValue(target)
        a.setEasingCurve(curve if curve is not None else QEasingCurve.OutCubic)
        self._anim = a

        def _finished():
            if self._anim is a:
                self._anim = None
            self._hover_locked = False
            if on_done is not None:
                try:
                    on_done()
                except Exception:
                    pass

        a.finished.connect(_finished)
        a.start()

    # ---------------- 悬停放大 ----------------
    def _hover_rect(self):
        """以静止几何的中心放大，并夹进所在显示器工作区。"""
        g = QRect(self._base_geom)
        if not g.isValid():
            g = QRect(self.geometry())
        nw = max(CARD_MIN_W, int(round(g.width() * self._hover_scale)))
        nh = max(CARD_MIN_H, int(round(g.height() * self._hover_scale)))
        cx, cy = g.center().x(), g.center().y()
        r = QRect(cx - nw // 2, cy - nh // 2, nw, nh)
        try:
            mi = w.monitor_from_point(r.center().x(), r.center().y())
        except Exception:
            mi = None
        if mi:
            mx, my = mi.rcWork.left, mi.rcWork.top
            mw, mh = mi.rcWork.width, mi.rcWork.height
        else:
            mx, my, mw, mh = 0, 0, 1920, 1080
        x = max(mx + 2, min(r.x(), mx + mw - nw - 2))
        y = max(my + 2, min(r.y(), my + mh - nh - 2))
        return QRect(x, y, nw, nh)

    def _hit_test_self(self):
        """光标是不是真的落在这张卡片上（按 z 序判断，不只比矩形）。

        卡片不置顶，别的应用窗口可以盖在它上面。只看坐标是否落在矩形里，
        就会出现「鼠标在放大的窗口里移动，下面的卡片跟着乱放大」——
        被盖住时必须当作没被指到。
        """
        p = QCursor.pos()
        if not self.frameGeometry().contains(p):
            return False
        try:
            top = w.root_window(w.window_from_point(p.x(), p.y()))
        except Exception:
            return True   # 查询失败就退回几何判断，保证卡片还能用
        try:
            return int(top or 0) == int(self.winId())
        except Exception:
            return True

    def _sync_hover(self):
        """轮询光标位置决定放大/复原。

        用轮询而不是 enterEvent/leaveEvent：卡片在缩放时几何一直在变，
        进入/离开事件会互相触发形成抖动；按光标与卡片的真实关系判断是确定状态。
        """
        try:
            if not self._hover_enabled or self._hover_locked:
                return
            if self._press is not None or self._dragging or self._resizing:
                return
            if not self.isVisible():
                return
            inside = self._hit_test_self()
            if self._hover_block:
                # 刚拖完/缩完：光标原地不动就不再自动放大。
                # 否则用户拖好的尺寸会被悬停放大立刻改写，看起来像「自己弹了一下」。
                # 注意：只有在收缩动画播完、且光标真的在卡片外时才解锁。
                # 动画期间卡片一直在缩，光标会短暂落到矩形外，这时候解锁会导致
                # 「拖完自己又放大回去」——正是这次要修的 bug。
                if not inside and self._anim is None:
                    self._hover_block = False
                    self._hover_on = False
                    if self.geometry() != self._base_geom:
                        self.animate_to(self._base_geom, 160)
                return
            if inside == self._hover_on:
                return
            self._hover_on = inside
            if inside:
                # 不在这里 raise_()：卡片属于桌面层，悬停只是「预览放大」，
                # 不该因为鼠标划过就骑到用户正在用的窗口上面去。
                self.animate_to(self._hover_rect(), 190,
                                curve=QEasingCurve.OutQuart)
            else:
                self.animate_to(self._base_geom, 210)
        except Exception:
            pass


    def halt_hover(self):
        """彻底停掉悬停轮询。

        卡片即将被展开/还原动画接管（或者马上要被销毁）时用，
        避免轮询在半路插一脚、把正在播放的动画顶掉。
        """
        self._hover_enabled = False
        self._hover_on = False
        self._hover_block = False
        if self._hover_timer is not None:
            try:
                self._hover_timer.stop()
            except Exception:
                pass

    def set_hover_enabled(self, enabled):
        """运行时开关悬停放大（设置面板改完立即生效，不用重建卡片）。"""
        enabled = bool(enabled)
        if enabled == self._hover_enabled:
            return
        self._hover_enabled = enabled
        self._hover_block = False
        if enabled:
            if self._hover_timer is None:
                self._hover_timer = QTimer(self)
                self._hover_timer.setInterval(120)
                self._hover_timer.timeout.connect(self._sync_hover)
                self._hover_timer.start()
        else:
            if self._hover_timer is not None:
                try:
                    self._hover_timer.stop()
                except Exception:
                    pass
                self._hover_timer = None
            if self._hover_on:
                self._hover_on = False
                self.animate_to(self._base_geom, 160)

    def dispose(self):
        if self._hover_timer is not None:
            try:
                self._hover_timer.stop()
            except Exception:
                pass
            self._hover_timer = None
        self.stop_anim()
        if self.thumb:
            w.thumbnail_unregister(self.thumb)
            self.thumb = 0
        self.hide()
        self.deleteLater()

    def set_title(self, title):
        if title and title != self.title:
            self.title = title
            self.update()

    # ---------------- 绘制 ----------------
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = self.rect()
        path = QPainterPath()
        path.addRoundedRect(0.5, 0.5, r.width() - 1, r.height() - 1, 12, 12)
        p.setPen(QPen(QColor(255, 255, 255, 40), 1))
        p.setBrush(QBrush(QColor(20, 22, 29, 255)))
        p.drawPath(path)

        # 标题栏文字
        f = QFont("Microsoft YaHei")
        f.setPixelSize(11)
        p.setFont(f)
        fm = QFontMetrics(f)
        x = 10
        if self.icon is not None and not self.icon.isNull():
            p.drawPixmap(QRect(9, (TITLE_H - 14) // 2, 14, 14),
                         self.icon.pixmap(14, 14))
            x = 28
        avail = max(10, self._btn_expand.left() - x - 6)
        txt = fm.elidedText(self.title, Qt.ElideRight, avail)
        p.setPen(QPen(QColor(234, 236, 242)))
        p.drawText(QRect(x, 1, avail, TITLE_H - 2),
                   Qt.AlignVCenter | Qt.AlignLeft, txt)

        # 右侧按钮
        self._draw_btn(p, self._btn_close, "close", self._hover_btn == "close")
        self._draw_btn(p, self._btn_expand, "expand", self._hover_btn == "expand")

        # 标题栏分隔线
        p.setPen(QPen(QColor(255, 255, 255, 20), 1))
        p.drawLine(PAD, TITLE_H - 1, r.width() - PAD, TITLE_H - 1)

        if not self.thumb:
            p.setPen(QPen(QColor(255, 255, 255, 110)))
            p.setFont(f)
            p.drawText(self._thumb_rect(), Qt.AlignCenter, "无法预览，单击展开")

    def _draw_btn(self, p, rect, kind, hover):
        if hover:
            p.setPen(Qt.NoPen)
            p.setBrush(QBrush(QColor(255, 255, 255, 38)))
            p.drawRoundedRect(rect, 6, 6)
        c = QColor(255, 120, 110) if (kind == "close" and hover) else QColor(226, 229, 236)
        p.setPen(QPen(c, 1.3))
        p.setBrush(Qt.NoBrush)
        cx, cy = rect.center().x() + 0.5, rect.center().y() + 0.5
        d = 3.6
        if kind == "close":
            p.drawLine(int(cx - d), int(cy - d), int(cx + d), int(cy + d))
            p.drawLine(int(cx + d), int(cy - d), int(cx - d), int(cy + d))
        else:
            # 两个对角箭头，表示「放大」
            p.drawLine(int(cx - d), int(cy + 1), int(cx + d), int(cy - d + 1))
            p.drawLine(int(cx + d - 3), int(cy - d + 1), int(cx + d), int(cy - d + 1))
            p.drawLine(int(cx + d), int(cy - d + 1), int(cx + d), int(cy - d + 4))

    # ---------------- 交互 ----------------
    def _expand(self):
        now = time.time()
        if now - self._last_expand < 0.35:
            return
        self._last_expand = now
        self.expand_requested.emit(self.src)

    def mousePressEvent(self, e):
        pos = e.pos()
        if e.button() == Qt.RightButton:
            self._menu(e.globalPos())
            return
        if e.button() != Qt.LeftButton:
            return
        if self._btn_close.contains(pos):
            self.close_requested.emit(self.src)
            return
        if self._btn_expand.contains(pos):
            self._expand()
            return
        # 按下只锁住悬停，不急着改静止基准：
        # 1) 从「悬停放大后的尺寸」开始拖/缩时，用眼前的几何做起点，手感和看到的一致；
        # 2) 但如果只是单击（展开），这次临时放大的尺寸不能变成新的卡片基准，
        #    否则连点几下，卡片会一次比一次大。
        self.stop_anim()
        self._hover_on = False
        self._hover_locked = True
        self._press_base = QRect(self._base_geom)
        self._press = e.globalPos()
        self._dragging = False
        self._resizing = self._in_corner(pos)
        self.raise_()


    def mouseMoveEvent(self, e):
        if not (e.buttons() & Qt.LeftButton):
            hover = ""
            if self._btn_close.contains(e.pos()):
                hover = "close"
            elif self._btn_expand.contains(e.pos()):
                hover = "expand"
            if hover != self._hover_btn:
                self._hover_btn = hover
                self.update()
            self.setCursor(Qt.SizeFDiagCursor if self._in_corner(e.pos()) else Qt.ArrowCursor)
            return
        if self._press is None:
            return
        d = e.globalPos() - self._press
        if not self._dragging and not self._resizing and d.manhattanLength() > 4:
            self._dragging = True
        if self._resizing:
            nw = max(CARD_MIN_W, min(CARD_MAX_W, self.width() + d.x()))
            nh = max(CARD_MIN_H, self.height() + d.y())
            self.resize(nw, nh)
            self._layout_buttons()
            self._apply()
            self.update()
            self._press = e.globalPos()
        elif self._dragging:
            self.move(self.pos() + d)
            self._press = e.globalPos()

    def mouseReleaseEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        if self._press is None:
            # 这一下按在关闭/放大按钮上，按下时已经处理过了，别再当成单击展开
            return
        was_click = not (self._dragging or self._resizing)
        was_resize = self._resizing
        # 先把按下状态清干净，再做动作：
        # 展开动画会自己把悬停锁上（lock_hover=True），如果这里在它之后再去解锁，
        # 悬停轮询就会立刻打断展开动画——卡片放大到一半停下，源窗口留在屏幕外。
        self._hover_on = False
        self._press = None
        self._dragging = False
        self._resizing = False
        self._hover_locked = False
        if was_click:
            # 单击 = 展开。悬停造成的临时放大不算数，基准原样还回去
            self._base_geom = QRect(self._press_base)
            self._expand()
            return
        if was_resize:
            # 拖右下角 = 用户明确在改尺寸：眼前这个几何就是要的尺寸，直接定成基准。
            # 锁定悬停，光标不动就不会再放大，刚调好的尺寸不会被改写。
            self._base_geom = QRect(self.geometry())
            self._hover_block = True
            self.geometry_changed.emit(self.src, self._base_geom)
            return
        # 只拖动位置：尺寸必须沿用按下前的基准，不能拿悬停放大后的几何当尺寸。
        # 悬停放大是围绕中心放大的，回缩也围绕中心，卡片不会往边上跑。
        base = QRect(self._press_base)
        base.moveCenter(self.geometry().center())
        self._base_geom = base
        self._hover_block = True
        if self.geometry() != base:
            self.animate_to(base, 170)   # 平滑收回到手动调节的尺寸
        self.geometry_changed.emit(self.src, base)

    def mouseDoubleClickEvent(self, e):
        if e.button() == Qt.LeftButton and e.pos().y() <= TITLE_H:
            self._expand()

    def _in_corner(self, pos):
        # 右下角缩放热区：稍微放宽一点，鼠标更容易抓得住
        return (pos.x() >= self.width() - CORNER
                and pos.y() >= self.height() - CORNER)

    def resizeEvent(self, e):
        self._layout_buttons()
        self._apply()
        self.update()
        super().resizeEvent(e)

    def _menu(self, gpos):
        m = QMenu(self)
        m.setStyleSheet(MENU_QSS)
        a = m.addAction("放大")
        a.triggered.connect(self._expand)
        a = m.addAction("还原到桌面（保持原大小）")
        a.triggered.connect(lambda: self.original_requested.emit(self.src))
        m.addSeparator()
        a = m.addAction("左半屏")
        a.triggered.connect(lambda: self.snap_requested.emit(self.src, "left"))
        a = m.addAction("右半屏")
        a.triggered.connect(lambda: self.snap_requested.emit(self.src, "right"))
        a = m.addAction("整屏")
        a.triggered.connect(lambda: self.snap_requested.emit(self.src, "full"))
        m.addSeparator()
        a = m.addAction("关闭窗口")
        a.triggered.connect(lambda: self.close_requested.emit(self.src))
        m.exec_(gpos)


# ================================================================== 管理器
class CardManager(QObject):
    """管理「窗口 <-> 卡片 <-> 放大尺寸」的转换。"""

    changed = pyqtSignal()

    def __init__(self, wm, settings, parent=None):
        super().__init__(parent)
        self.wm = wm
        self.settings = settings
        self.cards = {}       # src_hwnd -> CardWindow
        self.saved = {}       # src_hwnd -> {'rect','max','exe'}
        self.last_geom = {}   # src_hwnd -> QRect（卡片位置，下次缩回用）
        self._settle_until = 0.0
        self._last_fg = 0
        self._watch = {}      # hwnd -> [exe, [x,y,w,h], ts]
        self.expanded = set()  # 被我们放大摆到桌面上的窗口（ESC 要能缩回去）
        self._next_recover = time.time() + 3.0  # 运行期出界窗口巡检节流
        self._expanding = set()   # 正在播放大动画的窗口，防止重复触发
        self._anim_pending = {}   # hwnd -> (card, info, rect)，动画中途退出时的兜底
        self._restored_keys = set()  # 启动时已经恢复过的 exe，避免重复处理
        # hwnd -> [exe, [x,y,w,h](还原尺寸), maxed, 待写盘时间]
        # 常驻跟踪所有普通窗口：不只是卡片/放大过的窗口，
        # 否则用户手动挪一下普通窗口，重启后位置就丢了。
        self._live = {}
        # 启动后 6.5 秒内不跟踪：这段时间窗口还停在应用自己的默认位置，
        # 写盘会把还没恢复的存档直接盖掉。定时恢复（1.5s / 5s）先跑完。
        self._boot_until = time.time() + 6.5
        self.auto_restore = True   # 自测模式关掉，避免存档干扰用例

    # ---------------- 查询 ----------------
    def is_card(self, hwnd):
        return int(hwnd) in self.cards

    def count(self):
        return len(self.cards)

    def card_widgets(self):
        return list(self.cards.values())

    # ---------------- 缩成卡片 ----------------
    def cardify(self, hwnd, geom=None, animate=True):
        hwnd = int(hwnd)
        if hwnd in self.cards:
            return True
        if not w.is_window(hwnd) or not w.is_visible(hwnd):
            return False
        title = w.get_title(hwnd)
        if not title:
            return False

        maxed = w.is_zoomed(hwnd)
        if maxed:
            w.show(hwnd, w.SW_RESTORE)
            time.sleep(0.02)

        l, t, ww, hh = w.get_rect(hwnd)
        if ww < 160 or hh < 110:
            if maxed:
                w.show(hwnd, w.SW_SHOWMAXIMIZED)
            return False

        exe = ""
        try:
            exe = exe_of(w.get_pid(hwnd)) or ""
        except Exception:
            exe = ""

        if geom is None:
            geom = self.last_geom.get(hwnd)
        if geom is None or not geom.isValid():
            geom = self._default_rect(l, t, ww, hh)
        target = self._clamp_card(geom)

        try:
            icon = icon_for_exe(exe)
        except Exception:
            icon = None

        # 入场几何让「缩略图区域」正好盖住源窗口原来的屏幕位置：
        # 第一帧画面与真实窗口重合，再平滑缩成卡片，不会出现内容跳一下。
        start = QRect(l - PAD, t - TITLE_H, ww + PAD * 2, hh + TITLE_H + PAD)
        card = CardWindow(hwnd, title, start, icon,
                          hover_enabled=getattr(self.settings, "card_hover", True),
                          hover_scale=getattr(self.settings, "card_hover_scale", 1.14),
                          anim_enabled=getattr(self.settings, "card_anim", True))
        card._base_geom = QRect(target)
        card.expand_requested.connect(self.expand)
        card.close_requested.connect(self.close_source)
        card.original_requested.connect(self.restore_original)
        card.snap_requested.connect(self.expand_snap)
        card.geometry_changed.connect(self._on_geom)
        card.source_gone.connect(self.dispose)

        self.cards[hwnd] = card
        self.expanded.discard(hwnd)
        self.saved[hwnd] = {"rect": (l, t, ww, hh), "max": maxed, "exe": exe}
        self.last_geom[hwnd] = QRect(target)
        try:
            cid = int(card.winId())
            self.wm.own_hwnds.add(cid)
            self.wm.card_hwnds.add(cid)
        except Exception:
            pass

        # 源窗口整体挪到屏幕外：尺寸一点没变，内容不会重排
        w.set_pos(hwnd, 0, OFFSCREEN_X, 0, ww, hh,
                  w.SWP_NOZORDER | w.SWP_NOACTIVATE)
        if animate and getattr(self.settings, "card_anim", True):
            # OutCubic：第一帧就动起来，末段慢慢收住。
            # InOutCubic 前几帧几乎不动，观感上像「卡了一下才开始缩」。
            card.animate_to(target, 300, lock_hover=True,
                            curve=QEasingCurve.OutCubic)
        else:
            card.setGeometry(target)
        self._save_state(hwnd, "card", rect=(l, t, ww, hh), card=target, maxed=maxed)
        self._settle_until = time.time() + 0.9
        self.changed.emit()
        return True

    def _clamp_card(self, rect):
        mi = w.monitor_from_point(rect.center().x(), rect.center().y())
        if mi:
            mx, my = mi.rcWork.left, mi.rcWork.top
            mw, mh = mi.rcWork.width, mi.rcWork.height
        else:
            mx, my, mw, mh = 0, 0, 1920, 1080
        cw = max(CARD_MIN_W, min(CARD_MAX_W, rect.width()))
        ch = max(CARD_MIN_H, rect.height())
        x = max(mx + 4, min(rect.x(), mx + mw - cw - 4))
        y = max(my + 4, min(rect.y(), my + mh - ch - 4))
        return QRect(x, y, cw, ch)

    def _default_rect(self, l, t, ww, hh):
        mi = w.monitor_from_point(l + ww // 2, t + hh // 2)
        if mi:
            mx, my = mi.rcWork.left, mi.rcWork.top
            mw, mh = mi.rcWork.width, mi.rcWork.height
        else:
            mx, my, mw, mh = 0, 0, 1920, 1080
        scale = getattr(self.settings, "card_scale", 0.32)
        cw = int(ww * scale)
        cw = max(CARD_MIN_W, min(int(mw * 0.42), min(CARD_MAX_W, cw)))
        ratio = (hh / float(ww)) if ww else 0.62
        ch = int((cw - PAD * 2) * ratio) + TITLE_H + PAD
        ch = max(CARD_MIN_H, min(ch, int(mh * 0.52)))
        idx = len(self.cards) % 6
        x = mx + 40 + idx * 36
        y = my + 56 + idx * 32
        return QRect(x, y, cw, ch)

    # ---------------- 展开 ----------------
    def expand_rect(self, hwnd, info=None):
        """算出这个窗口该展开成多大：优先用记忆尺寸，否则按设置里的比例（保持原宽高比）。"""
        src = (info or {}).get("rect")
        # 展开到「用户当前视线所在的屏」= 光标所在显示器。
        # 绝不能按源窗口位置找屏：卡片源停在 -16000，MONITOR_DEFAULTTONEAREST
        # 会把它就近判到左边副屏，于是每次展开都跑到副屏、留下负坐标记忆。
        mi = None
        try:
            cx, cy = w.cursor_pos()
            mi = w.monitor_from_point(cx, cy)
        except Exception:
            mi = None
        if mi is None:
            try:
                mi = w.monitor_from_window(hwnd)
            except Exception:
                mi = None
        if mi:
            wx, wy = mi.rcWork.left, mi.rcWork.top
            W, H = mi.rcWork.width, mi.rcWork.height
        else:
            wx, wy, W, H = 0, 0, 1920, 1040

        exe = (info or {}).get("exe") or ""
        # 优先用完整窗口状态里记的「放大态」位置尺寸：
        # 它比 per_app_size 更准（区分卡片/放大/普通三种态）。
        st = self.settings.recall_window(exe)
        if st and st.get("mode") == "expanded":
            sr = st.get("rect")
            if sr and len(sr) == 4:
                try:
                    x, y, ww, hh = [int(v) for v in sr]
                    ww = max(400, min(W - 40, ww))
                    hh = max(300, min(H - 40, hh))
                    x = max(wx + 4, min(x, wx + W - ww - 4))
                    y = max(wy + 4, min(y, wy + H - hh - 4))
                    return (x, y, ww, hh)
                except Exception:
                    pass
        memo = self.settings.recall_size(exe)
        if memo:
            x, y, ww, hh = memo
            ww = max(400, min(W - 40, ww))
            hh = max(300, min(H - 40, hh))
            # 记忆的 x/y 可能来自别的屏（含负坐标），一律夹回当前目标屏
            x = max(wx + 4, min(x, wx + W - ww - 4))
            y = max(wy + 4, min(y, wy + H - hh - 4))
            return (x, y, ww, hh)

        src = (info or {}).get("rect") or (0, 0, 1280, 800)
        sw, sh = max(320, src[2]), max(240, src[3])
        aspect = max(0.55, min(2.6, sw / float(sh)))

        preset = getattr(self.settings, "expand_preset", "half")
        ratio = {"full": 1.0, "wide": 0.75, "half": 0.5,
                 "custom": getattr(self.settings, "expand_ratio", 0.62)}.get(preset, 0.5)
        ww = W * ratio
        hh = ww / aspect
        # 别超出工作区
        if hh > H * 0.94:
            hh = H * 0.94
            ww = hh * aspect
        # 最小可读尺寸：避免缩得太小、内容挤成一团
        min_w, min_h = min(760, W * 0.9), min(520, H * 0.9)
        if ww < min_w:
            k = min_w / ww
            ww, hh = ww * k, hh * k
        if hh < min_h:
            k = min_h / hh
            ww, hh = ww * k, hh * k
        if ww > W:
            ww, hh = W, W / aspect
        if hh > H * 0.94:
            hh, ww = H * 0.94, (H * 0.94) * aspect
        ww, hh = int(ww), int(hh)
        return (wx + (W - ww) // 2, wy + (H - hh) // 2, ww, hh)

    def _snap_rect(self, hwnd, where, info=None):
        src = (info or {}).get("rect")
        mi = None
        if src and len(src) == 4:
            mi = w.monitor_from_point(src[0] + src[2] // 2, src[1] + src[3] // 2)
        if mi is None:
            mi = w.monitor_from_window(hwnd)
        if mi:
            wx, wy = mi.rcWork.left, mi.rcWork.top
            W, H = mi.rcWork.width, mi.rcWork.height
        else:
            wx, wy, W, H = 0, 0, 1920, 1040
        if where == "full":
            return (wx, wy, W, H)
        if where == "left":
            return (wx, wy, W // 2, H)
        if where == "right":
            return (wx + W // 2, wy, W - W // 2, H)
        return None

    def expand(self, hwnd, rect=None, where=None, animate=True):
        hwnd = int(hwnd)
        if hwnd in self._expanding:
            return False
        card = self.cards.pop(hwnd, None)
        info = self.saved.pop(hwnd, None)
        self._watch.pop(hwnd, None)

        if not w.is_window(hwnd):
            if card is not None:
                self._forget_window(card)
                card.dispose()
            self.last_geom.pop(hwnd, None)
            self.changed.emit()
            return False

        if info is None:
            # 直接从桌面上的窗口展开：用它当前的位置尺寸算比例
            try:
                info = {"exe": exe_of(w.get_pid(hwnd)) or "", "rect": w.get_rect(hwnd)}
            except Exception:
                info = None

        try:
            w.show(hwnd, w.SW_RESTORE)
        except Exception:
            pass

        if rect is None:
            if where:
                rect = self._snap_rect(hwnd, where, info) or self.expand_rect(hwnd, info)
            else:
                rect = self.expand_rect(hwnd, info)

        x, y, ww, hh = rect
        # 缩回卡片前它是最大化的：展开时要把最大化状态还回去，
        # 但保存的 rect 仍是「还原后」的尺寸，不能是铺满屏幕的矩形。
        remax = bool(info and info.get("max")) and where is None
        settled = {"done": False}

        def _finish():
            # 幂等：动画结束信号 + 兜底定时器都可能走到这里，只允许落地一次
            if settled["done"]:
                return
            settled["done"] = True
            self._expanding.discard(hwnd)
            self._anim_pending.pop(hwnd, None)
            if hwnd in self.cards:
                # 动画期间又被缩成卡片了：这次展开作废，别把窗口抢回桌面
                return
            try:
                w.set_pos(hwnd, w.HWND_TOP, x, y, ww, hh,
                          w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
                w.focus(hwnd)
                if remax:
                    w.show(hwnd, w.SW_MAXIMIZE)
            except Exception:
                pass
            if card is not None:
                self._forget_window(card)
                card.dispose()
            if info:
                self._watch[hwnd] = [info.get("exe", ""), [x, y, ww, hh], time.time()]
            self.expanded.add(hwnd)
            self._last_fg = hwnd
            self._settle_until = time.time() + 0.7
            self._save_state(hwnd, "expanded", rect=(x, y, ww, hh), maxed=remax)
            self.changed.emit()

        if card is not None and animate and getattr(self.settings, "card_anim", True):
            # 卡片先放大到「缩略图区域正好等于目标窗口」的几何，落地瞬间再换成真窗口，
            # 画面是连续放大的，不会先闪一下再出现。
            self._expanding.add(hwnd)
            self._anim_pending[hwnd] = (card, info, (x, y, ww, hh))
            end = QRect(x - PAD, y - TITLE_H, ww + PAD * 2, hh + TITLE_H + PAD)
            card.halt_hover()
            card.animate_to(end, 300, on_done=_finish, lock_hover=True,
                            curve=QEasingCurve.OutCubic)
            # 兜底：动画万一被别的事情打断（卡片被销毁、事件被吞），
            # 到点也必须把源窗口摆回桌面，绝不能把它留在屏幕外。
            QTimer.singleShot(560, _finish)
            return True

        self._anim_pending.pop(hwnd, None)
        _finish()
        return True

    def is_expanded(self, hwnd):
        return int(hwnd) in self.expanded

    def on_activated(self, hwnd):
        """某个窗口被激活：如果它是我们缩成卡片的窗口，就展开它。

        用户从任务栏 / Alt+Tab 切回一个停在屏幕外的窗口时，画面立刻回到桌面，
        不会出现「点了没反应、窗口找不到也关不掉」的情况。
        """
        hwnd = int(hwnd or 0)
        if hwnd in self.cards and time.time() >= self._settle_until:
            self.expand(hwnd)

    def expand_snap(self, hwnd, where):
        return self.expand(hwnd, where=where)

    def restore_original(self, hwnd, animate=True, persist=True):
        """卡片 -> 回到原来的位置和大小（不放大）。

        persist=False 用于退出程序：只负责把窗口摆回桌面，不许再写状态。
        否则退出时会把「卡片态」覆盖成「普通态」，还会用展开那一刻的旧尺寸
        覆盖用户刚调好的新尺寸 —— 重启后自然什么记忆都没了。
        """
        hwnd = int(hwnd)
        if hwnd in self._expanding:
            return False
        card = self.cards.pop(hwnd, None)
        info = self.saved.pop(hwnd, None)
        self._watch.pop(hwnd, None)
        self.expanded.discard(hwnd)

        settled = {"done": False}

        def _finish():
            if settled["done"]:
                return
            settled["done"] = True
            self._expanding.discard(hwnd)
            self._anim_pending.pop(hwnd, None)
            if hwnd in self.cards:
                return
            if w.is_window(hwnd) and info:
                r = info["rect"]
                try:
                    w.show(hwnd, w.SW_RESTORE)
                    w.set_pos(hwnd, w.HWND_TOP, r[0], r[1], r[2], r[3],
                              w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
                    w.focus(hwnd)
                except Exception:
                    pass
                if persist:
                    self._save_state(hwnd, "normal", rect=r, maxed=False)
            if card is not None:
                self._forget_window(card)
                card.dispose()
            self.changed.emit()

        if card is not None and info and animate and getattr(self.settings, "card_anim", True):
            r = info["rect"]
            end = QRect(r[0] - PAD, r[1] - TITLE_H,
                        r[2] + PAD * 2, r[3] + TITLE_H + PAD)
            self._expanding.add(hwnd)
            self._anim_pending[hwnd] = (card, info, (r[0], r[1], r[2], r[3]))
            card.halt_hover()
            card.animate_to(end, 300, on_done=_finish, lock_hover=True,
                            curve=QEasingCurve.OutCubic)
            QTimer.singleShot(560, _finish)
            return True
        _finish()
        return True

    def close_source(self, hwnd):
        """关闭被卡片化的窗口。

        关键：先把窗口挪回屏幕内再发 WM_CLOSE，
        这样「是否保存」这类确认框不会出现在屏幕外让人以为程序卡死。
        """
        hwnd = int(hwnd)
        info = self.saved.get(hwnd)
        if w.is_window(hwnd) and info:
            try:
                r = info["rect"]
                w.show(hwnd, w.SW_RESTORE)
                w.set_pos(hwnd, w.HWND_TOP, r[0], r[1], r[2], r[3],
                          w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
            except Exception:
                pass
        if w.is_window(hwnd):
            try:
                w.post_close(hwnd)
            except Exception:
                pass
        # 关掉的窗口记成「普通态 + 原位置」：下次这个应用再打开，就回到原位
        if info:
            # 应用是被关掉的：位置尺寸沿用缩回前记录的值，
            # 最大化状态也保留，下次这个应用再启动就按同样的状态打开。
            self._save_state(hwnd, "normal", rect=info.get("rect"),
                             maxed=info.get("max"))
        # 卡片先移除：若用户在弹出的确认框里点了「取消」，窗口就留在桌面原位
        self.dispose(hwnd)
        return True

    def restore_all(self, animate=False, persist=True):
        """把所有卡片窗口还原到桌面。

        默认 animate=False 走同步路径：退出程序时必须立刻落地，
        不能依赖动画的信号回调（事件循环马上要结束了）。
        persist=False 时只摆窗口、不改持久化状态（退出流程用）。
        """
        for h in list(self.cards.keys()):
            try:
                self.restore_original(h, animate=animate, persist=persist)
            except Exception:
                pass

        # 正在播放大动画、还没落地的窗口：立刻把源窗口摆回记录位置
        for h, (card, info, rect) in list(self._anim_pending.items()):
            try:
                if card is not None:
                    card.stop_anim()
                r = (info or {}).get("rect") or rect
                if w.is_window(h) and r:
                    try:
                        w.show(h, w.SW_RESTORE)
                        w.set_pos(h, w.HWND_TOP, r[0], r[1], r[2], r[3],
                                  w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
                    except Exception:
                        pass
                    if persist:
                        self._save_state(h, "normal", rect=r, maxed=False)
                if card is not None:
                    self._forget_window(card)
                    card.dispose()
            except Exception:
                pass
            self._anim_pending.pop(h, None)
            self._expanding.discard(h)

    def dispose(self, hwnd):
        hwnd = int(hwnd)
        card = self.cards.pop(hwnd, None)
        if card is not None:
            self._forget_window(card)
            card.dispose()
        self.saved.pop(hwnd, None)
        self._watch.pop(hwnd, None)
        self._live.pop(hwnd, None)
        self.expanded.discard(hwnd)
        self._expanding.discard(hwnd)
        self._anim_pending.pop(hwnd, None)
        self.changed.emit()

    def _forget_window(self, card):
        try:
            cid = int(card.winId())
            self.wm.own_hwnds.discard(cid)
            self.wm.card_hwnds.discard(cid)
        except Exception:
            pass

    def _on_geom(self, hwnd, rect):
        hwnd = int(hwnd)
        self.last_geom[hwnd] = QRect(rect)
        # 卡片被拖动/缩放过：把这套坐标记下来，重启后卡片还在这个位置这个大小
        self._save_state(hwnd, "card",
                         card=(rect.x(), rect.y(), rect.width(), rect.height()))

    # ---------------- 状态持久化 ----------------
    def _save_state(self, hwnd, mode, rect=None, card=None, maxed=None):
        """把这个窗口的状态写进配置：位置尺寸 + 卡片/放大/普通 + 是否最大化。

        rect 必须是「还原后」的位置尺寸。最大化窗口要传 normal_rect()，
        不能传 get_rect()，否则会把铺满屏幕的矩形当成正常尺寸存下来。
        """
        try:
            hwnd = int(hwnd)
            exe = ""
            info = self.saved.get(hwnd)
            if info:
                exe = info.get("exe") or ""
            if not exe and w.is_window(hwnd):
                try:
                    exe = exe_of(w.get_pid(hwnd)) or ""
                except Exception:
                    exe = ""
            if not exe:
                return
            cr = None
            if card is None and mode == "card":
                cw = self.cards.get(hwnd)
                if cw is not None:
                    # 悬停预览放大的几何不能写进存档：用静止基准
                    b = getattr(cw, "_base_geom", None)
                    g = QRect(b) if isinstance(b, QRect) and b.isValid() else QRect(cw.geometry())
                    cr = (g.x(), g.y(), g.width(), g.height())
            elif card is not None:
                if isinstance(card, QRect):
                    cr = (card.x(), card.y(), card.width(), card.height())
                else:
                    cr = tuple(card)
            rr = tuple(rect) if rect is not None else None
            self.settings.remember_window(exe, rr, mode, cr, maxed=maxed)
            # 同步内存里的记录，退出还原时不能再用展开那一刻的旧尺寸
            if info is not None:
                if rr is not None:
                    info["rect"] = rr
                if maxed is not None:
                    info["max"] = bool(maxed)
        except Exception:
            pass

    def _clamp_to_visible(self, rect, work=None):
        """把一组坐标夹回某个可见工作区（优先选交集最大的那块屏）。"""
        if work is None:
            try:
                work = w.enum_monitor_work_rects()
            except Exception:
                work = [(0, 0, 1920, 1040)]
        try:
            x, y, ww, hh = [int(v) for v in rect]
        except Exception:
            return [40, 40, 1200, 800]
        best, best_area = None, -1
        for (rx, ry, rw, rh) in work:
            ix = max(0, min(x + ww, rx + rw) - max(x, rx))
            iy = max(0, min(y + hh, ry + rh) - max(y, ry))
            area = ix * iy
            if area > best_area:
                best_area, best = area, (rx, ry, rw, rh)
        rx, ry, rw, rh = best or (0, 0, 1920, 1040)
        nw = max(320, min(ww, rw - 8))
        nh = max(240, min(hh, rh - 8))
        nx = max(rx + 4, min(x, rx + rw - nw - 4))
        ny = max(ry + 4, min(y, ry + rh - nh - 4))
        return [nx, ny, nw, nh]

    def _apply_state(self, h, exe, st, work=None):
        """按存档摆好一个窗口：位置尺寸 + 最大化状态；卡片态重建卡片。

        最大化必须「先按正常尺寸摆好，再 ShowWindow(SW_MAXIMIZE)」：
        直接把最大化矩形 SetWindowPos 过去，系统会认为那就是还原尺寸，
        下次取消最大化就回不到原来的窗口大小。
        """
        if not w.is_window(h) or not isinstance(st, dict):
            return False
        mode = st.get("mode", "normal")
        rect = st.get("rect")
        cgeom = st.get("card")
        maxed = bool(st.get("max"))
        key = self.settings.exe_key(exe)

        if mode == "card" and cgeom and len(cgeom) == 4:
            # 先把源窗口摆回记录中的位置，卡片化的 saved["rect"] 才是对的
            if rect and len(rect) == 4:
                rr = self._clamp_to_visible(rect, work)
                try:
                    w.show(h, w.SW_RESTORE)
                    w.set_pos(h, w.HWND_TOP, rr[0], rr[1], rr[2], rr[3],
                              w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
                except Exception:
                    pass
            cg = QRect(int(cgeom[0]), int(cgeom[1]),
                       int(cgeom[2]), int(cgeom[3]))
            if self.cardify(h, cg, animate=False):
                # 卡片化会先把源窗口还原成普通窗口；记住「缩回前是最大化」，
                # 从卡片展开时还能恢复最大化。
                rec = self.saved.get(h)
                if rec is not None:
                    rec["max"] = maxed
                self._live.pop(h, None)
                return True
            return False

        if not (rect and len(rect) == 4):
            return False
        rr = self._clamp_to_visible(rect, work)
        try:
            w.show(h, w.SW_RESTORE)
            w.set_pos(h, w.HWND_TOP, rr[0], rr[1], rr[2], rr[3],
                      w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
            if maxed:
                w.show(h, w.SW_MAXIMIZE)
        except Exception:
            pass
        if mode == "expanded":
            self.expanded.add(h)
        # 恢复完也要把「待保存」计时打开：否则这条记录的时间戳是 0，
        # 之后用户再调整尺寸也不会触发写盘（看起来就是「记忆失效」）。
        self._live[h] = [exe, [int(v) for v in rr], bool(maxed), time.time()]
        return True

    def restore_window_states(self):
        """按上次记下的状态把窗口摆回原位（启动时调用，可重复调用）。

        - card：重建卡片（先摆回原位置，卡片位置也用记忆值）
        - expanded：窗口回到上次放大后的位置尺寸
        - normal：窗口回到普通位置尺寸
        最大化状态一并恢复。找不到对应窗口（应用没开）就跳过，
        之后它一启动、第一次被跟踪到时会立刻按存档摆好。
        """
        n = 0
        try:
            work = w.enum_monitor_work_rects()
        except Exception:
            work = None

        def cb(h):
            nonlocal n
            try:
                if h in self.wm.own_hwnds or h in self.cards or h in self._expanding:
                    return True
                if not w.is_visible(h) or not w.get_title(h):
                    return True
                if w.get_exstyle(h) & w.WS_EX_TOOLWINDOW:
                    return True
                try:
                    exe = exe_of(w.get_pid(h)) or ""
                except Exception:
                    exe = ""
                k = self.settings.exe_key(exe)
                if not k or k in self._restored_keys:
                    return True
                st = self.settings.recall_window(exe)
                if not st:
                    return True
                self._restored_keys.add(k)
                if self._apply_state(h, exe, st, work):
                    n += 1
            except Exception:
                pass
            return True

        try:
            w.enum_windows(cb)
        except Exception:
            pass
        return n

    # ---------------- 常驻几何跟踪 ----------------
    def _track_windows(self, now):
        """盯着所有普通窗口的位置尺寸和最大化状态，变了就写盘。

        之前只有「卡片化 / 展开过」的窗口才进 _watch，纯普通窗口从不落盘；
        而且 _watch 写一次就 pop，之后再调整也不记。这就是「改完大小重启
        又变回去」的直接原因。这里改成每秒巡检 + 700ms 稳定后写盘。
        """
        live = self._live
        seen = set()
        if now < self._boot_until:
            return

        def cb(h):
            try:
                if h in self.wm.own_hwnds or h in self.cards or h in self._expanding:
                    return True
                if h in self._anim_pending:
                    return True
                if w.get_exstyle(h) & w.WS_EX_TOOLWINDOW:
                    return True
                # 最小化时 GetWindowRect 不可信，保留上一次的记录
                if not w.is_visible(h) or w.is_iconic(h):
                    return True
                if not w.get_title(h):
                    return True
                r = w.get_rect(h)
                if r[2] < 200 or r[3] < 120:
                    return True
                try:
                    exe = exe_of(w.get_pid(h)) or ""
                except Exception:
                    exe = ""
                k = self.settings.exe_key(exe)
                if not k:
                    return True
                seen.add(h)
                maxed = w.is_zoomed(h)
                nr = w.normal_rect(h) if maxed else r
                rec = live.get(h)
                if rec is None:
                    # 第一次见到这个窗口：有存档且还没恢复过 -> 立刻按存档摆好。
                    # 这样应用晚几秒启动也能回到原位，不用干等启动时的两次定时恢复。
                    st = self.settings.recall_window(exe)
                    if st and self.auto_restore and k not in self._restored_keys:
                        self._restored_keys.add(k)
                        self._apply_state(h, exe, st)
                        if h in self.cards:
                            return True
                        maxed = w.is_zoomed(h)
                        nr = w.normal_rect(h) if maxed else w.get_rect(h)
                    # 新窗口的初始几何也要落盘：rec[3] 置为当前时间，
                    # 稳定 0.7 秒后写入。否则「打开后没动过」的窗口永远不会被记住，
                    # 下次启动就没有可恢复的尺寸。
                    live[h] = [exe, [int(v) for v in nr], bool(maxed), now]
                    return True
                if (abs(nr[0] - rec[1][0]) > 4 or abs(nr[1] - rec[1][1]) > 4
                        or abs(nr[2] - rec[1][2]) > 4 or abs(nr[3] - rec[1][3]) > 4
                        or bool(maxed) != bool(rec[2])):
                    rec[1] = [int(v) for v in nr]
                    rec[2] = bool(maxed)
                    rec[3] = now
                    return True
                if rec[3] and now - rec[3] >= 0.7:
                    self._save_state(h, "expanded" if h in self.expanded else "normal",
                                     rect=nr, maxed=maxed)
                    try:
                        self.settings.remember_size(exe, nr)
                    except Exception:
                        pass
                    rec[3] = 0.0
            except Exception:
                pass
            return True

        try:
            w.enum_windows(cb)
        except Exception:
            pass

        # 窗口关掉了：把最后一次已知状态落盘（最多滞后一轮巡检）
        for h, rec in list(live.items()):
            if h in seen or w.is_window(h):
                continue
            try:
                if rec[3]:
                    self._save_state(h, "expanded" if h in self.expanded else "normal",
                                     rect=rec[1], maxed=rec[2])
            except Exception:
                pass
            live.pop(h, None)

    def flush_states(self):
        """立刻把所有跟踪中的窗口状态写盘（退出前调用）。"""
        for h, rec in list(self._live.items()):
            try:
                if w.is_window(h) and not w.is_iconic(h):
                    maxed = w.is_zoomed(h)
                    nr = w.normal_rect(h) if maxed else w.get_rect(h)
                    rec[1], rec[2] = [int(v) for v in nr], bool(maxed)
                self._save_state(h, "expanded" if h in self.expanded else "normal",
                                 rect=rec[1], maxed=rec[2])
            except Exception:
                pass
        # 卡片态：源窗口停在屏幕外，按卡片态写，rect 用记录的原位置
        for h, info in list(self.saved.items()):
            if h in self.cards:
                try:
                    self._save_state(h, "card", rect=info.get("rect"),
                                     maxed=info.get("max"))
                except Exception:
                    pass

    # ---------------- 失联窗口找回 ----------------
    def _is_pullback_candidate(self, h, work_rects):
        """这个窗口是否属于「几乎完全在屏幕外、需要拉回」的普通窗口。"""
        # 卡片源和「正在播放大动画的源窗口」都合法地停在屏幕外，不能拉回：
        # 否则放大动画播到一半，源窗口会先闪现在桌面上。
        if h in self.wm.own_hwnds or h in self.cards:
            return False
        if h in self._expanding or h in self._anim_pending:
            return False
        if not w.is_visible(h) or not w.get_title(h):
            return False
        if w.get_exstyle(h) & w.WS_EX_TOOLWINDOW:
            return False
        try:
            l, t, ww, hh = w.get_rect(h)
        except Exception:
            return False
        if ww < 200 or hh < 120:
            return False
        # 关键：用「与任一显示器工作区的交集占比」判断，而不是看 x 是否小于 -4000。
        # 双屏下副屏是负坐标（-1920..0）属正常；真正出界的窗口占比会非常低。
        if w.rect_visible_fraction(l, t, ww, hh, work_rects) >= 0.35:
            return False
        return True

    def pull_back_offscreen(self, only_hwnd=None):
        """把「只露边角/完全在屏幕外」的普通窗口拉回主屏可见区域。

        only_hwnd 给定时只处理这一个窗口（运行期巡检用），否则扫描全部。
        返回被拉回的数量。卡片源窗口（在 self.cards/saved 里）不会被误伤。
        """
        moved = 0
        try:
            wx, wy, W, H = w.primary_work_rect()
            work_rects = w.enum_monitor_work_rects()
        except Exception:
            wx, wy, W, H = 0, 0, 1920, 1040
            work_rects = [(wx, wy, W, H)]

        def handle(h):
            nonlocal moved
            try:
                if not self._is_pullback_candidate(h, work_rects):
                    return True
                # 先还原（最小化的窗口直接 SetWindowPos 是没用的）
                try:
                    w.show(h, w.SW_RESTORE)
                except Exception:
                    pass
                l2, t2, w2, h2 = w.get_rect(h)
                nw = max(min(w2, W - 40), min(900, W - 40))
                nh = max(min(h2, H - 40), min(600, H - 40))
                x = wx + 60 + (moved % 6) * 44
                y = wy + 60 + (moved % 6) * 38
                x = max(wx + 4, min(x, wx + W - nw - 4))
                y = max(wy + 4, min(y, wy + H - nh - 4))
                w.set_pos(h, w.HWND_TOP, x, y, nw, nh,
                          w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
                moved += 1
            except Exception:
                pass
            return True

        if only_hwnd is not None:
            handle(only_hwnd)
            return moved

        try:
            w.enum_windows(handle)
        except Exception:
            pass
        return moved

    def recover_offscreen(self):
        """启动时把遗留在屏幕外的窗口拉回（兼容旧调用）。"""
        return self.pull_back_offscreen()

    # ---------------- 维护 ----------------
    def tick(self):
        now = time.time()
        # 0) 运行期巡检：新开的窗口若只露边角/完全出界，自动拉回主屏
        if now >= self._next_recover:
            self._next_recover = now + 3.0
            try:
                self.pull_back_offscreen()
            except Exception:
                pass
        for h in list(self.expanded):
            if not w.is_window(h) or h in self.cards:
                self.expanded.discard(h)
        # 1) 源窗口关掉了 -> 卡片跟着消失
        for h in list(self.cards.keys()):
            if not w.is_window(h):
                self.dispose(h)
                continue
            card = self.cards.get(h)
            if card is not None:
                t = w.get_title(h)
                if t:
                    card.set_title(t)
                card.refresh()

        # 2) 源窗口被程序自己拉回屏幕内 / 被最小化 -> 保持"停在屏幕外且可见"
        for h, info in list(self.saved.items()):
            if h not in self.cards or not w.is_window(h):
                continue
            try:
                l, t, ww, hh = w.get_rect(h)
                if l > OFFSCREEN_X + 2000:
                    w.set_pos(h, 0, OFFSCREEN_X, 0, info["rect"][2], info["rect"][3],
                              w.SWP_NOZORDER | w.SWP_NOACTIVATE)
                if w.is_iconic(h):
                    w.show(h, w.SW_RESTORE)
                    w.set_pos(h, 0, OFFSCREEN_X, 0, info["rect"][2], info["rect"][3],
                              w.SWP_NOZORDER | w.SWP_NOACTIVATE)
            except Exception:
                pass

        # 3) 用户从任务栏 / Alt+Tab 切到被卡片化的窗口 -> 自动展开，绝不"掉进屏幕外找不回来"
        fg = 0
        try:
            fg = w.get_foreground_window()
        except Exception:
            fg = 0
        if now >= self._settle_until:
            if fg in self.cards and fg != self._last_fg:
                self.expand(fg)
        self._last_fg = fg

        # 4) 记住所有窗口的位置/尺寸/最大化状态（普通窗口也要记，
        #    否则用户手动调完大小，重启就丢）
        try:
            self._track_windows(now)
        except Exception:
            pass
