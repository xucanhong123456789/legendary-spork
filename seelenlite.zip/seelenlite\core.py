# -*- coding: utf-8 -*-
"""
SeelenLite - core.py
窗口管理、全屏切换（记忆原位置）、全局双击还原钩子、配置与开机自启。
"""
import ctypes
from ctypes import wintypes
import json
import os
import sys
import time

from PyQt5.QtCore import QObject, QTimer, pyqtSignal, Qt, QFileInfo
from PyQt5.QtGui import QIcon, QPixmap, QColor, QPainter
from PyQt5.QtWidgets import QFileIconProvider

import win32api as w

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None


APP_NAME = "SeelenLite"
APP_VERSION = "0.2.8"

# 不纳入管理的窗口
SKIP_CLASSES = {
    "Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd",
    "Windows.UI.Core.CoreWindow", "DV2ControlHost", "ShotBarClass",
}
SKIP_TITLES = {
    "Program Manager", "Windows 输入体验", "Microsoft Text Input Application",
    "SeelenLite", " ",
}

MIN_W, MIN_H = 200, 120

# SELENLITE_DEBUG=1 时在钩子/交互路径上打点，平时完全静默
_DBG = bool(os.environ.get("SELENLITE_DEBUG"))


# ------------------------------------------------------------------ 配置
def config_dir():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, APP_NAME)
    os.makedirs(d, exist_ok=True)
    return d


def config_path():
    return os.path.join(config_dir(), "config.json")


DEFAULT_PINNED = [
    r"C:\Windows\explorer.exe",
    r"C:\Windows\System32\notepad.exe",
    r"C:\Windows\System32\calc.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files\Microsoft\WindowsApps\Microsoft.WindowsTerminal_8wekyb3d8bbwe\wt.exe",
]


class Settings:
    def __init__(self):
        self.pinned = [p for p in DEFAULT_PINNED if os.path.exists(p)]
        self.show_dock = True
        self.compact = True              # 精简模式：只留底部程序坞，不显示顶栏
        self.show_topbar = False
        self.autostart = False
        self.dock_magnify = True
        # ---- 窗口交互 ----
        # 单击放大默认关闭：它会在每次点击时改写窗口尺寸，
        # 和「拖窗口边缘改大小」「卡片缩放」直接打架，属于早期的实验功能。
        self.click_max = False
        self.click_max_mode = "inactive"  # any=任意位置都放大；inactive=只放大非活动窗口
        self.title_restore = True        # 双击标题栏 -> 缩成卡片
        self.esc_restore = True          # 按 ESC -> 把前台窗口缩回卡片
        self.right_restore = True        # 右键点放大窗口 -> 缩回卡片（等同 ESC）
        self.title_zone = 0              # 标题栏判定高度，0 表示自动
        # ---- 展开尺寸 ----
        self.expand_preset = "half"      # full=整屏 / wide=3/4 / half=半屏 / custom=自定义
        self.expand_ratio = 0.62         # custom 时的宽度占比
        self.expand_remember = True      # 记住每个应用手动调整后的尺寸
        self.per_app_size = {}           # exe(小写) -> [x, y, w, h]
        self.card_scale = 0.32           # 卡片宽度 = 源窗口宽度 × 该比例
        # ---- 卡片交互与动画 ----
        self.card_hover = True           # 鼠标悬停卡片时平滑放大
        self.card_hover_scale = 1.14     # 悬停放大倍数
        self.card_anim = True            # 缩小/放大时播放缩放动画
        # 鼠标悬停到哪个窗口，就把它抬到普通窗口的最前层（不激活、不置顶）
        self.hover_raise = True
        # ---- 窗口状态持久化 ----
        # exe(小写) -> {"rect":[x,y,w,h], "mode":"card|expanded|normal", "card":[x,y,w,h]}
        # rect 是这个窗口「该有的」位置尺寸（卡片态时记的是缩回后要回的位置），
        # mode 记录它当时是卡片、放大还是普通窗口，重启后据此精确还原。
        self.window_states = {}
        self.load()

    def load(self):
        migrated = False
        try:
            with open(config_path(), "r", encoding="utf-8") as f:
                d = json.load(f)
            self.pinned = d.get("pinned", self.pinned)
            self.show_dock = d.get("show_dock", True)
            self.compact = bool(d.get("compact", True))
            self.show_topbar = bool(d.get("show_topbar", False))
            self.autostart = d.get("autostart", False)
            self.dock_magnify = d.get("dock_magnify", True)
            self.click_max = bool(d.get("click_max", False))
            mode = d.get("click_max_mode", "inactive")
            self.click_max_mode = mode if mode in ("any", "inactive") else "inactive"
            ver = int(d.get("cfg_ver", 1) or 1)
            # 旧配置升级：早期版本默认「任意位置点击就放大」，太容易误触，统一改成只放大非活动窗口
            if ver < 2:
                self.click_max_mode = "inactive"
            # v3：单击放大整体默认关闭——每次点击都改窗口尺寸，和手动拖拽/卡片缩放冲突
            if ver < 3:
                self.click_max = False
                migrated = True
            self.title_restore = d.get("title_restore", True)
            self.esc_restore = d.get("esc_restore", True)
            self.right_restore = bool(d.get("right_restore", True))
            self.title_zone = int(d.get("title_zone", 0) or 0)
            p = d.get("expand_preset", "half")
            self.expand_preset = p if p in ("full", "wide", "half", "custom") else "half"
            try:
                self.expand_ratio = min(1.0, max(0.35, float(d.get("expand_ratio", 0.62))))
            except Exception:
                self.expand_ratio = 0.62
            self.expand_remember = bool(d.get("expand_remember", True))
            pas = d.get("per_app_size", {})
            self.per_app_size = pas if isinstance(pas, dict) else {}
            try:
                self.card_scale = min(0.5, max(0.15, float(d.get("card_scale", 0.32))))
            except Exception:
                self.card_scale = 0.32
            self.card_hover = bool(d.get("card_hover", True))
            try:
                self.card_hover_scale = min(1.35, max(1.0, float(d.get("card_hover_scale", 1.14))))
            except Exception:
                self.card_hover_scale = 1.14
            self.card_anim = bool(d.get("card_anim", True))
            self.hover_raise = bool(d.get("hover_raise", True))
            ws = d.get("window_states", {})
            if isinstance(ws, dict):
                clean = self._sanitize_states(ws)
                if clean != ws:
                    migrated = True
                self.window_states = clean
            else:
                self.window_states = {}
        except Exception:
            pass
        if migrated:
            # 立刻把升级后的值写回配置文件，避免每次启动都靠迁移逻辑兜
            self.save()

    @staticmethod
    def _sanitize_states(ws):
        """丢掉旧版本写坏的窗口记录。

        早期版本退出时会把「卡片源窗口」的屏幕外坐标 (-16000, 0) 当成普通态
        存下来，下次启动按它恢复，窗口就跳到屏幕左上角。这类记录没有可用
        信息，直接丢弃比硬修更安全。
        """
        out = {}
        for k, st in (ws or {}).items():
            try:
                if not isinstance(st, dict):
                    continue
                mode = st.get("mode", "normal")
                if mode not in ("card", "expanded", "normal"):
                    continue
                rect = st.get("rect")
                if not (isinstance(rect, (list, tuple)) and len(rect) == 4):
                    continue
                x, y, ww, hh = [int(v) for v in rect]
                if ww < 200 or hh < 120:
                    continue
                if x <= -4000:
                    continue
                if mode == "card":
                    card = st.get("card")
                    if not (isinstance(card, (list, tuple)) and len(card) == 4):
                        continue
                    cx, cy, cw, ch = [int(v) for v in card]
                    if cx <= -4000 or cw < 120 or ch < 80:
                        continue
                out[k] = st
            except Exception:
                continue
        return out

    def save(self):
        d = {
            "cfg_ver": 4,
            "pinned": self.pinned,
            "show_dock": self.show_dock,
            "compact": self.compact,
            "show_topbar": self.show_topbar,
            "autostart": self.autostart,
            "dock_magnify": self.dock_magnify,
            "click_max": self.click_max,
            "click_max_mode": self.click_max_mode,
            "title_restore": self.title_restore,
            "esc_restore": self.esc_restore,
            "right_restore": self.right_restore,
            "title_zone": self.title_zone,
            "expand_preset": self.expand_preset,
            "expand_ratio": self.expand_ratio,
            "expand_remember": self.expand_remember,
            "per_app_size": self.per_app_size,
            "card_scale": self.card_scale,
            "card_hover": self.card_hover,
            "card_hover_scale": self.card_hover_scale,
            "card_anim": self.card_anim,
            "hover_raise": self.hover_raise,
            "window_states": self.window_states,
        }
        try:
            with open(config_path(), "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    # ---- 每个应用的展开尺寸记忆 ----
    @staticmethod
    def exe_key(exe):
        return (exe or "").replace("/", "\\").lower()

    def remember_size(self, exe, rect):
        """记住某个应用最后一次的展开位置与大小。"""
        if not self.expand_remember:
            return
        k = self.exe_key(exe)
        if not k:
            return
        try:
            self.per_app_size[k] = [int(v) for v in rect]
        except Exception:
            return
        self.save()

    def recall_size(self, exe):
        """取出某个应用记忆的 [x, y, w, h]，没有则 None。"""
        if not self.expand_remember:
            return None
        v = self.per_app_size.get(self.exe_key(exe))
        if not v or len(v) != 4:
            return None
        try:
            return [int(x) for x in v]
        except Exception:
            return None

    def clear_sizes(self):
        self.per_app_size = {}
        self.save()

    # ---- 窗口状态（位置 / 尺寸 / 缩放态 / 最大化态）持久化 ----
    def remember_window(self, exe, rect=None, mode=None, card=None, maxed=None):
        """记录某个应用窗口的状态。

        rect: 该窗口「还原后」的位置尺寸（最大化时不要传最大化矩形）；
        mode: "card" 卡片态 / "expanded" 放大态 / "normal" 普通态；
        card: 卡片本身的几何（卡片态才有）；
        maxed: 当前是否最大化。只更新传入的字段，没传的保持原值。
        """
        k = self.exe_key(exe)
        if not k:
            return
        st = self.window_states.get(k)
        if not isinstance(st, dict):
            st = {}
        if rect is not None and len(rect) == 4:
            try:
                st["rect"] = [int(v) for v in rect]
            except Exception:
                pass
        if card is not None and len(card) == 4:
            try:
                st["card"] = [int(v) for v in card]
            except Exception:
                pass
        if mode in ("card", "expanded", "normal"):
            st["mode"] = mode
        if maxed is not None:
            st["max"] = bool(maxed)
        self.window_states[k] = st
        self.save()

    def recall_window(self, exe):
        st = self.window_states.get(self.exe_key(exe))
        return st if isinstance(st, dict) else None

    def clear_window_states(self):
        self.window_states = {}
        self.save()


def set_autostart(enable):
    """写入 HKCU\\...\\Run，开机自启。"""
    import winreg
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    try:
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
    except Exception:
        return False
    if enable:
        exe = os.path.abspath(sys.executable)
        if exe.lower().endswith("python.exe") or exe.lower().endswith("pythonw.exe"):
            cmd = '"%s" "%s"' % (exe, os.path.abspath(os.path.join(os.path.dirname(__file__), "main.py")))
        else:
            cmd = '"%s"' % exe
        try:
            winreg.SetValueEx(k, APP_NAME, 0, winreg.REG_SZ, cmd)
        except Exception:
            return False
    else:
        try:
            winreg.DeleteValue(k, APP_NAME)
        except Exception:
            pass
    winreg.CloseKey(k)
    return True


# ------------------------------------------------------------------ 窗口信息
class WindowInfo:
    __slots__ = ("hwnd", "title", "cls", "rect", "pid", "exe", "icon")

    def __init__(self, hwnd, title, cls, rect, pid):
        self.hwnd = hwnd
        self.title = title
        self.cls = cls
        self.rect = rect
        self.pid = pid
        self.exe = ""
        self.icon = None

    @property
    def x(self):
        return self.rect[0]

    @property
    def y(self):
        return self.rect[1]

    @property
    def width(self):
        return self.rect[2]

    @property
    def height(self):
        return self.rect[3]

    def __repr__(self):
        return "<Window %s %r>" % (self.hwnd, self.title)


_icon_prov = None
_exe_cache = {}


def _icon_provider():
    global _icon_prov
    if _icon_prov is None:
        _icon_prov = QFileIconProvider()
    return _icon_prov


def exe_of(pid):
    if pid in _exe_cache:
        return _exe_cache[pid]
    path = ""
    if psutil is not None:
        try:
            path = psutil.Process(pid).exe()
        except Exception:
            path = ""
    _exe_cache[pid] = path
    return path


def icon_for_exe(path):
    if not path or not os.path.exists(path):
        return QIcon()
    try:
        icon = _icon_provider().icon(QFileInfo(path))
        if not icon.isNull():
            return icon
    except Exception:
        pass
    try:
        return _icon_provider().icon(QFileInfo(path))
    except Exception:
        return QIcon()


def generic_icon():
    try:
        return _icon_provider().icon(QFileInfo("C:\\"))
    except Exception:
        return QIcon()


# ------------------------------------------------------------------ 窗口管理器
class WindowManager(QObject):
    changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.windows = []
        self._saved = {}          # hwnd -> (WINDOWPLACEMENT, style, exstyle)
        self.fs_hwnd = None       # 当前被我们最大化的窗口
        self.own_hwnds = set()
        self.card_hwnds = set()   # 卡片窗口：点击不要穿透到下面的窗口
        self.cards = None         # 由 main 注入的 CardManager（程序坞要用）

    # ---------------- 采集 ----------------
    def refresh(self):
        found = []
        own = self.own_hwnds

        def cb(hwnd):
            if hwnd in own:
                return True
            if not w.is_visible(hwnd):
                return True
            title = w.get_title(hwnd)
            if not title or title in SKIP_TITLES:
                return True
            cls = w.get_class(hwnd)
            if cls in SKIP_CLASSES:
                return True
            try:
                if w.get_exstyle(hwnd) & w.WS_EX_TOOLWINDOW:
                    return True
            except Exception:
                pass
            rect = w.get_rect(hwnd)
            if rect[2] < MIN_W or rect[3] < MIN_H:
                return True
            info = WindowInfo(hwnd, title, cls, rect, w.get_pid(hwnd))
            if not info.exe:
                info.exe = exe_of(info.pid)
            info.icon = icon_for_exe(info.exe) if info.exe else generic_icon()
            found.append(info)
            return True

        w.enum_windows(cb)
        self.windows = found
        self.changed.emit()
        return found

    def by_hwnd(self, hwnd):
        for i in self.windows:
            if i.hwnd == hwnd:
                return i
        return None

    # ---------------- 操作 ----------------
    def focus(self, info):
        try:
            if w.is_iconic(info.hwnd):
                w.show(info.hwnd, w.SW_RESTORE)
            else:
                w.show(info.hwnd, w.SW_SHOW)
        except Exception:
            pass
        w.focus(info.hwnd)

    def minimize(self, info):
        w.minimize(info.hwnd)

    def close(self, info):
        w.post_close(info.hwnd)

    def launch(self, exe):
        try:
            os.startfile(exe)
            return True
        except Exception:
            return False

    # ---------------- 最大化 / 还原 ----------------
    def is_maximized(self, hwnd):
        try:
            return w.is_zoomed(hwnd)
        except Exception:
            return False

    def maximize(self, info):
        """最大化窗口（保留标题栏），并记住它原来的大小和位置。"""
        hwnd = info.hwnd
        if not hwnd or not w.user32.IsWindow(hwnd):
            return False
        if self.fs_hwnd and self.fs_hwnd != hwnd:
            # 上一个被我们放大的窗口，如果用户已经自己还原了，就只清记录，别硬拉回去
            if w.user32.IsWindow(self.fs_hwnd) and w.is_zoomed(self.fs_hwnd):
                self.restore_max(self.fs_hwnd)
            else:
                self._saved.pop(self.fs_hwnd, None)
                self.fs_hwnd = None
        # 只在"由小变大"时记忆位置；本来就已经最大化则不动记忆
        if not w.is_zoomed(hwnd):
            wp = w.get_placement(hwnd)
            if wp:
                self._saved[hwnd] = (wp, w.get_style(hwnd), w.get_exstyle(hwnd))
        w.show(hwnd, w.SW_SHOWMAXIMIZED)
        self.fs_hwnd = hwnd
        return True

    def restore_max(self, hwnd=None):
        """还原到最大化之前的大小和位置（双击标题栏时调用）。"""
        if hwnd is None:
            hwnd = self.fs_hwnd
        if not hwnd or not w.user32.IsWindow(hwnd):
            if self.fs_hwnd == hwnd:
                self.fs_hwnd = None
            return False
        saved = self._saved.pop(hwnd, None)
        if saved:
            wp, style, exstyle = saved
            try:
                w.set_exstyle(hwnd, exstyle)
                w.set_style(hwnd, style)
            except Exception:
                pass
            w.show(hwnd, w.SW_RESTORE)
            w.set_placement(hwnd, wp)
        else:
            w.show(hwnd, w.SW_RESTORE)
        if self.fs_hwnd == hwnd:
            self.fs_hwnd = None
        return True

    def toggle_max(self, info):
        if self.is_maximized(info.hwnd):
            self.restore_max(info.hwnd)
            return False
        self.maximize(info)
        return True

    def restore_any(self):
        if self.fs_hwnd:
            self.restore_max(self.fs_hwnd)

    # ---------------- 命中测试 ----------------
    def hwnd_at_point(self, x, y):
        """屏幕坐标所在的应用窗口（快速判定，不做全量枚举）。

        任务栏、桌面、托盘、本程序自己的窗口都会返回 None。
        """
        try:
            h = w.root_window(w.window_from_point(x, y))
        except Exception:
            return None
        if not h:
            return None
        if h in self.own_hwnds:
            # 卡片窗口自己处理点击，绝不要穿透到它下面的窗口
            if h in self.card_hwnds:
                return None
            # 点在顶栏/程序坞这类自身窗口上：往下探一点，找被它盖住的应用窗口。
            # 最大化窗口的标题栏正好在顶栏下面，这样双击标题栏才点得到。
            below = None
            for dy in (36, 44, 56, 72):
                try:
                    h2 = w.root_window(w.window_from_point(x, y + dy))
                except Exception:
                    h2 = None
                if h2 and h2 not in self.own_hwnds:
                    below = h2
                    break
            if not below:
                return None
            h = below
        # 已知窗口直接命中
        if self.by_hwnd(h):
            return h
        # 新窗口：按与采集相同的规则快速筛一遍
        try:
            if not w.is_visible(h):
                return None
            title = w.get_title(h)
            if not title or title in SKIP_TITLES:
                return None
            cls = w.get_class(h)
            if cls in SKIP_CLASSES:
                return None
            if w.get_exstyle(h) & w.WS_EX_TOOLWINDOW:
                return None
            l, t, ww, hh = w.get_rect(h)
            if ww < MIN_W or hh < MIN_H:
                return None
        except Exception:
            return None
        return h

    def info_at_point(self, x, y):
        h = self.hwnd_at_point(x, y)
        if not h:
            return None
        info = self.by_hwnd(h)
        if info:
            return info
        # 列表里还没有它：临时构造一个（够用来最大化/还原）
        try:
            return WindowInfo(h, w.get_title(h), w.get_class(h), w.get_rect(h), w.get_pid(h))
        except Exception:
            return None

    def titlebar_bottom(self, hwnd, zone=0):
        """窗口标题栏的下边界 y（屏幕坐标）。"""
        try:
            l, t, ww, hh = w.get_rect(hwnd)
        except Exception:
            return 0
        cap = zone if zone and zone > 0 else w.caption_height()
        return t + cap


    # ---------------- 平铺 ----------------
    def tile_all(self):
        """把当前所有可见窗口按网格平铺到主显示器。"""
        items = [i for i in self.windows if i.width > MIN_W and i.height > MIN_H]
        if not items:
            return 0
        n = len(items)
        cols = int(n ** 0.5 + 0.5)
        if cols < 1:
            cols = 1
        rows = (n + cols - 1) // cols
        x0, y0, W, H = w.primary_work_rect()
        cw, ch = W // cols, H // rows
        for idx, it in enumerate(items):
            r, c = divmod(idx, cols)
            l = x0 + c * cw
            t = y0 + r * ch
            ww = cw if c < cols - 1 else (x0 + W - l)
            hh = ch if r < rows - 1 else (y0 + H - t)
            self.restore_max(it.hwnd)
            try:
                w.show(it.hwnd, w.SW_RESTORE)
                w.set_pos(it.hwnd, w.HWND_NOTOPMOST, l, t, ww, hh,
                          w.SWP_FRAMECHANGED | w.SWP_SHOWWINDOW)
            except Exception:
                pass
        return n

    def snap(self, info, where):
        """把单个窗口贴到 half/quarter 区域。"""
        x0, y0, W, H = w.primary_work_rect()
        self.restore_max(info.hwnd)
        try:
            w.show(info.hwnd, w.SW_RESTORE)
        except Exception:
            pass
        boxes = {
            "left":   (x0, y0, W // 2, H),
            "right":  (x0 + W // 2, y0, W - W // 2, H),
            "top":    (x0, y0, W, H // 2),
            "bottom": (x0, y0 + H // 2, W, H - H // 2),
            "tl":     (x0, y0, W // 2, H // 2),
            "tr":     (x0 + W // 2, y0, W - W // 2, H // 2),
            "bl":     (x0, y0 + H // 2, W // 2, H - H // 2),
            "br":     (x0 + W // 2, y0 + H // 2, W - W // 2, H - H // 2),
        }
        box = boxes.get(where)
        if box:
            w.set_pos(info.hwnd, w.HWND_NOTOPMOST, box[0], box[1], box[2], box[3],
                      w.SWP_FRAMECHANGED | w.SWP_SHOWWINDOW)

    def show_desktop(self):
        """全部最小化（保留全屏窗口也还原）。"""
        self.restore_any()
        for it in self.windows:
            try:
                w.minimize(it.hwnd)
            except Exception:
                pass


# ------------------------------------------------------------------ 全局双击还原
class ClickHook(QObject):
    """全局鼠标钩子：识别左键单击/双击，以及右键「缩回」手势。

    - 单击：按下到抬起位移很小（没拖动）、按住时间短；延迟 200ms 发出，
      留出时间判断它其实是双击的第一下。
    - 双击：两次点击间隔 < 400ms 且位置接近。
    - 右键：短按且没有拖动；只有 right_target(x, y, hwnd) 返回 True 时才拦截，
      不拦截的右键完全交给应用自己的菜单。
    钩子回调里只记录数据，由 20ms 定时器统一发信号（不在回调里碰 Qt）。
    """
    single_click = pyqtSignal(int, int, int, int)   # x, y, 点击前的前景窗口, 命中的窗口
    double_click = pyqtSignal(int, int, int)        # x, y, 命中的窗口（仅标题栏双击）
    right_click = pyqtSignal(int, int, int)         # x, y, 命中的窗口（右键缩回）

    DOUBLE_MS = 400          # 两次点击间隔小于它算双击
    MOVE_PX = 6              # 按下-抬起位移超过它算拖动
    LONG_MS = 500            # 按住超过它算长按，不算单击
    SINGLE_DELAY_MS = 200    # 单击延迟发出时长

    def __init__(self, parent=None):
        super().__init__(parent)
        self._hook = None
        self._proc = None
        self._timer = QTimer(self)
        self._timer.setInterval(20)
        self._timer.timeout.connect(self._poll)
        self._down = None        # (x, y, t, hwnd, rect, in_title)
        self._single = None      # (x, y, t, fg, hwnd)
        self._pending_double = None   # (x, y, hwnd)
        self._last_click = None  # (x, y, t)
        self._fg = 0
        self._dbl = False        # 当前按下这一对是标题栏双击
        self._rdown = None       # (x, y, t, hwnd, intercepted) 右键按下
        self._right = None       # (x, y, hwnd) 待发出的右键缩回
        self.right_target = None # (hwnd) -> bool，由 App 注入

    def start(self):
        if self._hook:
            return True
        self._proc = w.HOOKPROC(self._on_hook)
        hmod = w.kernel32.GetModuleHandleW(None)
        self._hook = w.user32.SetWindowsHookExW(w.WH_MOUSE_LL, self._proc, hmod, 0)
        if self._hook:
            self._timer.start()
        return bool(self._hook)

    def stop(self):
        self._timer.stop()
        if self._hook:
            try:
                w.user32.UnhookWindowsHookEx(self._hook)
            except Exception:
                pass
            self._hook = None

    def _on_hook(self, nCode, wParam, lParam):
        swallow = False
        if nCode == 0:
            try:
                st = ctypes.cast(lParam, ctypes.POINTER(w.MSLLHOOKSTRUCT)).contents
                px, py = st.pt.x, st.pt.y
                t = time.time()
                if wParam == w.WM_LBUTTONDOWN:
                    hwnd = 0
                    rect = None
                    in_title = False
                    try:
                        hwnd = w.root_window(w.window_from_point(px, py)) or 0
                        if hwnd:
                            rect = w.get_rect(hwnd)
                            in_title = rect[1] <= py <= rect[1] + w.caption_height()
                    except Exception:
                        hwnd = 0
                    try:
                        self._fg = w.get_foreground_window()
                    except Exception:
                        self._fg = 0
                    lc = self._last_click
                    is_dbl = bool(lc and (t - lc[2]) * 1000.0 <= self.DOUBLE_MS
                                  and abs(px - lc[0]) <= self.MOVE_PX
                                  and abs(py - lc[1]) <= self.MOVE_PX)
                    self._down = (px, py, t, hwnd, rect, in_title)
                    if _DBG:
                        print("LL_DOWN", px, py, hwnd, "title", in_title,
                              "dbl", is_dbl, "swallow", swallow, flush=True)
                    if is_dbl and in_title and hwnd:
                        # 标题栏上的第二下：拦下来，别让 Windows 原生"还原"抢先执行
                        self._dbl = True
                        self._single = None
                        swallow = True
                    elif self._single and (t - self._single[2]) * 1000.0 <= self.DOUBLE_MS:
                        self._single = None
                elif wParam == w.WM_LBUTTONUP and self._down is not None:
                    dx, dy, t0, hwnd, rect, in_title = self._down
                    self._down = None
                    moved = max(abs(px - dx), abs(py - dy))
                    held = (t - t0) * 1000.0
                    if _DBG:
                        print("LL_UP", px, py, hwnd, "moved", moved, "held", round(held),
                              "dbl", self._dbl, flush=True)
                    if self._dbl:
                        self._dbl = False
                        self._last_click = None
                        swallow = True
                        if hwnd:
                            self._pending_double = (px, py, int(hwnd))
                    elif moved <= self.MOVE_PX and held <= self.LONG_MS:
                        lc = self._last_click
                        if (lc and (t - lc[2]) * 1000.0 <= self.DOUBLE_MS
                                and abs(px - lc[0]) <= self.MOVE_PX
                                and abs(py - lc[1]) <= self.MOVE_PX):
                            # 内容区的双击：交给程序自己处理，不当作单击
                            self._last_click = None
                            self._single = None
                        else:
                            self._single = (px, py, t, self._fg, int(hwnd or 0))
                            self._last_click = (px, py, t)
                elif wParam == w.WM_RBUTTONDOWN:
                    hwnd = 0
                    try:
                        hwnd = w.root_window(w.window_from_point(px, py)) or 0
                    except Exception:
                        hwnd = 0
                    # 关键：是否在按下这一刻就决定接管。
                    # 按下/抬起必须成对拦截：只拦抬起会让应用一直以为右键没松开，
                    # 于是进入「右键拖拽」状态，窗口和桌面都会卡住、拖不动。
                    intercept = False
                    if hwnd and self.right_target is not None:
                        try:
                            intercept = bool(self.right_target(hwnd))
                        except Exception:
                            intercept = False
                    if intercept:
                        swallow = True
                    self._rdown = (px, py, t, int(hwnd), intercept)
                elif wParam == w.WM_RBUTTONUP:
                    if self._rdown is not None:
                        x0, y0, t0, hwnd, intercept = self._rdown
                        self._rdown = None
                        held = (t - t0) * 1000.0
                        # 配对拦截：按下拦了，抬起也必须拦。
                        # 超过 10 秒视为丢失的配对，放行以免卡住后续右键。
                        if intercept and held <= 10000:
                            swallow = True
                            moved = max(abs(px - x0), abs(py - y0))
                            if moved <= self.MOVE_PX and held <= self.LONG_MS and hwnd:
                                self._right = (px, py, int(hwnd))
            except Exception:
                pass
        if swallow:
            return 1
        try:
            return w.user32.CallNextHookEx(None, nCode, wParam, lParam)
        except Exception:
            return 0

    def _poll(self):
        if self._right is not None:
            x, y, h = self._right
            self._right = None
            self.right_click.emit(x, y, h)
            return
        if self._pending_double is not None:
            x, y, h = self._pending_double
            self._pending_double = None
            self.double_click.emit(x, y, h)
            return
        if self._single is not None and self._down is None:
            x, y, ts, fg, h = self._single
            if (time.time() - ts) * 1000.0 >= self.SINGLE_DELAY_MS:
                self._single = None
                self.single_click.emit(x, y, fg, h)


class ForegroundHook(QObject):
    """监听「哪个窗口被激活了」（EVENT_SYSTEM_FOREGROUND）。

    用于：被缩成卡片的窗口从任务栏 / Alt+Tab 切回来时，自动展开，
    绝不会让窗口停在屏幕外找不回来。
    """
    activated = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._hook = None
        self._proc = None
        self._last = 0
        self._timer = QTimer(self)
        self._timer.setInterval(60)
        self._timer.timeout.connect(self._poll)

    def start(self):
        if self._hook:
            return True
        self._proc = w.WINEVENTPROC(self._on_event)
        try:
            self._hook = w.user32.SetWinEventHook(
                w.EVENT_SYSTEM_FOREGROUND, w.EVENT_SYSTEM_FOREGROUND,
                None, self._proc, 0, 0,
                w.WINEVENT_OUTOFCONTEXT | w.WINEVENT_SKIPOWNPROCESS)
        except Exception:
            self._hook = None
        if self._hook:
            self._timer.start()
        return bool(self._hook)

    def stop(self):
        self._timer.stop()
        if self._hook:
            try:
                w.user32.UnhookWinEvent(self._hook)
            except Exception:
                pass
            self._hook = None

    def _on_event(self, hWinEventHook, event, hwnd, idObject, idChild, thread, time_):
        try:
            self._last = int(hwnd or 0)
        except Exception:
            pass

    def _poll(self):
        h = self._last
        if not h:
            return
        self._last = 0
        self.activated.emit(h)


class HoverRaise(QObject):
    """鼠标悬停到哪个应用窗口，就把它抬到普通窗口的最前层。

    只抬到 HWND_TOP（普通 z 序），不用 HWND_TOPMOST：
    抬起来之后原来在上面的窗口自然退到后面，不会留下「永久置顶」的尾巴；
    鼠标移到另一个窗口时，只有新的窗口被抬起，旧窗口就在它下面。

    只用 SWP_NOACTIVATE 抬层级，不抢焦点、不激活：
    用户正在输入的文字、输入法状态都不会被打断。

    防抖（这段是重点，不然会闪）：
      · 90ms 轮询；同一个窗口要连续命中才动手；
      · 抬过的窗口不重复抬（已经在最前再 SetWindowPos 会触发重绘闪烁）；
      · 抬起后 300ms 冷却，避免「抬起 -> 下层窗口露出来 -> 又被命中」来回抖；
      · 自己的窗口（程序坞/卡片/总览）、任务栏、桌面、工具窗、置顶窗一律跳过。
    """
    raised = pyqtSignal(int)

    def __init__(self, wm, settings, parent=None):
        super().__init__(parent)
        self.wm = wm
        self.settings = settings
        self._timer = QTimer(self)
        self._timer.setInterval(90)
        self._timer.timeout.connect(self._tick)
        self._cand = 0
        self._cand_since = 0.0
        self._last_raised = 0
        self._cooldown_until = 0.0
        self._paused_until = 0.0
        self.enabled = True

    def start(self):
        self._timer.start()

    def stop(self):
        self._timer.stop()

    def pause(self, seconds=0.6):
        """暂停一小会儿：切换动画/拖动期间不要插手 z 序。"""
        self._paused_until = time.time() + float(seconds)
        self._cand = 0

    def _eligible(self, h):
        if not h:
            return False
        h = int(h)
        if h in self.wm.own_hwnds or h in getattr(self.wm, "card_hwnds", set()):
            return False
        if not w.is_window(h) or not w.is_visible(h) or w.is_iconic(h):
            return False
        if not w.get_title(h):
            return False
        ex = w.get_exstyle(h)
        # 工具窗多半是浮层/菜单；置顶窗本来就在最前，抬它没有意义
        if ex & (w.WS_EX_TOOLWINDOW | w.WS_EX_TOPMOST):
            return False
        try:
            r = w.get_rect(h)
        except Exception:
            return False
        if r[2] < 200 or r[3] < 120:
            return False
        cls = w.get_class(h)
        if cls in ("Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd"):
            return False
        # 我们自己的全屏窗口正在用：不要被别的窗口盖掉
        fs = getattr(self.wm, "fs_hwnd", None)
        if fs and h != int(fs):
            return False
        # 卡片正在做放大/缩小动画：那几百毫秒里别插手 z 序，
        # 否则真窗口会在动画途中冒出来盖住卡片
        cards = getattr(self.wm, "cards", None)
        if cards is not None:
            if getattr(cards, "_expanding", None) or getattr(cards, "_anim_pending", None):
                return False
        return True

    def _tick(self):
        try:
            if not self.enabled or not getattr(self.settings, "hover_raise", True):
                return
            now = time.time()
            if now < self._paused_until or now < self._cooldown_until:
                return
            p = w.cursor_pos()
            h = int(w.root_window(w.window_from_point(p[0], p[1])) or 0)
            if not self._eligible(h):
                self._cand = 0
                self._last_raised = 0   # 离开窗口区域后，再回来可以重新抬
                return
            if h != self._cand:
                self._cand = h
                self._cand_since = now
                return
            # 连续命中 90ms 才动手：横向扫过一排窗口时不会每个都抬一下
            if now - self._cand_since < 0.09:
                return
            if h == self._last_raised:
                return
            self._last_raised = h
            self._cooldown_until = now + 0.30
            w.set_pos(h, w.HWND_TOP, 0, 0, 0, 0,
                      w.SWP_NOMOVE | w.SWP_NOSIZE | w.SWP_NOACTIVATE
                      | w.SWP_NOOWNERZORDER | w.SWP_NOSENDCHANGING)
            self.raised.emit(h)
        except Exception:
            pass


class KeyboardHook(QObject):
    """监听 ESC（用于关闭窗口总览）。仅在总览打开时生效。"""
    escape_pressed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._hook = None
        self._proc = None
        self._pending = False
        self._timer = QTimer(self)
        self._timer.setInterval(25)
        self._timer.timeout.connect(self._poll)

    def start(self):
        if self._hook:
            return True
        self._proc = w.HOOKPROC(self._on_hook)
        hmod = w.kernel32.GetModuleHandleW(None)
        self._hook = w.user32.SetWindowsHookExW(w.WH_KEYBOARD_LL, self._proc, hmod, 0)
        if self._hook:
            self._timer.start()
        return bool(self._hook)

    def stop(self):
        self._timer.stop()
        if self._hook:
            try:
                w.user32.UnhookWindowsHookEx(self._hook)
            except Exception:
                pass
            self._hook = None

    def _on_hook(self, nCode, wParam, lParam):
        if nCode == 0 and wParam == 0x0100:  # WM_KEYDOWN
            try:
                vk = ctypes.cast(lParam, ctypes.POINTER(wintypes.DWORD)).contents.value
                if vk == 0x1B:                # VK_ESCAPE
                    self._pending = True
            except Exception:
                pass
        try:
            return w.user32.CallNextHookEx(None, nCode, wParam, lParam)
        except Exception:
            return 0

    def _poll(self):
        if not self._pending:
            return
        self._pending = False
        self.escape_pressed.emit()
