# -*- coding: utf-8 -*-
"""
SeelenLite - win32api.py
薄封装 user32 / gdi32 / kernel32，提供窗口枚举、属性读写、位置调整与窗口捕获。
不依赖 pywin32，只用标准库 ctypes。
"""
import ctypes
from ctypes import wintypes, byref, sizeof, WINFUNCTYPE, Structure, c_int, c_uint, c_long, c_byte, c_void_p, c_ssize_t, POINTER

from PyQt5.QtGui import QImage

user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
dwmapi = ctypes.WinDLL("dwmapi")

# ------------------------------------------------------------------ 常量
GWL_STYLE = -16
GWL_EXSTYLE = -20

WS_BORDER = 0x00800000
WS_CAPTION = 0x00C00000
WS_DLGFRAME = 0x00400000
WS_THICKFRAME = 0x00040000
WS_SYSMENU = 0x00080000
WS_MINIMIZEBOX = 0x00020000
WS_MAXIMIZEBOX = 0x00010000
WS_POPUP = 0x80000000
WS_VISIBLE = 0x10000000
WS_DISABLED = 0x08000000

WS_EX_TOOLWINDOW = 0x00000080
WS_EX_WINDOWEDGE = 0x00000100
WS_EX_CLIENTEDGE = 0x00000200
WS_EX_APPWINDOW = 0x00040000
WS_EX_TOPMOST = 0x00000008
WS_EX_LAYERED = 0x00080000
WS_EX_NOACTIVATE = 0x08000000

SW_HIDE = 0
SW_SHOWNORMAL = 1
SW_SHOWMINIMIZED = 2
SW_SHOWMAXIMIZED = 3
SW_MAXIMIZE = 3          # 与 SW_SHOWMAXIMIZED 同值，两种写法都用得到
SW_SHOWNOACTIVATE = 4
SW_SHOW = 5
SW_MINIMIZE = 6
SW_RESTORE = 9

HWND_TOP = 0
HWND_BOTTOM = 1
HWND_TOPMOST = -1
HWND_NOTOPMOST = -2

SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOZORDER = 0x0004
SWP_NOREDRAW = 0x0008
SWP_NOACTIVATE = 0x0010
SWP_FRAMECHANGED = 0x0020
SWP_SHOWWINDOW = 0x0040
SWP_HIDEWINDOW = 0x0080
SWP_NOCOPYBITS = 0x0100
SWP_NOOWNERZORDER = 0x0200
SWP_NOSENDCHANGING = 0x0400

MONITOR_DEFAULTTONEAREST = 2

SM_CXSCREEN = 0
SM_CYSCREEN = 1
SM_CYCAPTION = 4
SM_CXSIZEFRAME = 32
SM_CYSIZEFRAME = 33
SM_CXPADDEDBORDER = 92
SPI_GETWORKAREA = 0x0030

GA_ROOT = 2
GW_OWNER = 4

SWP_ASYNCWINDOWPOS = 0x4000

WM_GETICON = 0x007F
ICON_BIG = 1
ICON_SMALL = 0
ICON_SMALL2 = 2

WH_MOUSE_LL = 14
WH_KEYBOARD_LL = 13
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
WM_KEYDOWN = 0x0100
VK_ESCAPE = 0x1B

EVENT_SYSTEM_FOREGROUND = 0x0003
WINEVENT_OUTOFCONTEXT = 0x0000
WINEVENT_SKIPOWNPROCESS = 0x0002

BI_RGB = 0
DIB_RGB_COLORS = 0
SRCCOPY = 0x00CC0020
PW_RENDERFULLCONTENT = 2
HALFTONE = 4

MAX_PATH = 260

# ------------------------------------------------------------------ 结构体
class POINT(Structure):
    _fields_ = [("x", c_long), ("y", c_long)]


class RECT(Structure):
    _fields_ = [("left", c_long), ("top", c_long), ("right", c_long), ("bottom", c_long)]

    @property
    def width(self):
        return self.right - self.left

    @property
    def height(self):
        return self.bottom - self.top


class WINDOWPLACEMENT(Structure):
    _fields_ = [
        ("length", wintypes.UINT),
        ("flags", wintypes.UINT),
        ("showCmd", wintypes.UINT),
        ("ptMinPosition", POINT),
        ("ptMaxPosition", POINT),
        ("rcNormalPosition", RECT),
    ]


class MONITORINFO(Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("rcMonitor", RECT),
        ("rcWork", RECT),
        ("dwFlags", wintypes.DWORD),
    ]


class BITMAPINFOHEADER(Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD),
        ("biWidth", c_long),
        ("biHeight", c_long),
        ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD),
        ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD),
        ("biXPelsPerMeter", c_long),
        ("biYPelsPerMeter", c_long),
        ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


class BITMAPINFO(Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 3)]


class MSLLHOOKSTRUCT(Structure):
    _fields_ = [
        ("pt", POINT),
        ("mouseData", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class DWM_THUMBNAIL_PROPERTIES(Structure):
    _fields_ = [
        ("dwFlags", wintypes.DWORD),
        ("rcDestination", RECT),
        ("rcSource", RECT),
        ("opacity", c_byte),
        ("fVisible", wintypes.BOOL),
        ("fSourceClientAreaOnly", wintypes.BOOL),
    ]


DWM_TNP_RECTDESTINATION = 0x00000001
DWM_TNP_RECTSOURCE = 0x00000002
DWM_TNP_OPACITY = 0x00000004
DWM_TNP_VISIBLE = 0x00000008
DWM_TNP_SOURCECLIENTAREAONLY = 0x00000010


# ------------------------------------------------------------------ 原型
WNDENUMPROC = WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
MONITORENUMPROC = WINFUNCTYPE(wintypes.BOOL, wintypes.HMONITOR, wintypes.HDC,
                              POINTER(RECT), wintypes.LPARAM)
HOOKPROC = WINFUNCTYPE(c_ssize_t, c_int, wintypes.WPARAM, wintypes.LPARAM)

user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
user32.EnumWindows.restype = wintypes.BOOL
user32.IsWindowVisible.argtypes = [wintypes.HWND]
user32.IsWindowVisible.restype = wintypes.BOOL
user32.IsWindow.argtypes = [wintypes.HWND]
user32.IsWindow.restype = wintypes.BOOL
user32.IsIconic.argtypes = [wintypes.HWND]
user32.IsIconic.restype = wintypes.BOOL
user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
user32.GetWindowTextLengthW.restype = c_int
user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, c_int]
user32.GetWindowTextW.restype = c_int
user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, c_int]
user32.GetClassNameW.restype = c_int
user32.GetWindowRect.argtypes = [wintypes.HWND, POINTER(RECT)]
user32.GetWindowRect.restype = wintypes.BOOL
user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, c_int]
user32.GetWindowLongPtrW.restype = c_ssize_t
user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, c_int, c_ssize_t]
user32.SetWindowLongPtrW.restype = c_ssize_t
user32.GetWindowPlacement.argtypes = [wintypes.HWND, POINTER(WINDOWPLACEMENT)]
user32.GetWindowPlacement.restype = wintypes.BOOL
user32.SetWindowPlacement.argtypes = [wintypes.HWND, POINTER(WINDOWPLACEMENT)]
user32.SetWindowPlacement.restype = wintypes.BOOL
user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, c_int, c_int, c_int, c_int, c_uint]
user32.SetWindowPos.restype = wintypes.BOOL
user32.ShowWindow.argtypes = [wintypes.HWND, c_int]
user32.ShowWindow.restype = wintypes.BOOL
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.SetForegroundWindow.restype = wintypes.BOOL
user32.GetForegroundWindow.restype = wintypes.HWND
user32.PostMessageW.argtypes = [wintypes.HWND, c_uint, wintypes.WPARAM, wintypes.LPARAM]
user32.PostMessageW.restype = wintypes.BOOL
user32.SendMessageW.argtypes = [wintypes.HWND, c_uint, wintypes.WPARAM, wintypes.LPARAM]
user32.SendMessageW.restype = wintypes.LPARAM
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, POINTER(wintypes.DWORD)]
user32.GetWindowThreadProcessId.restype = wintypes.DWORD
user32.EnumDisplayMonitors.argtypes = [wintypes.HDC, POINTER(RECT), MONITORENUMPROC, wintypes.LPARAM]
user32.EnumDisplayMonitors.restype = wintypes.BOOL
user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
user32.MonitorFromWindow.restype = wintypes.HMONITOR
user32.GetMonitorInfoW.argtypes = [wintypes.HMONITOR, POINTER(MONITORINFO)]
user32.GetMonitorInfoW.restype = wintypes.BOOL
user32.GetSystemMetrics.argtypes = [c_int]
user32.GetSystemMetrics.restype = c_int
user32.GetCursorPos.argtypes = [POINTER(POINT)]
user32.GetCursorPos.restype = wintypes.BOOL
user32.GetDC.argtypes = [wintypes.HWND]
user32.GetDC.restype = wintypes.HDC
user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
user32.ReleaseDC.restype = c_int
user32.PrintWindow.argtypes = [wintypes.HWND, wintypes.HDC, c_uint]
user32.PrintWindow.restype = wintypes.BOOL
user32.SetProcessDPIAware.restype = wintypes.BOOL
user32.WindowFromPoint.argtypes = [POINT]
user32.WindowFromPoint.restype = wintypes.HWND
user32.GetAncestor.argtypes = [wintypes.HWND, c_uint]
user32.GetAncestor.restype = wintypes.HWND
user32.IsZoomed.argtypes = [wintypes.HWND]
user32.IsZoomed.restype = wintypes.BOOL
user32.GetWindow.argtypes = [wintypes.HWND, c_uint]
user32.GetWindow.restype = wintypes.HWND
user32.MonitorFromPoint.argtypes = [POINT, wintypes.DWORD]
user32.MonitorFromPoint.restype = wintypes.HMONITOR
user32.SystemParametersInfoW.argtypes = [wintypes.UINT, wintypes.UINT,
                                         ctypes.c_void_p, wintypes.UINT]
user32.SystemParametersInfoW.restype = wintypes.BOOL

dwmapi.DwmRegisterThumbnail.argtypes = [wintypes.HWND, wintypes.HWND, POINTER(c_void_p)]
dwmapi.DwmRegisterThumbnail.restype = c_long
dwmapi.DwmUnregisterThumbnail.argtypes = [c_void_p]
dwmapi.DwmUnregisterThumbnail.restype = c_long
dwmapi.DwmUpdateThumbnailProperties.argtypes = [c_void_p, POINTER(DWM_THUMBNAIL_PROPERTIES)]
dwmapi.DwmUpdateThumbnailProperties.restype = c_long
dwmapi.DwmQueryThumbnailSourceSize.argtypes = [c_void_p, POINTER(wintypes.SIZE)]
dwmapi.DwmQueryThumbnailSourceSize.restype = c_long

gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
gdi32.CreateCompatibleDC.restype = wintypes.HDC
gdi32.CreateCompatibleBitmap.argtypes = [wintypes.HDC, c_int, c_int]
gdi32.CreateCompatibleBitmap.restype = wintypes.HBITMAP
gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
gdi32.SelectObject.restype = wintypes.HGDIOBJ
gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
gdi32.DeleteObject.restype = wintypes.BOOL
gdi32.DeleteDC.argtypes = [wintypes.HDC]
gdi32.DeleteDC.restype = wintypes.BOOL
gdi32.BitBlt.argtypes = [wintypes.HDC, c_int, c_int, c_int, c_int, wintypes.HDC, c_int, c_int, wintypes.DWORD]
gdi32.BitBlt.restype = wintypes.BOOL
gdi32.StretchBlt.argtypes = [wintypes.HDC, c_int, c_int, c_int, c_int, wintypes.HDC, c_int, c_int, c_int, c_int, wintypes.DWORD]
gdi32.StretchBlt.restype = wintypes.BOOL
gdi32.SetStretchBltMode.argtypes = [wintypes.HDC, c_int]
gdi32.SetStretchBltMode.restype = c_int
gdi32.GetDIBits.argtypes = [wintypes.HDC, wintypes.HBITMAP, c_uint, c_uint, wintypes.LPVOID, POINTER(BITMAPINFO), c_uint]
gdi32.GetDIBits.restype = c_int

kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype = wintypes.HMODULE
user32.SetWindowsHookExW.argtypes = [c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
user32.SetWindowsHookExW.restype = wintypes.HHOOK
user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
user32.UnhookWindowsHookEx.restype = wintypes.BOOL
user32.CallNextHookEx.argtypes = [wintypes.HHOOK, c_int, wintypes.WPARAM, wintypes.LPARAM]
user32.CallNextHookEx.restype = c_ssize_t
user32.keybd_event.argtypes = [wintypes.BYTE, wintypes.BYTE, wintypes.DWORD, ctypes.c_size_t]
user32.keybd_event.restype = None
WINEVENTPROC = WINFUNCTYPE(None, wintypes.HANDLE, wintypes.DWORD, wintypes.HWND,
                           wintypes.LONG, wintypes.LONG, wintypes.DWORD, wintypes.DWORD)
user32.SetWinEventHook.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.HMODULE,
                                   WINEVENTPROC, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD]
user32.SetWinEventHook.restype = wintypes.HANDLE
user32.UnhookWinEvent.argtypes = [wintypes.HANDLE]
user32.UnhookWinEvent.restype = wintypes.BOOL
user32.mouse_event.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_size_t]
user32.mouse_event.restype = None
user32.SetCursorPos.argtypes = [c_int, c_int]
user32.SetCursorPos.restype = wintypes.BOOL
user32.GetSystemMetrics.argtypes = [c_int]


# ------------------------------------------------------------------ 基础查询
def enum_windows(cb):
    """枚举所有顶层窗口，cb(hwnd) 返回 True 继续。"""
    def _wrap(hwnd, lparam):
        return 1 if cb(hwnd) else 0
    user32.EnumWindows(WNDENUMPROC(_wrap), 0)


def get_title(hwnd):
    n = user32.GetWindowTextLengthW(hwnd)
    if n <= 0:
        return ""
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def get_class(hwnd):
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def get_rect(hwnd):
    r = RECT()
    user32.GetWindowRect(hwnd, byref(r))
    return (r.left, r.top, r.width, r.height)


def is_visible(hwnd):
    return bool(user32.IsWindowVisible(hwnd))


def is_window(hwnd):
    """句柄是否还是一个有效窗口。"""
    if not hwnd:
        return False
    try:
        return bool(user32.IsWindow(hwnd))
    except Exception:
        return False


def is_iconic(hwnd):
    return bool(user32.IsIconic(hwnd))


def get_style(hwnd):
    return user32.GetWindowLongPtrW(hwnd, GWL_STYLE)


def get_exstyle(hwnd):
    return user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)


def set_style(hwnd, style):
    user32.SetWindowLongPtrW(hwnd, GWL_STYLE, style)


def set_exstyle(hwnd, exstyle):
    user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, exstyle)


def get_placement(hwnd):
    wp = WINDOWPLACEMENT()
    wp.length = sizeof(WINDOWPLACEMENT)
    if user32.GetWindowPlacement(hwnd, byref(wp)):
        return wp
    return None


def set_placement(hwnd, wp):
    wp.length = sizeof(WINDOWPLACEMENT)
    return bool(user32.SetWindowPlacement(hwnd, byref(wp)))


def set_pos(hwnd, insert_after, x, y, cx, cy, flags):
    return bool(user32.SetWindowPos(hwnd, insert_after, x, y, cx, cy, flags))


def show(hwnd, cmd):
    return bool(user32.ShowWindow(hwnd, cmd))


def focus(hwnd):
    """把窗口提到前台（需要一点技巧绕过前台锁）。"""
    fg = user32.GetForegroundWindow()
    if fg == hwnd:
        return True
    # 模拟按下再松开 Alt，绕过 SetForegroundWindow 限制
    user32.keybd_event(0x12, 0, 0, 0)        # VK_MENU down
    user32.keybd_event(0x12, 0, 0x0002, 0)   # VK_MENU up
    return bool(user32.SetForegroundWindow(hwnd))


def minimize(hwnd):
    return show(hwnd, SW_MINIMIZE)


def get_foreground_window():
    return user32.GetForegroundWindow()


def window_from_point(x, y):
    """取屏幕坐标 (x, y) 处最内层的窗口。"""
    return user32.WindowFromPoint(POINT(int(x), int(y)))


def root_window(hwnd):
    """取顶层窗口（去掉子控件）。"""
    if not hwnd:
        return None
    r = user32.GetAncestor(hwnd, GA_ROOT)
    return r or hwnd


def owner_window(hwnd):
    return user32.GetWindow(hwnd, GW_OWNER)


def is_zoomed(hwnd):
    """窗口是否处于最大化状态。"""
    return bool(user32.IsZoomed(hwnd))


def normal_rect(hwnd):
    """窗口「还原后」的位置尺寸。

    最大化时 GetWindowRect 返回的是铺满屏幕的矩形，直接存下来会把
    「正常尺寸」污染成屏幕大小，下次还原就再也回不到原来的窗口大小。
    这里改用 WINDOWPLACEMENT.rcNormalPosition —— 它就是系统自己记的
    还原尺寸，最大化/最小化状态下依然有效。
    """
    try:
        wp = get_placement(hwnd)
    except Exception:
        wp = None
    if wp is not None:
        r = wp.rcNormalPosition
        ww, hh = int(r.right - r.left), int(r.bottom - r.top)
        if ww >= 80 and hh >= 60:
            return (int(r.left), int(r.top), ww, hh)
    return get_rect(hwnd)


def caption_height():
    """估算窗口标题栏的屏幕高度（用于判断双击是否落在标题栏上）。"""
    cap = user32.GetSystemMetrics(SM_CYCAPTION)
    frame = user32.GetSystemMetrics(SM_CYSIZEFRAME)
    pad = user32.GetSystemMetrics(SM_CXPADDEDBORDER)
    return max(20, cap + frame * 2 + pad)


def get_pid(hwnd):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, byref(pid))
    return pid.value


def post_close(hwnd):
    user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE


def get_hicon(hwnd, which=ICON_BIG):
    return user32.SendMessageW(hwnd, WM_GETICON, which, 0)


def monitor_from_window(hwnd):
    hmon = user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)
    mi = MONITORINFO()
    mi.cbSize = sizeof(MONITORINFO)
    if hmon and user32.GetMonitorInfoW(hmon, byref(mi)):
        return mi
    return None


def monitor_from_point(x, y):
    hmon = user32.MonitorFromPoint(POINT(int(x), int(y)), MONITOR_DEFAULTTONEAREST)
    mi = MONITORINFO()
    mi.cbSize = sizeof(MONITORINFO)
    if hmon and user32.GetMonitorInfoW(hmon, byref(mi)):
        return mi
    return None


def enum_monitor_work_rects():
    """返回所有显示器的工作区矩形 [(left, top, width, height), ...]。

    虚拟桌面下负坐标（副屏在左）是合法的，不能只看 x 正负判断窗口是否出界，
    必须逐屏比较。取 rcWork（已排除任务栏），与 SetWindowPos 使用的坐标系一致。
    """
    rects = []

    def cb(hmon, hdc, lprc, data):
        mi = MONITORINFO()
        mi.cbSize = sizeof(MONITORINFO)
        if user32.GetMonitorInfoW(hmon, byref(mi)):
            r = mi.rcWork
            if r.width > 100 and r.height > 100:
                rects.append((r.left, r.top, r.width, r.height))
        return True

    try:
        cb_fn = MONITORENUMPROC(cb)
        user32.EnumDisplayMonitors(None, None, cb_fn, 0)
    except Exception:
        pass
    if not rects:
        rects = [primary_work_rect()]
    return rects


def rect_visible_fraction(l, t, ww, hh, work_rects=None):
    """窗口矩形与「任一显示器工作区」的最大交集面积占比（0~1）。

    用它判断窗口是「只露一个边角」还是「正常显示」，比看 x 是否小于 -4000
    可靠得多：副屏负坐标不算异常，真正出界的窗口占比会很低。
    """
    if ww <= 0 or hh <= 0:
        return 0.0
    area = float(ww * hh)
    rects = work_rects if work_rects is not None else enum_monitor_work_rects()
    best = 0.0
    for (rx, ry, rw, rh) in rects:
        ix = max(0, min(l + ww, rx + rw) - max(l, rx))
        iy = max(0, min(t + hh, ry + rh) - max(t, ry))
        best = max(best, (ix * iy) / area)
    return best


def is_window_visible_enough(hwnd, min_fraction=0.35, work_rects=None):
    """窗口是否至少有 min_fraction 落在某个工作区内（可正常看见/拖动）。"""
    try:
        l, t, ww, hh = get_rect(hwnd)
    except Exception:
        return True
    return rect_visible_fraction(l, t, ww, hh, work_rects) >= min_fraction


def primary_work_rect():
    """主显示器的工作区（已排除任务栏）。"""
    r = RECT()
    try:
        if user32.SystemParametersInfoW(SPI_GETWORKAREA, 0, byref(r), 0):
            if r.width > 100 and r.height > 100:
                return (r.left, r.top, r.width, r.height)
    except Exception:
        pass
    return primary_screen_rect()


def primary_screen_rect():
    return (0, 0, user32.GetSystemMetrics(SM_CXSCREEN), user32.GetSystemMetrics(SM_CYSCREEN))


def cursor_pos():
    pt = POINT()
    user32.GetCursorPos(byref(pt))
    return (pt.x, pt.y)


# ------------------------------------------------------------------ DWM 缩略图
def thumbnail_register(dst_hwnd, src_hwnd):
    """把 src 窗口的画面挂到 dst 窗口上（类似 Win11 任务栏预览）。"""
    h = c_void_p()
    try:
        hr = dwmapi.DwmRegisterThumbnail(dst_hwnd, src_hwnd, byref(h))
    except Exception:
        return None
    return h.value if hr == 0 else None


def thumbnail_source_size(hthumb):
    s = wintypes.SIZE()
    try:
        if dwmapi.DwmQueryThumbnailSourceSize(hthumb, byref(s)) == 0:
            return (s.cx, s.cy)
    except Exception:
        pass
    return None


def thumbnail_set(hthumb, x, y, w, h, visible=True, client_only=False, opacity=255):
    """设置缩略图在目标窗口内的绘制区域与可见性。"""
    p = DWM_THUMBNAIL_PROPERTIES()
    p.dwFlags = DWM_TNP_RECTDESTINATION | DWM_TNP_VISIBLE | DWM_TNP_OPACITY
    p.rcDestination = RECT(int(x), int(y), int(x + w), int(y + h))
    p.fVisible = bool(visible)
    p.opacity = int(opacity)
    if client_only:
        p.dwFlags |= DWM_TNP_SOURCECLIENTAREAONLY
        p.fSourceClientAreaOnly = True
    try:
        return dwmapi.DwmUpdateThumbnailProperties(hthumb, byref(p)) == 0
    except Exception:
        return False


def thumbnail_unregister(hthumb):
    if not hthumb:
        return
    try:
        dwmapi.DwmUnregisterThumbnail(hthumb)
    except Exception:
        pass


# ------------------------------------------------------------------ 窗口捕获
def capture_window(hwnd, max_width=640):
    """用 PrintWindow 抓取窗口内容，返回 QImage；失败返回 None。"""
    if not hwnd or not user32.IsWindow(hwnd):
        return None
    l, t, w, h = get_rect(hwnd)
    if w <= 0 or h <= 0:
        return None
    hdc_win = user32.GetDC(hwnd)
    if not hdc_win:
        return None
    mem_dc = gdi32.CreateCompatibleDC(hdc_win)
    bmp = gdi32.CreateCompatibleBitmap(hdc_win, w, h)
    old_obj = gdi32.SelectObject(mem_dc, bmp) if mem_dc and bmp else None
    ok = False
    if mem_dc and bmp:
        ok = user32.PrintWindow(hwnd, mem_dc, PW_RENDERFULLCONTENT)
        if not ok:
            gdi32.BitBlt(mem_dc, 0, 0, w, h, hdc_win, 0, 0, SRCCOPY)
    img = None
    if mem_dc and bmp:
        bi = BITMAPINFO()
        bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER)
        bi.bmiHeader.biWidth = w
        bi.bmiHeader.biHeight = h
        bi.bmiHeader.biPlanes = 1
        bi.bmiHeader.biBitCount = 32
        bi.bmiHeader.biCompression = BI_RGB
        buf = (c_byte * (w * h * 4))()
        got = gdi32.GetDIBits(mem_dc, bmp, 0, h, buf, byref(bi), DIB_RGB_COLORS)
        if got:
            img = QImage(bytes(buf), w, h, QImage.Format_RGB32).mirrored(False, True).rgbSwapped()
    if old_obj:
        gdi32.SelectObject(mem_dc, old_obj)
    if bmp:
        gdi32.DeleteObject(bmp)
    if mem_dc:
        gdi32.DeleteDC(mem_dc)
    user32.ReleaseDC(hwnd, hdc_win)
    if img is None or img.isNull():
        return None
    if img.width() > max_width:
        img = img.scaledToWidth(max_width, 0)  # Qt::FastTransformation
    return img
