# -*- coding: utf-8 -*-
"""
SeelenLite - build.py
一键打包脚本：调用 PyInstaller 生成单文件 exe。
用法：
    python build.py            # 打包到 dist/SeelenLite.exe
    python build.py --clean    # 打包前清理 build/ dist/
"""
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ENTRY = os.path.join(HERE, "main.py")
ICON = os.path.join(HERE, "icon.ico")
OUT_NAME = "SeelenLite"

# 本项目只用到 QtWidgets / QtGui / QtCore，其余 Qt 模块全部排除以减小体积
EXCLUDES = [
    "PyQt5.QtWebEngineCore", "PyQt5.QtWebEngineWidgets", "PyQt5.QtWebEngine",
    "PyQt5.QtQml", "PyQt5.QtQuick", "PyQt5.QtQuickWidgets",
    "PyQt5.QtMultimedia", "PyQt5.QtMultimediaWidgets", "PyQt5.QtSql",
    "PyQt5.QtTest", "PyQt5.QtDesigner", "PyQt5.QtBluetooth", "PyQt5.QtNfc",
    "PyQt5.QtPositioning", "PyQt5.QtLocation", "PyQt5.QtSensors",
    "PyQt5.QtSerialPort", "PyQt5.QtXmlPatterns",
    "PyQt5.Qt3DCore", "PyQt5.Qt3DExtras", "PyQt5.Qt3DInput",
    "PyQt5.Qt3DLogic", "PyQt5.Qt3DRender",
    "PyQt5.QtChart", "PyQt5.QtDataVisualization", "PyQt5.QtPurchasing",
    "PyQt5.QtRemoteobjects", "PyQt5.QtScxml", "PyQt5.QtTextToSpeech",
    "PyQt5.QtWebChannel", "PyQt5.QtWebSockets", "PyQt5.QtHelp",
    "PyQt5.QtScript", "PyQt5.QtScriptTools",
]


def main():
    if "--clean" in sys.argv:
        for d in ("build", "dist"):
            p = os.path.join(HERE, d)
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
                print("removed", p)

    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--name", OUT_NAME,
        "--hidden-import", "PyQt5.sip",
        "--collect-submodules", "PyQt5",
    ]
    if os.path.isfile(ICON):
        cmd += ["--icon", ICON]
    for m in EXCLUDES:
        cmd += ["--exclude-module", m]
    cmd.append(ENTRY)

    print("building ...", flush=True)
    rc = subprocess.call(cmd, cwd=HERE)
    if rc != 0:
        print("BUILD_FAILED rc=", rc)
        return rc

    exe = os.path.join(HERE, "dist", OUT_NAME + ".exe")
    if os.path.isfile(exe):
        size = os.path.getsize(exe) / 1024 / 1024
        print("BUILD_OK %s  %.1f MB" % (exe, size))
    return 0


if __name__ == "__main__":
    sys.exit(main())
