# -*- coding: utf-8 -*-
"""
SeelenLite - ui.py
仿 Seelen UI 的桌面组件：Dock 程序坞、顶部全局栏、Mission Control 式窗口总览。
全部使用自绘（paintEvent），保证在 Windows 上透明/毛玻璃效果稳定。
"""
import math
import os

from PyQt5.QtCore import Qt, QRect, QRectF, QPoint, QTimer, pyqtSignal, QSize
from PyQt5.QtGui import (QPainter, QColor, QPen, QBrush, QFont, QFontMetrics,
                         QPixmap, QImage, QIcon, QLinearGradient, QPainterPath)
from PyQt5.QtWidgets import (QWidget, QApplication, QMenu, QAction, QSystemTrayIcon,
                             QGraphicsDropShadowEffect, QDialog)

import win32api as w
from core import icon_for_exe, APP_VERSION, set_autostart

APP_VERSION_S = APP_VERSION

# ------------------------------------------------------------------ 主题
class Theme:
    BG          = QColor(17, 19, 25, 255)
    BG_LIGHT    = QColor(246, 247, 250, 255)
    BORDER      = QColor(255, 255, 255, 26)
    BORDER_DARK = QColor(255, 255, 255, 34)
    TEXT        = QColor(244, 245, 248)
    TEXT_DIM    = QColor(255, 255, 255, 120)
    ACCENT      = QColor(0, 122, 255)
    ACCENT_SOFT = QColor(0, 122, 255, 70)
    CARD        = QColor(255, 255, 255, 16)
    CARD_HOVER  = QColor(255, 255, 255, 40)
    OVERLAY     = QColor(8, 9, 12, 172)
    DANGER      = QColor(255, 69, 58)
    FONT        = "Segoe UI"
    FONT_CN     = "Microsoft YaHei"


def _screen():
    return QApplication.primaryScreen()


def _screen_rect():
    return _screen().geometry()


def _font(size=12, bold=False, cn=False):
    f = QFont(Theme.FONT_CN if cn else Theme.FONT, size)
    f.setBold(bold)
    return f


def _round(painter, rect, radius):
    painter.drawRoundedRect(QRectF(rect), radius, radius)


def _friendly_name(path):
    """把 exe 路径转成短名称，用于程序坞提示。"""
    if not path:
        return ""
    name = os.path.basename(path)
    if name.lower().endswith(".exe"):
        name = name[:-4]
    return name or path


# ================================================================== Dock
class Dock(QWidget):
    """macOS 风格程序坞：运行/固定应用、悬停放大、单击展开、双击放大。"""

    settings_requested = pyqtSignal()
    overview_requested = pyqtSignal()
    restore_cards_requested = pyqtSignal()
    quit_requested = pyqtSignal()

    def __init__(self, wm, settings, parent=None):
        super().__init__(parent)
        self.wm = wm
        self.settings = settings
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setFocusPolicy(Qt.NoFocus)
        self.setMouseTracking(True)

        self.icon_size = 46
        self.pad = 10
        self.bottom_margin = 8
        self.gap = 8
        self.max_scale = 1.65
        self.sigma = 78.0

        self.items = []          # [{'exe','title','hwnds','icon','pinned'}]
        self.rects = []
        self._mouse_x = -9999
        self._scales = []
        self._hover = -1

        self._anim = QTimer(self)
        self._anim.setInterval(16)
        self._anim.timeout.connect(self._tick)

        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(800)
        self._refresh_timer.timeout.connect(self.refresh)
        self._refresh_timer.start()

    # ---------------- 数据 ----------------
    def refresh(self):
        try:
            self.wm.refresh()
        except Exception:
            import traceback; traceback.print_exc()
            return
        running = {}
        for it in self.wm.windows:
            key = (it.exe or "").lower()
            if not key:
                key = "hwnd:%d" % it.hwnd
            running.setdefault(key, {"exe": it.exe, "title": it.title,
                                     "hwnds": [], "icon": it.icon, "pinned": False})
            running[key]["hwnds"].append(it.hwnd)
            if not running[key]["exe"] and it.exe:
                running[key]["exe"] = it.exe

        items = []
        used = set()
        for exe in self.settings.pinned:
            if not exe:
                continue
            key = exe.lower()
            entry = running.pop(key, None)
            icon = entry["icon"] if entry else None
            if icon is None or icon.isNull():
                from core import icon_for_exe
                icon = icon_for_exe(exe)
            items.append({"exe": exe, "title": _friendly_name(exe),
                          "hwnds": entry["hwnds"] if entry else [],
                          "icon": icon, "pinned": True})
            used.add(key)
        # 其余运行中的窗口，按进程聚合
        for key, entry in running.items():
            if key.startswith("hwnd:"):
                # 无进程信息，仍显示
                pass
            items.append({"exe": entry["exe"], "title": entry["title"] or _friendly_name(entry["exe"]),
                          "hwnds": entry["hwnds"], "icon": entry["icon"], "pinned": False})

        self.items = items
        self._scales = [1.0] * len(items)
        self._layout()
        self.update()

    def _layout(self):
        n = len(self.items)
        size = self.icon_size
        self.tip_h = 30
        extra = int(size * (self.max_scale - 1.0)) + 6
        height = self.tip_h + size + self.pad * 2 + extra
        width = self.pad * 2 + max(1, n) * (size + self.gap) - self.gap
        width = max(width, 180)
        sr = _screen_rect()
        try:
            wx, wy, WW, HH = w.primary_work_rect()
            if WW < 400 or HH < 300:
                wx, wy, WW, HH = sr.x(), sr.y(), sr.width(), sr.height()
        except Exception:
            wx, wy, WW, HH = sr.x(), sr.y(), sr.width(), sr.height()
        x = wx + (WW - width) // 2
        y = wy + HH - self.bottom_margin - height
        self.setGeometry(x, y, width, height)
        self.rects = []
        iy = height - self.pad - size
        for i in range(n):
            ix = self.pad + i * (size + self.gap)
            self.rects.append(QRect(ix, iy, size, size))

    def _target_scale(self, i):
        if not self.settings.dock_magnify or self._mouse_x < -999:
            return 1.0
        cx = self.rects[i].center().x() if i < len(self.rects) else 0
        d = abs(self._mouse_x - cx)
        return 1.0 + (self.max_scale - 1.0) * math.exp(-(d / self.sigma) ** 2)

    def _tick(self):
        if not self.rects:
            return
        changed = False
        for i in range(len(self.items)):
            tgt = self._target_scale(i)
            cur = self._scales[i]
            new = cur + (tgt - cur) * 0.35
            if abs(new - cur) > 0.004:
                changed = True
            self._scales[i] = new
        if changed:
            self.update()

    # ---------------- 交互 ----------------
    def mouseMoveEvent(self, e):
        self._mouse_x = e.x()
        self._anim.start() if not self._anim.isActive() else None
        hover = -1
        for i, r in enumerate(self.rects):
            if r.contains(e.pos()):
                hover = i
                break
        if hover != self._hover:
            self._hover = hover
            self.update()

    def leaveEvent(self, e):
        self._mouse_x = -9999
        self._hover = -1
        self.update()

    def mousePressEvent(self, e):
        idx = self._index_at(e.pos())
        if idx < 0:
            if e.button() == Qt.RightButton:
                self._bg_menu(e.globalPos())
            return
        it = self.items[idx]
        if e.button() == Qt.RightButton:
            self._menu(it, e.globalPos())
        elif e.button() == Qt.LeftButton:
            if it["hwnds"]:
                h = it["hwnds"][0]
                cards = getattr(self.wm, "cards", None)
                if cards is not None and cards.is_card(h):
                    # 已经是卡片：直接展开
                    cards.expand(h)
                    return
                self.wm.focus(self.wm.by_hwnd(h) or self._info_for(h))
            else:
                self.wm.launch(it["exe"])

    def mouseDoubleClickEvent(self, e):
        idx = self._index_at(e.pos())
        if idx < 0 or e.button() != Qt.LeftButton:
            return
        it = self.items[idx]
        if it["hwnds"]:
            h = it["hwnds"][0]
            cards = getattr(self.wm, "cards", None)
            if cards is not None and cards.is_card(h):
                cards.expand(h)
                return
            info = self.wm.by_hwnd(h) or self._info_for(h)
            if info:
                self.wm.toggle_max(info)
        else:
            self.wm.launch(it["exe"])

    def _info_for(self, hwnd):
        info = self.wm.by_hwnd(hwnd)
        if info:
            return info
        return None

    def _index_at(self, pos):
        for i, r in enumerate(self.rects):
            if r.contains(pos):
                return i
        return -1

    def _bg_menu(self, gpos):
        """程序坞空白处右键：程序坞就是唯一入口时的总菜单。"""
        m = QMenu(self)
        m.setStyleSheet("""
            QMenu { background:#1b1d24; color:#f2f3f7; border:1px solid #3a3d47;
                     border-radius:8px; padding:6px; font-family:'Microsoft YaHei'; font-size:12px;}
            QMenu::item { padding:6px 18px; border-radius:6px; }
            QMenu::item:selected { background:#0a84ff; }
            QMenu::separator { height:1px; background:#3a3d47; margin:5px 8px; }
        """)
        a = m.addAction("设置…")
        a.triggered.connect(self.settings_requested.emit)
        m.addSeparator()
        a = m.addAction("窗口总览")
        a.triggered.connect(self.overview_requested.emit)
        a = m.addAction("展开所有卡片")
        a.triggered.connect(self.restore_cards_requested.emit)
        a = m.addAction("显示桌面")
        a.triggered.connect(self.wm.show_desktop)
        m.addSeparator()
        a = m.addAction("隐藏程序坞（托盘图标可恢复）")
        a.triggered.connect(self._hide_self)
        a = m.addAction("退出 SeelenLite")
        a.triggered.connect(self.quit_requested.emit)
        m.exec_(gpos)

    def _menu(self, it, gpos):
        m = QMenu(self)
        m.setStyleSheet("""
            QMenu { background:#1b1d24; color:#f2f3f7; border:1px solid #3a3d47;
                     border-radius:8px; padding:6px; font-family:'Microsoft YaHei'; font-size:12px;}
            QMenu::item { padding:6px 18px; border-radius:6px; }
            QMenu::item:selected { background:#0a84ff; }
            QMenu::separator { height:1px; background:#3a3d47; margin:5px 8px; }
        """)
        if it["hwnds"]:
            a = m.addAction("激活")
            a.triggered.connect(lambda: self.wm.focus(self.wm.by_hwnd(it["hwnds"][0])))
            a = m.addAction("最大化 / 缩回")
            a.triggered.connect(lambda: self.wm.toggle_max(
                self.wm.by_hwnd(it["hwnds"][0])))
            a = m.addAction("最小化")
            a.triggered.connect(lambda: self.wm.minimize(self.wm.by_hwnd(it["hwnds"][0])))
            m.addSeparator()
        if it["pinned"]:
            a = m.addAction("从程序坞移除")
            a.triggered.connect(lambda: self._unpin(it["exe"]))
        else:
            a = m.addAction("固定到程序坞")
            a.triggered.connect(lambda: self._pin(it["exe"]))
        if it["hwnds"]:
            m.addSeparator()
            a = m.addAction("关闭窗口")
            a.triggered.connect(lambda: self.wm.close(self.wm.by_hwnd(it["hwnds"][0])))
        m.exec_(gpos)

    def _hide_self(self):
        self.settings.show_dock = False
        self.settings.save()
        self.hide()

    def _pin(self, exe):
        if exe and exe not in self.settings.pinned:
            self.settings.pinned.append(exe)
            self.settings.save()
            self.refresh()

    def _unpin(self, exe):
        if exe in self.settings.pinned:
            self.settings.pinned.remove(exe)
            self.settings.save()
            self.refresh()

    # ---------------- 绘制 ----------------
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        r = self.rect()
        # 底板
        p.setPen(QPen(Theme.BORDER, 1))
        p.setBrush(QBrush(Theme.BG))
        _round(p, r, 18)
        p.setPen(Qt.NoPen)

        fm = QFontMetrics(_font(11, cn=True))
        for i, it in enumerate(self.items):
            if i >= len(self.rects):
                break
            base = self.rects[i]
            s = max(0.2, self._scales[i]) * self.icon_size
            cx = base.center().x()
            bottom = r.height() - self.pad
            icon_rect = QRect(int(cx - s / 2), int(bottom - s), int(s), int(s))
            pix = it["icon"].pixmap(int(s), int(s)) if it["icon"] and not it["icon"].isNull() \
                else QPixmap(int(s), int(s))
            if pix.isNull():
                p.setBrush(QBrush(Theme.CARD_HOVER))
                _round(p, icon_rect, int(s * 0.22))
            else:
                p.drawPixmap(icon_rect, pix)

            running = bool(it["hwnds"])
            if it["pinned"] and not running:
                p.setBrush(QBrush(QColor(0, 0, 0, 90)))
                _round(p, icon_rect, int(s * 0.22))

            if running:
                dot = 4
                p.setBrush(QBrush(Theme.ACCENT))
                p.drawEllipse(int(cx - dot / 2), int(bottom) + 2, dot, dot)

            if i == self._hover:
                label = it["title"]
                if label.lower().endswith(".exe"):
                    label = label[:-4]
                txt = fm.elidedText(label, Qt.ElideRight, 120)
                tw = fm.horizontalAdvance(txt)
                lx = int(cx - tw / 2)
                ly = 4
                p.setBrush(QBrush(QColor(20, 22, 30, 220)))
                p.setPen(QPen(Theme.BORDER, 1))
                _round(p, QRect(lx - 8, ly, int(tw) + 16, 22), 8)
                p.setPen(QPen(Theme.TEXT))
                p.setFont(_font(11, cn=True))
                p.drawText(QRect(lx - 8, ly, int(tw) + 16, 22), Qt.AlignCenter, txt)
        p.end()


# ================================================================== 顶栏
class TopBar(QWidget):
    """顶部全局栏：左侧应用名 + 活动窗口，右侧时钟与功能按钮。"""

    overview_clicked = pyqtSignal()
    desktop_clicked = pyqtSignal()
    tile_clicked = pyqtSignal(str)
    menu_clicked = pyqtSignal(QPoint)

    def __init__(self, wm, settings, parent=None):
        super().__init__(parent)
        self.wm = wm
        self.settings = settings
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setFocusPolicy(Qt.NoFocus)
        self.setMouseTracking(True)
        self.height = 30
        self.buttons = {}     # name -> QRect
        self.active_title = ""
        self.clock_text = ""
        self.date_text = ""
        self._hover = None

        self._timer = QTimer(self)
        self._timer.setInterval(500)
        self._timer.timeout.connect(self._tick)
        self._timer.start()
        self._layout()

    def _layout(self):
        sr = _screen_rect()
        self.setGeometry(sr.x(), sr.y(), sr.width(), self.height)

    def _tick(self):
        hwnd = w.get_foreground_window()
        title = w.get_title(hwnd) if hwnd else ""
        if title in ("Program Manager", ""):
            title = "桌面"
        from datetime import datetime
        now = datetime.now()
        self.clock_text = now.strftime("%H:%M")
        self.date_text = now.strftime("%Y/%m/%d")
        if title != self.active_title:
            self.active_title = title
        self.update()

    def mouseMoveEvent(self, e):
        h = None
        for name, r in self.buttons.items():
            if r.contains(e.pos()):
                h = name
                break
        if h != self._hover:
            self._hover = h
            self.update()

    def mousePressEvent(self, e):
        for name, r in self.buttons.items():
            if r.contains(e.pos()):
                if name == "overview":
                    self.overview_clicked.emit()
                elif name == "desktop":
                    self.desktop_clicked.emit()
                elif name == "tile":
                    self._tile_menu(r)
                elif name == "menu":
                    self.menu_clicked.emit(e.globalPos())
                return

    def _tile_menu(self, rect):
        m = QMenu(self)
        m.setStyleSheet("""
            QMenu { background:#1b1d24; color:#f2f3f7; border:1px solid #3a3d47;
                     border-radius:8px; padding:6px; font-family:'Microsoft YaHei'; font-size:12px;}
            QMenu::item { padding:6px 18px; border-radius:6px; }
            QMenu::item:selected { background:#0a84ff; }
        """)
        acts = [("全部平铺", "all"), ("左半屏", "left"), ("右半屏", "right"),
                ("上半屏", "top"), ("下半屏", "bottom"),
                ("左上", "tl"), ("右上", "tr"), ("左下", "bl"), ("右下", "br")]
        for label, key in acts:
            a = m.addAction(label)
            a.triggered.connect(lambda _=False, k=key: self.tile_clicked.emit(k))
        m.exec_(self.mapToGlobal(QPoint(rect.center().x(), self.height + 4)))

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = self.rect()
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(Theme.BG))
        p.drawRect(r)
        p.setBrush(QBrush(Theme.BORDER))
        p.drawRect(r.x(), r.bottom() - 1, r.width(), 1)

        p.setFont(_font(12, bold=True))
        p.setPen(QPen(Theme.ACCENT))
        brand = "SeelenLite"
        p.drawText(QRect(14, 0, 110, self.height), Qt.AlignVCenter | Qt.AlignLeft, brand)
        bw = QFontMetrics(_font(12, bold=True)).horizontalAdvance(brand)
        p.setPen(QPen(Theme.TEXT_DIM))
        p.setFont(_font(12, cn=True))
        title = self.active_title or "桌面"
        fm = QFontMetrics(_font(12, cn=True))
        title = fm.elidedText(title, Qt.ElideRight, 520)
        p.drawText(QRect(14 + bw + 18, 0, 520, self.height), Qt.AlignVCenter | Qt.AlignLeft, title)

        # 右侧
        p.setFont(_font(11, cn=True))
        fm2 = QFontMetrics(_font(11, cn=True))
        clock = self.clock_text
        date = self.date_text
        cw = fm2.horizontalAdvance(clock)
        dw = fm2.horizontalAdvance(date)
        self.buttons = {}
        x = r.width() - 14
        for label, key in (("菜单", "menu"), ("平铺", "tile"), ("总览", "overview"), ("桌面", "desktop")):
            lw = fm2.horizontalAdvance(label) + 22
            x -= lw
            rect = QRect(x, 3, lw, self.height - 6)
            self.buttons[key] = rect
            hover = (self._hover == key)
            p.setBrush(QBrush(Theme.CARD_HOVER if hover else QColor(255, 255, 255, 8)))
            _round(p, rect, 7)
            p.setPen(QPen(Theme.TEXT))
            p.drawText(rect, Qt.AlignCenter, label)
            x -= 8
        x -= 10
        p.setPen(QPen(Theme.TEXT))
        p.drawText(QRect(x - cw, 0, cw, self.height), Qt.AlignVCenter | Qt.AlignRight, clock)
        x -= cw + 10
        p.setPen(QPen(Theme.TEXT_DIM))
        p.drawText(QRect(x - dw, 0, dw, self.height), Qt.AlignVCenter | Qt.AlignRight, date)
        p.end()


# ================================================================== 窗口总览
class Overview(QWidget):
    """Mission Control 风格总览：缩略图网格，单击聚焦，双击全屏/还原。"""

    closed = pyqtSignal()
    opened = pyqtSignal()

    def __init__(self, wm, settings, parent=None):
        super().__init__(parent)
        self.wm = wm
        self.settings = settings
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setMouseTracking(True)
        self.cards = []       # [{'info','rect','thumb','title','icon'}]
        self._hover = -1
        self._close_rect = QRect()
        self._desk_rect = QRect()

    def open(self):
        sr = _screen_rect()
        self.setGeometry(sr)
        try:
            self.wm.refresh()
        except Exception:
            pass
        self._build()
        self.show()
        self.opened.emit()
        self.raise_()
        self.activateWindow()
        self.setFocus(Qt.OtherFocusReason)
        self.update()

    def close_overview(self):
        self.hide()
        self.closed.emit()

    def _build(self):
        sr = _screen_rect()
        items = list(self.wm.windows)
        self.cards = []
        if not items:
            return
        n = len(items)
        cols = max(1, int(math.ceil(math.sqrt(n * (sr.width() / float(sr.height()))))))
        rows = int(math.ceil(n / float(cols)))
        pad = 18
        top = 70
        bottom = 30
        grid_w = sr.width() - pad * 2
        grid_h = sr.height() - top - bottom
        cw = grid_w // cols
        ch = grid_h // rows
        thumb_w = min(cw - 24, 300)
        thumb_h = int(thumb_w * 9.0 / 16.0)
        for idx, info in enumerate(items):
            r, c = divmod(idx, cols)
            cell_x = pad + c * cw
            cell_y = top + r * ch
            tr = QRect(cell_x + (cw - thumb_w) // 2, cell_y + (ch - thumb_h - 18) // 2,
                       thumb_w, thumb_h)
            thumb = None
            try:
                img = w.capture_window(info.hwnd, thumb_w)
                if img is not None and not img.isNull():
                    thumb = img.scaled(thumb_w, thumb_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            except Exception:
                thumb = None
            self.cards.append({"info": info, "rect": tr, "thumb": thumb,
                               "title": info.title, "icon": info.icon})
        self._close_rect = QRect(sr.width() - 130, 18, 110, 30)
        self._desk_rect = QRect(sr.width() - 250, 18, 110, 30)

    def mouseMoveEvent(self, e):
        h = -1
        for i, c in enumerate(self.cards):
            if c["rect"].contains(e.pos()):
                h = i
                break
        if h != self._hover:
            self._hover = h
            self.update()

    def mousePressEvent(self, e):
        if self._close_rect.contains(e.pos()):
            self.close_overview()
            return
        if self._desk_rect.contains(e.pos()):
            self.wm.show_desktop()
            self.close_overview()
            return
        for c in self.cards:
            if c["rect"].contains(e.pos()):
                self.wm.focus(c["info"])
                self.close_overview()
                return
        # 点击空白处关闭
        self.close_overview()

    def mouseDoubleClickEvent(self, e):
        for c in self.cards:
            if c["rect"].contains(e.pos()):
                self.wm.toggle_max(c["info"])
                self.close_overview()
                return

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key_Escape, Qt.Key_Return, Qt.Key_Enter):
            self.close_overview()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.fillRect(self.rect(), Theme.OVERLAY)

        p.setPen(QPen(Theme.TEXT))
        p.setFont(_font(20, bold=True))
        p.drawText(QRect(24, 44, 300, 34), Qt.AlignVCenter | Qt.AlignLeft, "窗口总览")

        for label, rect in (("显示桌面", self._desk_rect), ("关闭", self._close_rect)):
            p.setBrush(QBrush(Theme.CARD_HOVER))
            p.setPen(QPen(Theme.BORDER, 1))
            _round(p, rect, 9)
            p.setPen(QPen(Theme.TEXT))
            p.setFont(_font(12, cn=True))
            p.drawText(rect, Qt.AlignCenter, label)

        p.setFont(_font(12, cn=True))
        fm = QFontMetrics(_font(12, cn=True))
        for i, c in enumerate(self.cards):
            rect = c["rect"]
            hover = (i == self._hover)
            p.setBrush(QBrush(Theme.CARD_HOVER if hover else Theme.CARD))
            p.setPen(QPen(Theme.ACCENT if hover else Theme.BORDER, 1))
            _round(p, rect, 12)
            if c["thumb"] is not None:
                p.drawImage(rect, c["thumb"])
            else:
                ic = c["icon"].pixmap(64, 64) if c["icon"] and not c["icon"].isNull() else QPixmap(64, 64)
                p.drawPixmap(rect.x() + (rect.width() - 64) // 2,
                             rect.y() + (rect.height() - 64) // 2, ic)
            label = fm.elidedText(c["title"], Qt.ElideRight, rect.width())
            p.setPen(QPen(Theme.TEXT if hover else Theme.TEXT_DIM))
            p.drawText(QRect(rect.x(), rect.bottom() + 4, rect.width(), 22),
                       Qt.AlignHCenter | Qt.AlignTop, label)
        p.end()


# ================================================================== 设置
DLG_QSS = """
QDialog { background:#14161c; }
QLabel { color:#e9ebf1; font-family:'Microsoft YaHei'; font-size:12px; }
QLabel#sec { color:#8b93a3; font-size:11px; font-weight:bold; }
QLabel#hint { color:#98a0ae; font-size:11px; }
QLabel#val { color:#0a84ff; font-size:12px; font-weight:bold; }
QCheckBox { color:#e9ebf1; font-family:'Microsoft YaHei'; font-size:12px; spacing:8px; }
QCheckBox::indicator { width:16px; height:16px; border-radius:4px;
                       border:1px solid #4a4f5c; background:#1e2129; }
QCheckBox::indicator:checked { background:#0a84ff; border-color:#0a84ff; }
QComboBox { background:#1e2129; color:#e9ebf1; border:1px solid #3a3d47;
            border-radius:6px; padding:3px 8px; min-height:22px;
            font-family:'Microsoft YaHei'; font-size:12px; }
QComboBox QAbstractItemView { background:#1e2129; color:#e9ebf1;
            selection-background-color:#0a84ff; border:1px solid #3a3d47; }
QSlider::groove:horizontal { height:4px; background:#2c303a; border-radius:2px; }
QSlider::handle:horizontal { width:14px; height:14px; margin:-5px 0;
            border-radius:7px; background:#0a84ff; }
QPushButton { background:#23262e; color:#e9ebf1; border:1px solid #3a3d47;
            border-radius:7px; padding:6px 16px; font-family:'Microsoft YaHei'; font-size:12px; }
QPushButton:hover { background:#2c303a; }
QPushButton#primary { background:#0a84ff; border-color:#0a84ff; color:#ffffff; }
QPushButton#primary:hover { background:#2f93ff; }
QFrame#line { background:#2a2e37; max-height:1px; }
"""


class SettingsDialog(QDialog):
    """深色设置面板：放大幅度、卡片大小、界面显隐、交互开关。"""

    applied = pyqtSignal()

    def __init__(self, settings, wm, cards, parent=None):
        super().__init__(parent)
        from PyQt5.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QCheckBox,
                                     QComboBox, QSlider, QPushButton, QFrame)
        self.settings = settings
        self.wm = wm
        self.cards = cards
        self.setWindowTitle("SeelenLite 设置")
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setStyleSheet(DLG_QSS)
        self.setFixedWidth(470)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 18, 20, 16)
        lay.setSpacing(10)

        def section(text):
            lb = QLabel(text)
            lb.setObjectName("sec")
            lay.addWidget(lb)

        def line():
            f = QFrame()
            f.setObjectName("line")
            lay.addWidget(f)

        def hint(text):
            lb = QLabel(text)
            lb.setObjectName("hint")
            lb.setWordWrap(True)
            lay.addWidget(lb)

        # ---- 窗口放大 ----
        section("窗口放大")
        row = QHBoxLayout()
        row.addWidget(QLabel("放大到"))
        self.cmb_preset = QComboBox()
        for label, key in (("半屏（推荐）", "half"), ("整屏", "full"),
                           ("3/4 屏", "wide"), ("自定义比例", "custom")):
            self.cmb_preset.addItem(label, key)
        i = self.cmb_preset.findData(settings.expand_preset)
        self.cmb_preset.setCurrentIndex(i if i >= 0 else 0)
        self.cmb_preset.currentIndexChanged.connect(self._on_preset)
        row.addWidget(self.cmb_preset, 1)
        lay.addLayout(row)

        self.row_custom = QWidget()
        rowc = QHBoxLayout(self.row_custom)
        rowc.setContentsMargins(0, 0, 0, 0)
        rowc.addWidget(QLabel("自定义宽度"))
        self.sld_ratio = QSlider(Qt.Horizontal)
        self.sld_ratio.setRange(40, 100)
        self.sld_ratio.setValue(int(round(settings.expand_ratio * 100)))
        self.sld_ratio.valueChanged.connect(self._on_ratio)
        rowc.addWidget(self.sld_ratio, 1)
        self.lbl_ratio = QLabel("%d%%" % self.sld_ratio.value())
        self.lbl_ratio.setObjectName("val")
        rowc.addWidget(self.lbl_ratio)
        lay.addWidget(self.row_custom)
        self.row_custom.setVisible(settings.expand_preset == "custom")

        self.chk_remember = QCheckBox("记住每个应用拖过的尺寸（下次展开用它）")
        self.chk_remember.setChecked(settings.expand_remember)
        self.chk_remember.toggled.connect(self._apply)
        lay.addWidget(self.chk_remember)
        hint("放大时保持窗口原来的长宽比，并保证不小于可读尺寸，所以内容不会被压扁挤成一团。"
             "展开后自己拖窗口边缘调大小，位置和尺寸会被记住。")
        line()

        # ---- 卡片 ----
        section("桌面卡片")
        row = QHBoxLayout()
        row.addWidget(QLabel("卡片大小"))
        self.sld_card = QSlider(Qt.Horizontal)
        self.sld_card.setRange(15, 45)
        self.sld_card.setValue(int(round(settings.card_scale * 100)))
        self.sld_card.valueChanged.connect(self._on_card)
        row.addWidget(self.sld_card, 1)
        self.lbl_card = QLabel("%d%%" % self.sld_card.value())
        self.lbl_card.setObjectName("val")
        row.addWidget(self.lbl_card)
        lay.addLayout(row)
        hint("卡片是窗口画面的等比缩小版（DWM 缩略图），文字和内容一起变小，布局不变。")
        self.chk_hover = QCheckBox("鼠标悬停时平滑放大卡片（移开自动复原）")
        self.chk_hover.setChecked(getattr(settings, "card_hover", True))
        self.chk_hover.toggled.connect(self._apply)
        lay.addWidget(self.chk_hover)
        self.chk_raise = QCheckBox("鼠标悬停到窗口上时自动置于最前（不抢焦点）")
        self.chk_raise.setChecked(getattr(settings, "hover_raise", True))
        self.chk_raise.toggled.connect(self._apply)
        lay.addWidget(self.chk_raise)
        self.chk_anim = QCheckBox("缩小 / 放大时播放缩放动画")
        self.chk_anim.setChecked(getattr(settings, "card_anim", True))
        self.chk_anim.toggled.connect(self._apply)
        lay.addWidget(self.chk_anim)
        hint("卡片的位置、大小和缩放状态会保存下来，重启后自动回到原样；退出程序时会把所有窗口还原到桌面。")
        line()

        # ---- 界面 ----
        section("界面")
        self.chk_compact = QCheckBox("精简模式（只显示底部程序坞，隐藏顶栏）")
        self.chk_compact.setChecked(settings.compact)
        self.chk_compact.toggled.connect(self._on_compact)
        lay.addWidget(self.chk_compact)
        self.chk_topbar = QCheckBox("显示顶部状态栏")
        self.chk_topbar.setChecked(settings.show_topbar)
        self.chk_topbar.setEnabled(not settings.compact)
        self.chk_topbar.toggled.connect(self._apply)
        lay.addWidget(self.chk_topbar)
        self.chk_dock = QCheckBox("显示底部程序坞")
        self.chk_dock.setChecked(settings.show_dock)
        self.chk_dock.toggled.connect(self._apply)
        lay.addWidget(self.chk_dock)
        line()

        # ---- 交互 ----
        section("交互")
        self.chk_click = QCheckBox("单击窗口时放大（默认关闭，会改写窗口尺寸）")
        self.chk_click.setChecked(settings.click_max)
        self.chk_click.toggled.connect(self._apply)
        lay.addWidget(self.chk_click)

        row = QHBoxLayout()
        row.addSpacing(24)
        row.addWidget(QLabel("放大范围"))
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItem("仅非活动窗口（推荐）", "inactive")
        self.cmb_mode.addItem("任意位置", "any")
        j = self.cmb_mode.findData(settings.click_max_mode)
        self.cmb_mode.setCurrentIndex(j if j >= 0 else 0)
        self.cmb_mode.currentIndexChanged.connect(self._apply)
        row.addWidget(self.cmb_mode, 1)
        lay.addLayout(row)
        hint("这一项会改写窗口尺寸，和拖动窗口边缘改大小互相覆盖，建议保持关闭。"
             "放大窗口请用「单击卡片」或「双击标题栏」。")

        self.chk_title = QCheckBox("双击标题栏缩成卡片")
        self.chk_title.setChecked(settings.title_restore)
        self.chk_title.toggled.connect(self._apply)
        lay.addWidget(self.chk_title)
        self.chk_esc = QCheckBox("按 ESC 把当前窗口缩回卡片")
        self.chk_esc.setChecked(settings.esc_restore)
        self.chk_esc.toggled.connect(self._apply)
        lay.addWidget(self.chk_esc)
        self.chk_right = QCheckBox("右键点放大窗口缩回卡片（等同 ESC）")
        self.chk_right.setChecked(settings.right_restore)
        self.chk_right.toggled.connect(self._apply)
        lay.addWidget(self.chk_right)
        hint("右键手势只接管被放大的窗口；其它窗口、卡片和标题栏的右键菜单照常使用。")

        # ---- 底部按钮 ----
        row = QHBoxLayout()
        btn_clear = QPushButton("清除已记住的尺寸")
        btn_clear.clicked.connect(self._clear_sizes)
        row.addWidget(btn_clear)
        row.addStretch(1)
        btn_ok = QPushButton("完成")
        btn_ok.setObjectName("primary")
        btn_ok.clicked.connect(self.accept)
        row.addWidget(btn_ok)
        lay.addLayout(row)

        self.adjustSize()

    # ---- 事件 ----
    def _on_compact(self, checked):
        self.chk_topbar.setEnabled(not checked)
        self._apply()

    def _on_preset(self):
        custom = self.cmb_preset.currentData() == "custom"
        self.row_custom.setVisible(custom)
        self.adjustSize()
        self._apply()

    def _on_ratio(self, v):
        self.lbl_ratio.setText("%d%%" % v)
        self._apply()

    def _on_card(self, v):
        self.lbl_card.setText("%d%%" % v)
        self._apply()

    def _clear_sizes(self):
        self.settings.clear_sizes()
        self.settings.clear_window_states()
        if self.cards is not None:
            self.cards._watch.clear()
            self.cards._restored_keys.clear()

    def _apply(self):
        s = self.settings
        s.expand_preset = self.cmb_preset.currentData()
        s.expand_ratio = self.sld_ratio.value() / 100.0
        s.expand_remember = self.chk_remember.isChecked()
        s.card_scale = self.sld_card.value() / 100.0
        s.compact = self.chk_compact.isChecked()
        s.show_topbar = self.chk_topbar.isChecked()
        s.show_dock = self.chk_dock.isChecked()
        s.click_max = self.chk_click.isChecked()
        s.click_max_mode = self.cmb_mode.currentData()
        s.title_restore = self.chk_title.isChecked()
        s.esc_restore = self.chk_esc.isChecked()
        s.right_restore = self.chk_right.isChecked()
        s.card_hover = self.chk_hover.isChecked()
        s.card_anim = self.chk_anim.isChecked()
        s.hover_raise = self.chk_raise.isChecked()
        # 已存在的卡片立即跟随开关，不用等下次重建
        if self.cards is not None:
            for cw in self.cards.card_widgets():
                try:
                    cw._anim_enabled = s.card_anim
                    cw.set_hover_enabled(s.card_hover)
                except Exception:
                    pass
        s.save()
        self.applied.emit()


# ================================================================== 托盘
def make_tray_icon():
    pm = QPixmap(64, 64)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setBrush(QBrush(Theme.ACCENT))
    p.setPen(Qt.NoPen)
    _round(p, QRectF(4, 4, 56, 56), 16)
    p.setPen(QPen(QColor(255, 255, 255)))
    p.setFont(_font(30, bold=True))
    p.drawText(pm.rect(), Qt.AlignCenter, "S")
    p.end()
    return QIcon(pm)


class Tray(QSystemTrayIcon):
    overview_requested = pyqtSignal()
    restore_cards_requested = pyqtSignal()
    settings_requested = pyqtSignal()
    quit_requested = pyqtSignal()

    def __init__(self, app, wm, settings, parent=None):
        super().__init__(parent)
        self.app = app
        self.wm = wm
        self.settings = settings
        self.setIcon(make_tray_icon())
        self.setToolTip("SeelenLite")
        self.menu = QMenu()
        self.menu.setStyleSheet("""
            QMenu { background:#1b1d24; color:#f2f3f7; border:1px solid #3a3d47;
                     border-radius:8px; padding:6px; font-family:'Microsoft YaHei'; font-size:12px;}
            QMenu::item { padding:6px 18px; border-radius:6px; }
            QMenu::item:selected { background:#0a84ff; }
            QMenu::separator { height:1px; background:#3a3d47; margin:5px 8px; }
        """)
        self._build()
        self.setContextMenu(self.menu)
        self.activated.connect(self._on_activated)

    def rebuild(self):
        self._build()

    def _build(self):
        m = self.menu
        m.clear()
        a = m.addAction("设置…")
        a.triggered.connect(self.settings_requested.emit)
        m.addSeparator()
        a = m.addAction("窗口总览")
        a.triggered.connect(self._sig_overview)
        a = m.addAction("显示桌面")
        a.triggered.connect(self.wm.show_desktop)
        a = m.addAction("展开所有卡片")
        a.triggered.connect(self.restore_cards_requested.emit)
        m.addSeparator()
        self._dock_act = m.addAction("隐藏程序坞" if self.settings.show_dock else "显示程序坞")
        self._dock_act.triggered.connect(self._toggle_dock)
        self._bar_act = m.addAction("隐藏顶栏" if self.settings.show_topbar else "显示顶栏")
        self._bar_act.triggered.connect(self._toggle_bar)
        m.addSeparator()
        self._cm_act = m.addAction("单击窗口放大：%s" % ("开" if self.settings.click_max else "关"))
        self._cm_act.triggered.connect(self._toggle_click_max)
        self._cm_mode = m.addAction("放大范围：%s" % ("任意位置" if self.settings.click_max_mode == "any" else "仅非活动窗口"))
        self._cm_mode.triggered.connect(self._toggle_click_mode)
        self._tr_act = m.addAction("双击标题栏缩成卡片：%s" % ("开" if self.settings.title_restore else "关"))
        self._tr_act.triggered.connect(self._toggle_title_restore)
        self._esc_act = m.addAction("ESC 缩回卡片：%s" % ("开" if self.settings.esc_restore else "关"))
        self._esc_act.triggered.connect(self._toggle_esc_restore)
        self._as_act = m.addAction("开机自启：开" if self.settings.autostart else "开机自启：关")
        self._as_act.triggered.connect(self._toggle_as)
        m.addSeparator()
        a = m.addAction("关于 SeelenLite")
        a.triggered.connect(self._about)
        a = m.addAction("退出")
        a.triggered.connect(self._quit)

    def _sig_overview(self):
        self.overview_requested.emit()

    def _toggle_dock(self):
        self.settings.show_dock = not self.settings.show_dock
        self.settings.save()
        self._build()
        try:
            self.app._apply_settings()
        except Exception:
            pass

    def _toggle_bar(self):
        self.settings.show_topbar = not self.settings.show_topbar
        if self.settings.show_topbar:
            self.settings.compact = False
        self.settings.save()
        self._build()
        try:
            self.app._apply_settings()
        except Exception:
            pass

    def _toggle_click_max(self):
        self.settings.click_max = not self.settings.click_max
        self.settings.save()
        self._build()

    def _toggle_click_mode(self):
        self.settings.click_max_mode = "inactive" if self.settings.click_max_mode == "any" else "any"
        self.settings.save()
        self._build()

    def _toggle_title_restore(self):
        self.settings.title_restore = not self.settings.title_restore
        self.settings.save()
        self._build()

    def _toggle_esc_restore(self):
        self.settings.esc_restore = not self.settings.esc_restore
        self.settings.save()
        self._build()

    def _toggle_as(self):
        self.settings.autostart = not self.settings.autostart
        set_autostart(self.settings.autostart)
        self.settings.save()
        self._build()

    def _about(self):
        from PyQt5.QtWidgets import QMessageBox
        QMessageBox.information(None, "关于 SeelenLite",
                                "SeelenLite %s\n轻量窗口卡片工具。\n\n"
                                "· 双击窗口标题栏：窗口整体缩成桌面卡片（内容等比缩小）\n"
                                "· 单击卡片：放大到设置里的尺寸（默认半屏，不强制全屏）\n"
                                "· 卡片标题栏 ×：关闭窗口；⤢：放大\n"
                                "· 按 ESC：把当前窗口缩回卡片\n"
                                "· 展开后自己拖窗口边缘，尺寸会被记住\n"
                                "· 拖动卡片摆放位置，拖右下角调整卡片大小" % APP_VERSION_S)

    def _quit(self):
        # 先走统一退出流程（还原所有窗口、停钩子），再兜底 quit
        self.quit_requested.emit()
        QApplication.quit()

    def _on_activated(self, reason):
        if reason == QSystemTrayIcon.DoubleClick:
            self._sig_overview()
