# -*- coding: utf-8 -*-
"""
SeelenLite - main.py
入口：装配窗口管理器、程序坞、顶栏、总览与托盘。
"""
import ctypes
import os
import sys
import time

os.environ.setdefault("QT_AUTO_SCREEN_SCALE_FACTOR", "0")

# 打包成 --noconsole 时 sys.stdout/stderr 是 None，任何 print 都会抛异常。
# 设了 SELENLITE_LOG 就写日志文件，否则丢进空设备。
if sys.stdout is None or sys.stderr is None:
    _log_path = os.environ.get("SELENLITE_LOG")
    try:
        _out = open(_log_path, "w", encoding="utf-8", buffering=1) if _log_path \
            else open(os.devnull, "w", encoding="utf-8", buffering=1)
    except Exception:
        _out = open(os.devnull, "w", encoding="utf-8")
    if sys.stdout is None:
        sys.stdout = _out
    if sys.stderr is None:
        sys.stderr = _out

from PyQt5.QtWidgets import QApplication, QMessageBox
from PyQt5.QtCore import Qt, QTimer, QRect

import win32api as w
from core import (Settings, WindowManager, ClickHook, KeyboardHook, ForegroundHook,
                  HoverRaise, APP_NAME, APP_VERSION)
from ui import Dock, TopBar, Overview, Tray
from cards import CardManager


def _single_instance():
    """用互斥量保证只运行一份。"""
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.CreateMutexW.restype = ctypes.c_void_p
    k.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
    k.GetLastError.restype = ctypes.c_uint32
    handle = k.CreateMutexW(None, False, "SeelenLite_SingleInstance_v1")
    return k.GetLastError() == 183  # ERROR_ALREADY_EXISTS


class App(QApplication):
    def __init__(self, argv):
        super().__init__(argv)
        self.setQuitOnLastWindowClosed(False)
        self.setApplicationName(APP_NAME)
        self.setApplicationVersion(APP_VERSION)

        self.settings = Settings()
        self.wm = WindowManager(self)

        if "--bare" in sys.argv:
            return

        self.dock = Dock(self.wm, self.settings)
        self.topbar = TopBar(self.wm, self.settings)
        self.overview = Overview(self.wm, self.settings)
        self.cards = CardManager(self.wm, self.settings, self)
        self.cards.auto_restore = "--demo" not in sys.argv
        self.wm.cards = self.cards
        self._card_timer = QTimer(self)
        self._card_timer.setInterval(1000)
        self._card_timer.timeout.connect(self.cards.tick)
        self._card_timer.start()

        # 记录自身窗口，避免被当成普通窗口管理
        self.wm.own_hwnds = {int(self.dock.winId()), int(self.topbar.winId()),
                             int(self.overview.winId())}

        if "--no-tray" not in sys.argv:
            self.tray = Tray(self, self.wm, self.settings)
            self.tray.show()
        else:
            self.tray = None

        self.hook = ClickHook(self)
        self.hook.single_click.connect(self._on_single_click)
        self.hook.double_click.connect(self._on_double_click)
        self.hook.right_target = self._right_target
        self.hook.right_click.connect(self._on_right_click)
        self.kb = KeyboardHook(self)
        self.kb.escape_pressed.connect(self._on_escape)
        self.fgh = ForegroundHook(self)
        self.fgh.activated.connect(self._on_foreground)
        self.hover = HoverRaise(self.wm, self.settings, self)
        self.hover.enabled = "--no-hook" not in sys.argv
        # ESC 常驻监听：总览开着就关总览，否则把最大化/全屏窗口缩回卡片
        self.overview.opened.connect(self.kb.start)

        # ---- 信号接线 ----
        self.topbar.overview_clicked.connect(self.toggle_overview)
        self.topbar.desktop_clicked.connect(self.wm.show_desktop)
        self.topbar.tile_clicked.connect(self._on_tile)
        self.dock.settings_requested.connect(self.open_settings)
        self.dock.overview_requested.connect(self.toggle_overview)
        self.dock.restore_cards_requested.connect(self.cards.restore_all)
        self.dock.quit_requested.connect(self.shutdown)
        if self.tray is not None:
            self.tray.overview_requested.connect(self.toggle_overview)
            self.tray.restore_cards_requested.connect(self.cards.restore_all)
            self.tray.settings_requested.connect(self.open_settings)
            self.tray.quit_requested.connect(self.shutdown)

        if "--no-show" not in sys.argv:
            if self.settings.show_dock:
                self.dock.show()
                self.dock.refresh()
            # 精简模式：只在底部程序坞留入口，不显示顶部状态栏
            if self.settings.show_topbar and not self.settings.compact:
                self.topbar.show()

        # 单击放大 / 双击缩回 / 右键缩回 / ESC 缩回都走全局钩子，统一常驻
        if "--no-hook" not in sys.argv:
            self.hook.start()
            self.kb.start()
            self.fgh.start()
        if self.hover.enabled:
            self.hover.start()

        self.wm.refresh()
        # 上次被异常结束后留在屏幕外的窗口，启动时拉回来
        QTimer.singleShot(700, self._recover_offscreen)
        # 按上次记下的状态恢复：卡片态重建卡片、放大态回放大位置、普通态回普通位置。
        # 跑两次：有些应用（浏览器、Electron）启动慢，窗口晚几秒才出现。
        QTimer.singleShot(1500, self._restore_states)
        QTimer.singleShot(5000, self._restore_states)

    # ---------------- 行为 ----------------
    def _recover_offscreen(self):
        try:
            n = self.cards.recover_offscreen()
            if n and "--demo" in sys.argv:
                print("RECOVERED", n, flush=True)
        except Exception:
            pass

    def _restore_states(self):
        """按持久化的窗口状态恢复。演示模式跳过，避免干扰自测。"""
        if "--demo" in sys.argv:
            return
        try:
            n = self.cards.restore_window_states()
            if n:
                print("STATES_RESTORED", n, flush=True)
        except Exception:
            pass
    def _on_foreground(self, hwnd):
        """有窗口被激活：卡片化的窗口被切回前台时自动展开。"""
        try:
            self.cards.on_activated(hwnd)
        except Exception:
            pass

    def _right_target(self, hwnd):
        """右键钩子同步判定：这次右键要不要接管成「缩回卡片」。

        这个函数在低级鼠标钩子回调里同步执行，必须极轻：
        只做几次集合/标志查询，绝不调用 GetWindowRect、显示器查询这类
        可能阻塞的 API，否则整台机器的鼠标输入都会被拖慢直到卡死。
        """
        try:
            if not self.settings.right_restore:
                return False
            h = int(hwnd or 0)
            if not h or h in self.wm.own_hwnds or self.cards.is_card(h):
                return False
            return h in self.cards.expanded or bool(w.is_zoomed(h))
        except Exception:
            return False

    def _on_right_click(self, x, y, hwnd):
        """右键点放大窗口 -> 缩回桌面卡片（与 ESC 同一动作）。"""
        try:
            if self.overview.isVisible():
                self.overview.close_overview()
                return
            if not self.settings.right_restore:
                return
            h = int(hwnd or 0)
            if not h or self.cards.is_card(h):
                return
            if not (self.cards.is_expanded(h) or w.is_zoomed(h)):
                return
            if self.cards.cardify(h):
                if "--demo" in sys.argv:
                    print("RIGHT_CARDIFY", h, w.get_rect(h), flush=True)
                self.status_message("已缩回卡片")
        except Exception:
            pass

    def _on_escape(self):
        """ESC：关总览，或把当前最大化/全屏的窗口缩回卡片。"""
        try:
            if self.overview.isVisible():
                self.overview.close_overview()
                return
            if not self.settings.esc_restore:
                return
            hwnd = w.get_foreground_window()
            if not hwnd or self.cards.is_card(hwnd):
                return
            # 只处理「最大化」或「我们刚放大摆出来的」窗口，避免抢走普通程序的 ESC
            if not (w.is_zoomed(hwnd) or self.cards.is_expanded(hwnd)):
                return
            if self.cards.cardify(hwnd):
                if "--demo" in sys.argv:
                    print("ESC_CARDIFY", hwnd, flush=True)
                self.status_message("已缩回卡片")
        except Exception:
            pass

    def shutdown_hooks(self):
        for h in (getattr(self, "hook", None), getattr(self, "kb", None),
                  getattr(self, "fgh", None), getattr(self, "hover", None)):
            if h is None:
                continue
            try:
                h.stop()
            except Exception:
                pass
        # 兜底：不管从哪条路径退出，都不能把用户的窗口留在屏幕外或卡片态。
        # 先把当前几何全部落盘，再做同步还原（persist=False：还原动作本身
        # 不能反过来覆盖刚存好的状态）。
        try:
            cards = getattr(self, "cards", None)
            if cards is not None:
                cards.flush_states()
                cards.restore_all(animate=False, persist=False)
        except Exception:
            pass

    def toggle_overview(self):
        if self.overview.isVisible():
            self.overview.close_overview()
        else:
            self.overview.open()

    def _on_tile(self, key):
        if key == "all":
            self.wm.tile_all()
            return
        hwnd = w.get_foreground_window()
        info = self.wm.by_hwnd(hwnd)
        if info is None:
            self.wm.refresh()
            info = self.wm.by_hwnd(hwnd)
        if info is not None:
            self.wm.snap(info, key)

    def _on_single_click(self, x, y, fg_before, hwnd):
        """单击窗口任意位置 -> 把这个窗口最大化（内容跟着一起放大）。"""
        try:
            self._single_click_impl(x, y, fg_before, hwnd)
        except Exception:
            # 钩子回调里的异常绝不能让整个程序挂掉
            pass

    def _single_click_impl(self, x, y, fg_before, hwnd):
        if not self.settings.click_max:
            return
        if not hwnd:
            return
        # 已经由我们放大过的窗口：尺寸归用户管，绝不再自动改。
        # 否则用户拖完边缘改大小，下一次点击又被改回「展开尺寸」。
        if hwnd in self.cards.expanded:
            return
        info = self.wm.by_hwnd(hwnd)
        if info is None:
            self.wm.refresh()
            info = self.wm.by_hwnd(hwnd)
        if info is None:
            return
        # 已经是最大化的窗口不再处理，保证窗口内部的点击不受影响
        if self.wm.is_maximized(hwnd):
            return
        # 「只放大非活动窗口」模式：点当前正在用的窗口，不打扰它
        if self.settings.click_max_mode == "inactive" and fg_before == hwnd:
            return
        # 按设置里的尺寸放大（默认半屏，不强制全屏），并保持窗口原来的长宽比
        rect = self.cards.expand_rect(hwnd, {"exe": info.exe, "rect": info.rect})
        try:
            cur = w.get_rect(hwnd)
            if all(abs(int(cur[i]) - int(rect[i])) <= 3 for i in range(4)):
                return      # 已经是这个尺寸了，点一下不该有任何变化
        except Exception:
            pass
        w.set_pos(hwnd, w.HWND_TOP, rect[0], rect[1], rect[2], rect[3],
                  w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
        # 登记为「我们放大的窗口」，这样右键 / ESC 都能把它缩回卡片
        self.cards.expanded.add(int(hwnd))
        try:
            if info.exe:
                self.settings.remember_window(info.exe, list(rect), "expanded")
        except Exception:
            pass
        if "--demo" in sys.argv:
            print("SINGLE_CLICK", x, y, hwnd, w.get_rect(hwnd), flush=True)


    def _on_double_click(self, x, y, hwnd):
        """双击窗口标题栏 -> 把窗口整体缩成桌面卡片（内容等比缩小）。"""
        try:
            if os.environ.get("SELENLITE_DEBUG"):
                print("DBL_EVENT", x, y, hwnd, flush=True)
            self._double_click_impl(x, y, hwnd)
        except Exception:
            pass

    def _double_click_impl(self, x, y, hwnd):
        if not self.settings.title_restore:
            return
        if not hwnd or self.cards.is_card(hwnd):
            return
        # 只处理我们识别到的应用窗口，任务栏/桌面之类直接忽略
        if self.wm.by_hwnd(hwnd) is None:
            self.wm.refresh()
        if self.wm.by_hwnd(hwnd) is None:
            if os.environ.get("SELENLITE_DEBUG"):
                print("DBL_SKIP_NOT_MANAGED", hwnd, flush=True)
            return
        if os.environ.get("SELENLITE_DEBUG"):
            print("TITLE_DBL", x, y, hwnd, "zoomed", w.is_zoomed(hwnd), flush=True)
        if self.cards.cardify(hwnd):
            self.status_message("已缩成卡片")

    def status_message(self, text):
        try:
            self.tray.showMessage(APP_NAME, text, 1200)
        except Exception:
            pass

    def open_settings(self):
        from ui import SettingsDialog
        try:
            dlg = SettingsDialog(self.settings, self.wm, self.cards)
            dlg.applied.connect(self._apply_settings)
            dlg.exec_()
            self._apply_settings()
        except Exception:
            pass

    def _apply_settings(self):
        """设置改动后立即生效（顶栏显隐、程序坞等）。"""
        try:
            if self.settings.show_dock:
                self.dock.show()
                self.dock.refresh()
            else:
                self.dock.hide()
        except Exception:
            pass
        try:
            if self.settings.show_topbar and not self.settings.compact:
                self.topbar.show()
            else:
                self.topbar.hide()
        except Exception:
            pass
        try:
            if self.tray is not None:
                self.tray.rebuild()
        except Exception:
            pass

    def shutdown(self):
        for h in (self.hook, self.kb, self.fgh, self.hover):
            try:
                h.stop()
            except Exception:
                pass
        # 退出前先把状态落盘，再把所有卡片展开回桌面，绝不把用户的窗口留在屏幕外
        try:
            self.cards.flush_states()
            self.cards.restore_all(persist=False)
        except Exception:
            pass
        try:
            self.wm.restore_any()
        except Exception:
            pass
        try:
            self.tray.hide()
        except Exception:
            pass
        QApplication.quit()


def _install_excepthook():
    """槽函数里的未捕获异常不能带走整个程序。

    pythonw / 打包后的 exe 没有控制台，默认的异常输出可能直接让进程退出
    （表现为「双击后闪退、日志里什么都没有」）。这里统一改成写日志。
    """
    def _hook(t, v, tb):
        try:
            import traceback
            msg = "".join(traceback.format_exception(t, v, tb))
            p = os.environ.get("SELENLITE_LOG")
            if p:
                with open(p, "a", encoding="utf-8") as f:
                    f.write(msg + "\n")
            elif os.environ.get("SELENLITE_DEBUG"):
                sys.stderr.write(msg)
                sys.stderr.flush()
        except Exception:
            pass
    sys.excepthook = _hook


def main():
    _install_excepthook()
    # 让 Win32 坐标与 Qt 坐标一致（100% 缩放下完全对齐）
    try:
        w.user32.SetProcessDPIAware()
    except Exception:
        pass

    # --force：允许在已有实例运行时再起一份（自测用，正常启动不受影响）
    if _single_instance() and "--force" not in sys.argv:
        print("SeelenLite 已在运行", flush=True)
        return 0

    app = App(sys.argv)


    # 自测模式：--shot [秒] —— 启动后截图保存并退出，用于无头验证
    if "--shot" in sys.argv:
        idx = sys.argv.index("--shot")
        wait = 3.0
        if len(sys.argv) > idx + 1:
            try:
                wait = float(sys.argv[idx + 1])
            except Exception:
                pass
        out = "_shot.png"
        if "--out" in sys.argv:
            oi = sys.argv.index("--out")
            if len(sys.argv) > oi + 1:
                out = sys.argv[oi + 1]
        elif os.environ.get("SELENLITE_SHOT_OUT"):
            out = os.environ["SELENLITE_SHOT_OUT"]
        else:
            # onefile 打包时 __file__ 指向临时解压目录，这里改用当前工作目录
            out = os.path.join(os.getcwd(), "_shot.png")

        def _snap():
            try:
                w.user32.SetCursorPos(300, 250)
            except Exception:
                pass
            import time as _t
            _t.sleep(0.3)
            try:
                from PIL import ImageGrab
                ImageGrab.grab().save(out)
                print("SAVED_SHOT", out, flush=True)
            except Exception as e:
                print("SHOT_FAIL", e, flush=True)
            app.shutdown()

        QTimer.singleShot(int(wait * 1000), _snap)

    # 演示/自测钩子：--demo fs|dbl|overview
    if "--demo" in sys.argv:
        idx = sys.argv.index("--demo")
        mode = sys.argv[idx + 1] if len(sys.argv) > idx + 1 else "fs"

        def _demo():
            print("DEMO", mode, flush=True)
            if mode == "offscreen":
                # 自建一个窗口，故意放到副屏左外侧（只露边角），验证运行期巡检会拉回
                from PyQt5.QtWidgets import QWidget
                own = QWidget()
                own.setWindowTitle("SeelenLite-OutScreen-Test")
                own.setStyleSheet("background:#2d6a4f;")
                own.setGeometry(200, 200, 900, 600)
                own.show()
                app.processEvents()
                th = int(own.winId())
                w.set_pos(th, w.HWND_TOP, -3222, 0, 900, 600, w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
                print("OFFSCREEN_SET", w.get_rect(th),
                      "fraction", round(w.rect_visible_fraction(*w.get_rect(th)), 3),
                      "workrects", w.enum_monitor_work_rects(), flush=True)

                def _chk_pull():
                    r = w.get_rect(th)
                    print("OFFSCREEN_AFTER", r,
                          "fraction", round(w.rect_visible_fraction(*r), 3),
                          "pulled", r[0] > -1900, flush=True)
                    own.close()

                QTimer.singleShot(7000, _chk_pull)
                return

            if mode == "anim":
                # 缩小动画：卡片应在 120ms 时处于中间态，700ms 时落到目标几何
                from PyQt5.QtWidgets import QWidget
                from PyQt5.QtWidgets import QLabel
                own = QWidget()
                own.setWindowTitle("SeelenLite-Anim-Test")
                own.setStyleSheet("background:#eef1f6;")
                own.setGeometry(120, 160, 1000, 680)
                lab = QLabel("SeelenLite 缩略图测试 ABCD 12345", own)
                lab.setStyleSheet("background:#c0392b;color:#ffffff;font-size:44px;"
                                  "font-family:'Microsoft YaHei';padding:18px;")
                lab.setGeometry(40, 40, 900, 120)
                lab2 = QLabel("内容应该随卡片一起等比缩小，不能重排", own)
                lab2.setStyleSheet("color:#1b2b4b;font-size:28px;"
                                   "font-family:'Microsoft YaHei';")
                lab2.setGeometry(40, 200, 900, 60)
                own.show()
                app.processEvents()
                th = int(own.winId())
                print("ANIM_START_RECT", w.get_rect(th), flush=True)
                ok = app.cards.cardify(th, animate=True)
                card = app.cards.cards.get(th)
                print("ANIM_CARDIFY", ok, "card", card is not None,
                      "target", None if card is None else
                      (card._base_geom.x(), card._base_geom.y(),
                       card._base_geom.width(), card._base_geom.height()), flush=True)

                def _mid():
                    if card is not None:
                        g = card.geometry()
                        print("ANIM_MID", (g.x(), g.y(), g.width(), g.height()),
                              "running", card._anim is not None, flush=True)

                def _end():
                    if card is not None:
                        g = card.geometry()
                        t = card._base_geom
                        print("ANIM_END", (g.x(), g.y(), g.width(), g.height()),
                              "at_target", (g.x(), g.y(), g.width(), g.height())
                              == (t.x(), t.y(), t.width(), t.height()),
                              "anim_done", card._anim is None, flush=True)
                        try:
                            img = w.capture_window(int(card.winId()))
                            if img is not None:
                                img.save("_anim_card.png")
                                print("ANIM_SHOT", img.width(), img.height(), flush=True)
                        except Exception as _e:
                            print("ANIM_SHOT_ERR", repr(_e), flush=True)
                    app.cards.restore_all(animate=False)
                    own.close()

                QTimer.singleShot(120, _mid)
                QTimer.singleShot(700, _end)
                return

            if mode == "hover":
                # 悬停：光标进入卡片 -> 放大；移开 -> 复原
                from PyQt5.QtWidgets import QWidget
                own = QWidget()
                own.setWindowTitle("SeelenLite-Hover-Test")
                own.setStyleSheet("background:#3a2f5b;")
                own.setGeometry(420, 220, 900, 620)
                own.show()
                app.processEvents()
                th = int(own.winId())
                app.cards.cardify(th, animate=False)
                app.processEvents()
                card = app.cards.cards.get(th)
                if card is None:
                    print("NO_CARD", flush=True)
                    own.close()
                    return
                base = QRect(card.geometry())
                old_pos = w.cursor_pos()
                print("HOVER_BASE", (base.x(), base.y(), base.width(), base.height()), flush=True)

                def _enter():
                    w.user32.SetCursorPos(base.center().x(), base.center().y())

                def _check_in():
                    g = card.geometry()
                    print("HOVER_IN", (g.x(), g.y(), g.width(), g.height()),
                          "grew", g.width() > base.width() + 6,
                          "ratio", round(g.width() / float(max(1, base.width())), 3), flush=True)
                    w.user32.SetCursorPos(20, 980)   # 移出卡片

                def _check_out():
                    g = card.geometry()
                    print("HOVER_OUT", (g.x(), g.y(), g.width(), g.height()),
                          "restored", abs(g.width() - base.width()) <= 2
                          and abs(g.height() - base.height()) <= 2, flush=True)
                    w.user32.SetCursorPos(old_pos[0], old_pos[1])
                    app.cards.restore_all(animate=False)
                    own.close()

                QTimer.singleShot(400, _enter)
                QTimer.singleShot(1100, _check_in)
                QTimer.singleShot(1900, _check_out)
                return

            if mode == "cardresize":
                # 悬停 -> 按右下角缩放 -> 松手，逐步打印几何，定位「缩完自己变回去」
                from PyQt5.QtWidgets import QWidget
                own = QWidget()
                own.setWindowTitle("SeelenLite-Resize-Test")
                own.setStyleSheet("background:#20465e;")
                own.setGeometry(520, 280, 900, 620)
                own.show()
                app.processEvents()
                th = int(own.winId())
                ok = app.cards.cardify(th, animate=False)
                app.processEvents()
                card = app.cards.cards.get(th)
                if card is None:
                    print("NO_CARD", ok, flush=True)
                    own.close()
                    return
                base = QRect(card.geometry())
                print("RS_BASE", (base.x(), base.y(), base.width(), base.height()), flush=True)

                def _info(tag):
                    g = card.geometry()
                    b = card._base_geom
                    print(tag, (g.x(), g.y(), g.width(), g.height()),
                          "base", (b.x(), b.y(), b.width(), b.height()),
                          "hover_on", card._hover_on,
                          "locked", card._hover_locked,
                          "resizing", card._resizing,
                          "press", card._press is not None, flush=True)

                def _enter():
                    w.user32.SetCursorPos(base.center().x(), base.center().y())

                def _press():
                    g = card.geometry()
                    w.user32.SetCursorPos(g.x() + g.width() - 8,
                                          g.y() + g.height() - 8)
                    _info("RS_AT_CORNER")
                    w.user32.mouse_event(0x0002, 0, 0, 0, 0)

                def _drag():
                    _info("RS_PRESSED")
                    g = card.geometry()
                    x, y = g.x() + g.width(), g.y() + g.height()
                    for i in range(1, 5):
                        w.user32.SetCursorPos(x + 36 * i, y + 26 * i)
                        app.processEvents()
                    _info("RS_DRAGGED")

                def _release():
                    w.user32.mouse_event(0x0004, 0, 0, 0, 0)   # LEFTUP
                    app.processEvents()
                    QTimer.singleShot(80, lambda: _info("RS_UP_80"))
                    QTimer.singleShot(500, lambda: _info("RS_UP_500"))
                    QTimer.singleShot(900, lambda: _info("RS_UP_900"))

                def _away():
                    w.user32.SetCursorPos(24, 960)
                    QTimer.singleShot(700, lambda: _info("RS_AWAY"))
                    # 再移回来：悬停应该恢复正常（锁只到光标离开为止）
                    QTimer.singleShot(1100, _back)

                def _back():
                    g = card.geometry()
                    w.user32.SetCursorPos(g.center().x(), g.center().y())
                    QTimer.singleShot(700, lambda: _info("RS_BACK"))

                QTimer.singleShot(300, _enter)
                QTimer.singleShot(900, lambda: _info("RS_HOVER"))
                QTimer.singleShot(1000, _press)
                QTimer.singleShot(1150, _drag)
                QTimer.singleShot(1600, _release)
                QTimer.singleShot(2000, _away)

                def _end():
                    _info("RS_END")
                    app.cards.restore_all(animate=False)
                    own.close()

                QTimer.singleShot(3400, _end)
                return

            if mode == "cardmove":
                # 悬停放大 -> 按住拖动位置 -> 松手：尺寸必须回到手动调节的基准
                from PyQt5.QtWidgets import QWidget
                own = QWidget()
                own.setWindowTitle("SeelenLite-Move-Test")
                own.setStyleSheet("background:#1f4a3d;")
                own.setGeometry(500, 260, 880, 600)
                own.show()
                app.processEvents()
                th = int(own.winId())
                app.cards.cardify(th, animate=False)
                app.processEvents()
                card = app.cards.cards.get(th)
                if card is None:
                    print("NO_CARD", flush=True)
                    own.close()
                    return
                base = QRect(card.geometry())
                print("MV_BASE", (base.x(), base.y(), base.width(), base.height()), flush=True)

                def _info(tag):
                    g = card.geometry()
                    b = card._base_geom
                    p = w.cursor_pos()
                    top = w.root_window(w.window_from_point(p[0], p[1]))
                    print(tag, (g.x(), g.y(), g.width(), g.height()),
                          "base", (b.x(), b.y(), b.width(), b.height()),
                          "hover_on", card._hover_on,
                          "block", card._hover_block,
                          "cursor", p,
                          "top", int(top or 0), repr(w.get_title(top)) if top else "",
                          "hit", card._hit_test_self(), flush=True)

                def _enter():
                    w.user32.SetCursorPos(base.center().x(), base.center().y())

                def _press():
                    # 按在卡片中间偏上：既不是右下角，也不在按钮上
                    g = card.geometry()
                    px, py = g.x() + g.width() // 2, g.y() + g.height() // 2
                    w.user32.SetCursorPos(px, py)
                    _info("MV_HOVER")
                    w.user32.mouse_event(0x0002, 0, 0, 0, 0)
                    app.processEvents()
                    for i in range(1, 5):
                        w.user32.SetCursorPos(px + 35 * i, py + 22 * i)
                        app.processEvents()
                    _info("MV_DRAGGED")

                def _release():
                    w.user32.mouse_event(0x0004, 0, 0, 0, 0)   # LEFTUP
                    app.processEvents()
                    QTimer.singleShot(60, lambda: _info("MV_UP_60"))
                    QTimer.singleShot(400, lambda: _info("MV_UP_400"))
                    QTimer.singleShot(800, lambda: _info("MV_UP_800"))
                    QTimer.singleShot(1200, lambda: _info("MV_UP_1200"))

                def _away():
                    w.user32.SetCursorPos(24, 990)
                    QTimer.singleShot(700, lambda: _info("MV_AWAY"))

                def _back():
                    b = card._base_geom
                    w.user32.SetCursorPos(b.center().x(), b.center().y())
                    QTimer.singleShot(700, lambda: _info("MV_BACK"))

                QTimer.singleShot(300, _enter)
                QTimer.singleShot(900, _press)
                QTimer.singleShot(1500, _release)
                QTimer.singleShot(2300, _away)
                QTimer.singleShot(3100, _back)

                def _end():
                    _info("MV_END")
                    app.cards.restore_all(animate=False)
                    own.close()

                QTimer.singleShot(4200, _end)
                return

            if mode == "hoverz":
                # 悬停命中必须看 z 序：卡片被别的窗口盖住时，鼠标划过不该触发放大
                from PyQt5.QtWidgets import QWidget
                own = QWidget()
                own.setWindowTitle("SeelenLite-HoverZ-Test")
                own.setStyleSheet("background:#3a2f5b;")
                own.setGeometry(420, 220, 900, 620)
                own.show()
                app.processEvents()
                th = int(own.winId())
                app.cards.cardify(th, animate=False)
                app.processEvents()
                card = app.cards.cards.get(th)
                if card is None:
                    print("NO_CARD", flush=True)
                    own.close()
                    return
                base = QRect(card.geometry())
                cover = QWidget()
                cover.setWindowTitle("SeelenLite-Cover")
                cover.setStyleSheet("background:#c0392b;")
                cover.setGeometry(base)
                cover.show()
                cover.raise_()
                app.processEvents()
                print("HZ_BASE", (base.x(), base.y(), base.width(), base.height()),
                      "cover", int(cover.winId()), "card", int(card.winId()), flush=True)

                def _enter():
                    w.user32.SetCursorPos(base.center().x(), base.center().y())

                def _check():
                    g = card.geometry()
                    print("HZ_AFTER", (g.x(), g.y(), g.width(), g.height()),
                          "grew", g.width() > base.width() + 6,
                          "point_hwnd", w.window_from_point(base.center().x(),
                                                            base.center().y()),
                          "cover_hwnd", int(cover.winId()), flush=True)
                    cover.close()
                    app.cards.restore_all(animate=False)
                    own.close()

                QTimer.singleShot(400, _enter)
                QTimer.singleShot(1400, _check)
                return

            if mode == "clicks":
                # 连点卡片：看每次点击后卡片/窗口的几何如何变化
                from PyQt5.QtWidgets import QWidget
                own = QWidget()
                own.setWindowTitle("SeelenLite-Click-Test")
                own.setStyleSheet("background:#2f4858;")
                own.setGeometry(460, 260, 900, 600)
                own.show()
                app.processEvents()
                th = int(own.winId())
                app.cards.cardify(th, animate=False)
                app.processEvents()
                card = app.cards.cards.get(th)
                if card is None:
                    print("NO_CARD", flush=True)
                    own.close()
                    return
                base = QRect(card.geometry())
                print("CL_BASE", (base.x(), base.y(), base.width(), base.height()),
                      "click_max", app.settings.click_max,
                      "mode", app.settings.click_max_mode, flush=True)
                cxp, cyp = base.center().x(), base.center().y()

                def _click_once(tag):
                    w.user32.SetCursorPos(cxp, cyp)
                    w.user32.mouse_event(0x0002, 0, 0, 0, 0)
                    w.user32.mouse_event(0x0004, 0, 0, 0, 0)
                    app.processEvents()

                    def _rep():
                        c = app.cards.cards.get(th)
                        g = QRect(c.geometry()) if c is not None else None
                        alive = False
                        try:
                            alive = w.is_window(int(card.winId()))
                        except Exception:
                            pass
                        cg = None
                        try:
                            cg = card.geometry()
                        except Exception:
                            pass
                        print(tag,
                              "card", (g.x(), g.y(), g.width(), g.height()) if g else None,
                              "ghost", alive,
                              "ghost_geom", (cg.x(), cg.y(), cg.width(), cg.height()) if cg else None,
                              "anim", card._anim is not None,
                              "expanding", th in app.cards._expanding,
                              "pending", th in app.cards._anim_pending,
                              "src", w.get_rect(th),
                              "cards", app.cards.count(),
                              "expanded", app.cards.is_expanded(th), flush=True)
                        # 下一击仍打在卡片/窗口中心附近
                        if c is not None:
                            gg = c.geometry()
                            w.user32.SetCursorPos(gg.center().x(), gg.center().y())

                    QTimer.singleShot(420, _rep)

                QTimer.singleShot(300, lambda: _click_once("CL_1"))
                QTimer.singleShot(1000, lambda: _click_once("CL_2"))
                QTimer.singleShot(1700, lambda: _click_once("CL_3"))

                def _end2():
                    app.cards.restore_all(animate=False)
                    own.close()

                QTimer.singleShot(2600, _end2)
                return

            if mode == "cycle":
                # 往返：卡片 -> 放大 -> 再卡片，验证动画路径与卡片位置复用
                from PyQt5.QtWidgets import QWidget
                own = QWidget()
                own.setWindowTitle("SeelenLite-Cycle-Test")
                own.setStyleSheet("background:#1f3b4d;")
                own.setGeometry(500, 260, 820, 560)
                own.show()
                app.processEvents()
                th = int(own.winId())
                start = w.get_rect(th)
                app.cards.cardify(th, animate=False)
                app.processEvents()
                card = app.cards.cards.get(th)
                cg = QRect(card.geometry()) if card is not None else None
                print("CYCLE_START", start,
                      "card", (cg.x(), cg.y(), cg.width(), cg.height()) if cg else None,
                      flush=True)

                app.cards.expand(th, animate=True)

                def _after_expand():
                    print("CYCLE_EXPANDED", w.get_rect(th),
                          "cards", app.cards.count(), flush=True)
                    # 光标先移开，否则新卡片会立刻被悬停放大，位置自然对不上
                    w.user32.SetCursorPos(20, 960)
                    app.cards.cardify(th, animate=True)

                    def _after_card():
                        c2 = app.cards.cards.get(th)
                        g2 = QRect(c2.geometry()) if c2 is not None else None
                        print("CYCLE_BACK",
                              (g2.x(), g2.y(), g2.width(), g2.height()) if g2 else None,
                              "same_card_pos", bool(cg and g2
                                                    and abs(g2.x() - cg.x()) <= 2
                                                    and abs(g2.y() - cg.y()) <= 2),
                              "src_offscreen", w.get_rect(th)[0] < -1000, flush=True)
                        app.cards.restore_all(animate=False)
                        own.close()

                    QTimer.singleShot(700, _after_card)

                QTimer.singleShot(700, _after_expand)
                return

            if mode == "restore":
                # 启动恢复：写入一条卡片态记录，调 restore_window_states 看是否重建卡片
                from PyQt5.QtWidgets import QWidget
                from core import exe_of
                own = QWidget()
                own.setWindowTitle("SeelenLite-Restore-Test")
                own.setStyleSheet("background:#4a2f1f;")
                own.setGeometry(600, 300, 780, 540)
                own.show()
                app.processEvents()
                th = int(own.winId())
                try:
                    exe = exe_of(w.get_pid(th)) or ""
                except Exception:
                    exe = ""
                k = app.settings.exe_key(exe)
                prev = app.settings.window_states.get(k)
                want = [64, 96, 300, 240]
                app.settings.remember_window(exe, [600, 300, 780, 540], "card", want)
                app.cards._restored_keys.clear()
                n = app.cards.restore_window_states()
                card = app.cards.cards.get(th)
                g = QRect(card.geometry()) if card is not None else None
                print("RESTORE_N", n, "rebuilt", card is not None,
                      "geom", (g.x(), g.y(), g.width(), g.height()) if g else None,
                      "match", bool(g and abs(g.x() - want[0]) <= 2
                                    and abs(g.y() - want[1]) <= 2
                                    and abs(g.width() - want[2]) <= 2), flush=True)
                app.cards.restore_all(animate=False)
                if prev is None:
                    app.settings.window_states.pop(k, None)
                else:
                    app.settings.window_states[k] = prev
                app.settings.save()
                own.close()
                return

            if mode == "persist":
                # 持久化：卡片化后重新读盘，确认状态与卡片几何都写进了配置文件
                from PyQt5.QtWidgets import QWidget
                from core import Settings, exe_of
                own = QWidget()
                own.setWindowTitle("SeelenLite-Persist-Test")
                own.setGeometry(260, 180, 880, 600)
                own.show()
                app.processEvents()
                th = int(own.winId())
                try:
                    exe = exe_of(w.get_pid(th)) or ""
                except Exception:
                    exe = ""
                k = app.settings.exe_key(exe)
                prev = app.settings.window_states.get(k)
                app.cards.cardify(th, animate=False)
                app.processEvents()
                card = app.cards.cards.get(th)
                g = card.geometry() if card is not None else None
                st = app.settings.recall_window(exe)
                print("PERSIST_STATE", st, flush=True)
                fresh = Settings()
                st2 = fresh.recall_window(exe)
                print("PERSIST_RELOAD", st2, flush=True)
                ok = bool(st2 and st2.get("mode") == "card" and st2.get("card")
                          and g is not None
                          and abs(st2["card"][2] - g.width()) <= 2
                          and abs(st2["card"][3] - g.height()) <= 2
                          and st2.get("rect") and len(st2["rect"]) == 4)
                print("PERSIST_OK", ok, flush=True)
                app.cards.restore_all(animate=False)
                # 还原测试前的记录，别把 python.exe 的假状态留在配置里
                if prev is None:
                    app.settings.window_states.pop(k, None)
                else:
                    app.settings.window_states[k] = prev
                app.settings.save()
                own.close()
                return

            if mode == "wstate":
                # 窗口状态记忆：普通调整 -> 最大化 -> 关闭 -> 下一次启动恢复
                from PyQt5.QtWidgets import QWidget
                from core import exe_of
                from PyQt5.QtCore import Qt as _Qt
                app.cards._boot_until = 0.0   # 跳过启动保护期
                own = QWidget()
                own.setWindowTitle("SeelenLite-WState-App")
                own.setAttribute(_Qt.WA_DeleteOnClose, True)
                own.setGeometry(260, 180, 760, 520)
                own.show()
                app.processEvents()
                th = int(own.winId())
                try:
                    exe = exe_of(w.get_pid(th)) or ""
                except Exception:
                    exe = ""
                k = app.settings.exe_key(exe)
                prev = app.settings.window_states.get(k)
                want = [300, 220, 800, 560]
                w.set_pos(th, w.HWND_TOP, *want, w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
                app.processEvents()
                box = {"own2": None, "th2": 0}

                def _st():
                    return app.settings.recall_window(exe)

                def _p(tag):
                    print(tag, _st(), "zoomed", w.is_zoomed(th) if w.is_window(th) else "-",
                          "live", app.cards._live.get(th), flush=True)

                def _maxed():
                    w.show(th, w.SW_MAXIMIZE)
                    _p("WS_MAXIMIZED")

                def _closed():
                    _p("WS_BEFORE_CLOSE")
                    own.close()
                    app.processEvents()

                def _closed_check():
                    print("WS_CLOSED", "alive", w.is_window(th), "state", _st(), flush=True)

                def _reopen():
                    own2 = QWidget()
                    own2.setWindowTitle("SeelenLite-WState-App2")
                    own2.setGeometry(900, 100, 420, 300)
                    own2.show()
                    app.processEvents()
                    box["own2"] = own2
                    box["th2"] = int(own2.winId())
                    app.cards._restored_keys.discard(k)
                    n = app.cards.restore_window_states()
                    th2 = box["th2"]
                    nr = w.normal_rect(th2)
                    print("WS_RESTORED", n, "zoomed", w.is_zoomed(th2),
                          "normal", nr, "match", all(abs(nr[i] - want[i]) <= 8 for i in range(4)),
                          flush=True)

                def _no_overwrite():
                    before = _st()
                    app.cards.flush_states()
                    app.cards.restore_all(animate=False, persist=False)
                    print("WS_SHUTDOWN_NO_OVERWRITE", "same", _st() == before, _st(), flush=True)

                QTimer.singleShot(900, lambda: _p("WS_MOVED"))
                QTimer.singleShot(2600, _maxed)
                QTimer.singleShot(4600, lambda: _p("WS_MAX_SAVED"))
                QTimer.singleShot(4700, _closed)
                QTimer.singleShot(5700, _closed_check)
                QTimer.singleShot(5800, _reopen)
                QTimer.singleShot(7200, _no_overwrite)

                def _end():
                    for wid in (box["own2"],):
                        try:
                            if wid is not None:
                                wid.close()
                        except Exception:
                            pass
                    try:
                        own.close()
                    except Exception:
                        pass
                    if prev is None:
                        app.settings.window_states.pop(k, None)
                    else:
                        app.settings.window_states[k] = prev
                    app.settings.save()
                    print("WS_END", flush=True)

                QTimer.singleShot(8000, _end)
                return

            if mode == "raise":
                # 悬停置顶：A/B 两个重叠窗口，鼠标移到谁身上谁到最前，且不抢焦点
                from PyQt5.QtWidgets import QWidget
                app.hover.enabled = True
                app.hover.start()
                A = QWidget()
                A.setWindowTitle("Raise-A")
                A.setGeometry(420, 260, 720, 520)
                A.show()
                B = QWidget()
                B.setWindowTitle("Raise-B")
                B.setGeometry(680, 360, 720, 520)
                B.show()
                app.processEvents()
                ha, hb = int(A.winId()), int(B.winId())
                cnt = {"n": 0}

                def _bump(h):
                    cnt["n"] += 1

                app.hover.raised.connect(_bump)

                def _zorder():
                    seq = []

                    def cb(h):
                        seq.append(h)
                        return True

                    w.enum_windows(cb)
                    try:
                        return "A_TOP" if seq.index(ha) < seq.index(hb) else "B_TOP"
                    except ValueError:
                        return "?"

                def _fg():
                    try:
                        return w.get_title(w.get_foreground_window())
                    except Exception:
                        return "?"

                def _to_a():
                    w.user32.SetCursorPos(500, 320)

                def _to_b():
                    w.user32.SetCursorPos(1300, 820)

                def _report(tag):
                    print(tag, "z", _zorder(), "fg", _fg(), "raised", cnt["n"], flush=True)

                QTimer.singleShot(300, _to_a)
                QTimer.singleShot(800, lambda: _report("RAISE_TO_A"))
                QTimer.singleShot(1100, _to_b)
                QTimer.singleShot(1600, lambda: _report("RAISE_TO_B"))

                def _sweep(i=0):
                    # 快速横扫：每 80ms 换一个窗口，防抖应该不发或只发一次
                    if i >= 8:
                        return
                    w.user32.SetCursorPos(500 if i % 2 == 0 else 1300,
                                          320 if i % 2 == 0 else 820)
                    QTimer.singleShot(80, lambda: _sweep(i + 1))

                QTimer.singleShot(1900, _sweep)
                QTimer.singleShot(2900, lambda: _report("RAISE_SWEEP_END"))
                QTimer.singleShot(3200, _to_a)
                QTimer.singleShot(3700, lambda: _report("RAISE_AGAIN_A"))

                def _end():
                    app.hover.stop()
                    A.close()
                    B.close()
                    print("RAISE_END", flush=True)

                QTimer.singleShot(4300, _end)
                return

            if mode == "animprobe":
                # 采样缩小/放大动画的帧序列，检查有没有跳帧、回退
                from PyQt5.QtWidgets import QWidget
                own = QWidget()
                own.setWindowTitle("SeelenLite-Anim-Test")
                own.setGeometry(480, 240, 880, 600)
                own.show()
                app.processEvents()
                th = int(own.winId())
                box = {"samples": [], "phase": "shrink"}

                def _sample():
                    # 展开时卡片会立刻从 cards 字典里摘掉，所以留个引用自己采样
                    c = box.get("card")
                    if c is None:
                        return
                    try:
                        g = c.geometry()
                    except RuntimeError:
                        timer.stop()
                        return
                    box["samples"].append((time.time(), g.width(), g.height()))

                timer = QTimer(app)
                timer.setInterval(16)
                timer.timeout.connect(_sample)

                def _summary(tag):
                    ss = box["samples"]
                    if len(ss) < 2:
                        print(tag, "NO_SAMPLES", flush=True)
                        return
                    dur = ss[-1][0] - ss[0][0]
                    steps = [abs(ss[i][1] - ss[i - 1][1]) for i in range(1, len(ss))]
                    back = sum(1 for i in range(2, len(ss))
                               if (ss[i][1] - ss[i - 1][1]) * (ss[i - 1][1] - ss[i - 2][1]) < 0)
                    print(tag, "frames", len(ss), "dur_ms", int(dur * 1000),
                          "fps", round((len(ss) - 1) / dur, 1) if dur > 0 else 0,
                          "max_step", max(steps), "reversals", back,
                          "w", ss[0][1], "->", ss[-1][1], flush=True)


                def _shrink():
                    timer.start()
                    app.cards.cardify(th, animate=True)
                    box["card"] = app.cards.cards.get(th)

                def _end_shrink():
                    timer.stop()
                    _summary("ANIM_SHRINK")
                    box["samples"] = []
                    box["card"] = app.cards.cards.get(th)
                    timer.start()
                    app.cards.expand(th, animate=True)

                def _end_expand():
                    timer.stop()
                    _summary("ANIM_EXPAND")
                    app.cards.restore_all(animate=False)
                    own.close()
                    print("ANIM_END", flush=True)

                QTimer.singleShot(400, _shrink)
                QTimer.singleShot(1100, _end_shrink)
                QTimer.singleShot(1900, _end_expand)
                return

            if mode == "exit":
                # 退出还原：卡片化之后走同步还原，窗口必须回到桌面原位置
                from PyQt5.QtWidgets import QWidget
                from core import exe_of
                own = QWidget()
                own.setWindowTitle("SeelenLite-Exit-Test")
                own.setGeometry(320, 220, 860, 580)
                own.show()
                app.processEvents()
                th = int(own.winId())
                try:
                    exe = exe_of(w.get_pid(th)) or ""
                except Exception:
                    exe = ""
                k = app.settings.exe_key(exe)
                prev = app.settings.window_states.get(k)
                before = w.get_rect(th)
                app.cards.cardify(th, animate=False)
                app.processEvents()
                print("EXIT_CARDIFIED", w.get_rect(th),
                      "cards", app.cards.count(), flush=True)
                app.cards.restore_all(animate=False)   # 退出时的同步路径
                after = w.get_rect(th)
                frac = w.rect_visible_fraction(*after)
                print("EXIT_AFTER", after, "cards", app.cards.count(),
                      "visible", frac > 0.8, "same_rect", after == before, flush=True)
                if prev is None:
                    app.settings.window_states.pop(k, None)
                else:
                    app.settings.window_states[k] = prev
                app.settings.save()
                own.close()
                return

            if mode == "overview":
                app.overview.open()
                if "--esc-check" in sys.argv:
                    import time as _t

                    def _esc():
                        _t.sleep(0.4)
                        print("ESC_BEFORE visible=", app.overview.isVisible(), flush=True)
                        w.user32.keybd_event(0x1B, 0, 0, 0)
                        w.user32.keybd_event(0x1B, 0, 0x0002, 0)

                        def _check():
                            print("ESC_AFTER visible=", app.overview.isVisible(), flush=True)

                        QTimer.singleShot(400, _check)

                    QTimer.singleShot(600, _esc)
                return
            tgt = ""
            if "--target" in sys.argv:
                ti = sys.argv.index("--target")
                if len(sys.argv) > ti + 1:
                    tgt = sys.argv[ti + 1]
            hwnd = 0
            if tgt:
                found = []
                w.enum_windows(lambda h: (found.append(h) or True))
                app.wm.refresh()
                for h in found:
                    t = w.get_title(h) or ""
                    if tgt.lower() in t.lower() and w.is_visible(h):
                        hwnd = h
                        break
            else:
                hwnd = w.get_foreground_window()
            info = app.wm.by_hwnd(hwnd)
            if info is None and hwnd:
                from core import WindowInfo, exe_of
                info = WindowInfo(hwnd, w.get_title(hwnd), w.get_class(hwnd),
                                  w.get_rect(hwnd), w.get_pid(hwnd))
                info.exe = exe_of(info.pid)
            if info is None:
                app.wm.refresh()
                info = app.wm.by_hwnd(hwnd)
            if info is None and app.wm.windows:
                info = app.wm.windows[0]
            if info is None:
                print("DEMO_NO_WINDOW", flush=True)
                return
            print("TARGET", info.hwnd, repr(info.title), w.get_rect(info.hwnd), flush=True)

            def _click_at(x, y):
                w.user32.SetCursorPos(int(x), int(y))
                w.user32.mouse_event(0x0002, 0, 0, 0, 0)   # LEFTDOWN
                w.user32.mouse_event(0x0004, 0, 0, 0, 0)   # LEFTUP

            if mode == "card":
                print("BEFORE_CARDIFY", flush=True)
                try:
                    ok = app.cards.cardify(info.hwnd)
                    card = app.cards.cards.get(info.hwnd)
                    print("CARDIFY", ok, "cards", app.cards.count(),
                          "src_rect", w.get_rect(info.hwnd),
                          "card_geom", card.geometry() if card else None, flush=True)
                except Exception:
                    import traceback
                    traceback.print_exc()

                def _alive():
                    print("AFTER_CARDIFY_ALIVE", app.cards.count(), flush=True)

                QTimer.singleShot(1200, _alive)
                return

            if mode == "zorder":
                # 卡片不得置顶：拿一个普通窗口盖上去，应该盖得住
                from PyQt5.QtWidgets import QWidget

                own = None
                target = info.hwnd
                if not tgt:
                    # 没有指定目标就自建一个测试窗口，不碰用户的任何窗口
                    own = QWidget()
                    own.setWindowTitle("SeelenLite-Test")
                    own.setStyleSheet("background:#2b6cb0;")
                    own.setGeometry(300, 180, 860, 560)
                    own.show()
                    app.processEvents()
                    target = int(own.winId())
                    print("OWN_HWND", target, flush=True)

                ok = app.cards.cardify(target)
                card = app.cards.cards.get(target)
                if card is None:
                    print("NO_CARD", ok, flush=True)
                    return
                g = card.geometry()
                cx, cy = g.x() + g.width() // 2, g.y() + g.height() // 2
                ch = int(card.winId())
                print("CARD_TOP", "topmost", card.is_topmost(),
                      "ex", hex(w.get_exstyle(ch) & 0xFFFFFFFF),
                      "point_hwnd", w.window_from_point(cx, cy),
                      "card_hwnd", ch, flush=True)

                cov = QWidget()
                cov.setStyleSheet("background:#c0392b;")
                cov.setWindowFlags(Qt.FramelessWindowHint)
                cov.setGeometry(g.x(), g.y(), g.width(), g.height())
                cov.show()
                cov.raise_()

                def _chk_z():
                    top = w.window_from_point(cx, cy)
                    print("COVER_HWND", int(cov.winId()), "point_top", top,
                          "covered", top == int(cov.winId()),
                          "card_topmost", card.is_topmost(), flush=True)
                    cov.close()
                    if own is not None:
                        own.close()

                QTimer.singleShot(900, _chk_z)
                return

            if mode == "right_single":
                # 实际工作流：单击放大 -> 在放大窗口里右键 -> 缩回卡片
                app._single_click_impl(0, 0, 0, info.hwnd)
                r = w.get_rect(info.hwnd)
                cx, cy = r[0] + r[2] // 2, r[1] + r[3] // 2
                print("SINGLE_EXPAND", r, "in_expanded", app.cards.is_expanded(info.hwnd),
                      "right_target", app._right_target(info.hwnd), flush=True)

                def _rc2():
                    w.user32.SetCursorPos(int(cx), int(cy))
                    w.user32.mouse_event(0x0008, 0, 0, 0, 0)   # RIGHTDOWN
                    w.user32.mouse_event(0x0010, 0, 0, 0, 0)   # RIGHTUP

                    def _chk8():
                        print("AFTER_RIGHT_SINGLE", w.get_rect(info.hwnd),
                              "cards", app.cards.count(),
                              "in_cards", info.hwnd in app.cards.cards, flush=True)

                    QTimer.singleShot(1000, _chk8)

                QTimer.singleShot(600, _rc2)
                return

            if mode == "right":
                # 右键缩回：自建窗口卡片化后展开，再用真实右键点内容区
                from PyQt5.QtWidgets import QWidget

                own = QWidget()
                own.setWindowTitle("SeelenLite-Test")
                own.setStyleSheet("background:#2b6cb0;")
                own.setGeometry(300, 180, 860, 560)
                own.show()
                app.processEvents()
                target = int(own.winId())
                print("OWN_HWND", target, flush=True)
                print("RT_OTHER", app._right_target(info.hwnd),
                      "RT_OWN", app._right_target(int(app.dock.winId())),
                      flush=True)

                app.cards.cardify(target)
                app.cards.expand(target)
                r = w.get_rect(target)
                cx, cy = r[0] + r[2] // 2, r[1] + r[3] // 2
                print("EXPANDED", r, "in_expanded", app.cards.is_expanded(target),
                      "right_target", app._right_target(target), flush=True)

                def _right_click():
                    w.user32.SetCursorPos(int(cx), int(cy))
                    w.user32.mouse_event(0x0008, 0, 0, 0, 0)   # RIGHTDOWN
                    w.user32.mouse_event(0x0010, 0, 0, 0, 0)   # RIGHTUP

                    def _chk():
                        menus = []
                        w.enum_windows(lambda h: (menus.append(h) if
                                                  w.get_class(h) == "#32768" and
                                                  w.is_visible(h) else True))
                        print("AFTER_RIGHT", w.get_rect(target),
                              "cards", app.cards.count(),
                              "in_cards", target in app.cards.cards,
                              "menus", len(menus), flush=True)
                        own.close()

                    QTimer.singleShot(1000, _chk)

                QTimer.singleShot(700, _right_click)
                return

            if mode == "rects":
                # 各种放大幅度算出来的尺寸，用来检查会不会太挤
                for preset in ("full", "wide", "half", "custom"):
                    app.settings.expand_preset = preset
                    app.settings.expand_ratio = 0.62
                    print("PRESET", preset,
                          app.cards.expand_rect(info.hwnd,
                                                {"exe": info.exe, "rect": info.rect}),
                          flush=True)
                return

            if mode == "close":
                ok = app.cards.cardify(info.hwnd)
                print("CARDIFY_FOR_CLOSE", ok, "cards", app.cards.count(), flush=True)

                def _hit_close():
                    card = app.cards.cards.get(info.hwnd)
                    if card is None:
                        print("NO_CARD", flush=True)
                        return
                    card.raise_()          # 卡片不置顶：测试前先提到前面
                    app.processEvents()
                    g = card.geometry()
                    b = card._btn_close
                    _click_at(g.x() + b.center().x(), g.y() + b.center().y())

                    def _chk5():
                        print("AFTER_CLOSE alive", w.is_window(info.hwnd),
                              "cards", app.cards.count(), flush=True)

                    QTimer.singleShot(900, _chk5)

                QTimer.singleShot(1000, _hit_close)
                return

            if mode == "fg":
                # 验证：卡片化的窗口被从别处切回前台时自动展开
                app.cards.cardify(info.hwnd)
                print("PARKED", w.get_rect(info.hwnd), "cards",
                      app.cards.count(), flush=True)

                def _away():
                    other = 0
                    for it in app.wm.windows:
                        if it.hwnd != info.hwnd:
                            other = it.hwnd
                            break
                    if other:
                        w.focus(other)
                    print("AWAY fg", repr(w.get_title(w.get_foreground_window())), flush=True)

                def _back():
                    w.focus(info.hwnd)

                def _chk7():
                    print("AFTER_FG", w.get_rect(info.hwnd), "cards",
                          app.cards.count(), flush=True)

                QTimer.singleShot(1500, _away)
                QTimer.singleShot(3000, _back)
                QTimer.singleShot(4800, _chk7)
                return

            if mode == "memory":
                # 展开 -> 手动改尺寸 -> 应该被记住
                app.cards.cardify(info.hwnd)
                print("CARDIFY", app.cards.count(), flush=True)

                def _expand():
                    app.cards.expand(info.hwnd)
                    w.set_pos(info.hwnd, 0, 200, 160, 1100, 700,
                              w.SWP_SHOWWINDOW | w.SWP_NOACTIVATE)
                    print("EXPAND_RESIZE", w.get_rect(info.hwnd), flush=True)

                    def _chk6():
                        s = app.settings
                        k = s.exe_key(info.exe)
                        print("SAVED_SIZE", k, s.per_app_size.get(k), flush=True)

                    QTimer.singleShot(2600, _chk6)

                QTimer.singleShot(900, _expand)
                return

            if mode == "expand":
                print("CARDS_BEFORE", app.cards.count(), flush=True)
                app.cards.restore_all()

                def _chk2():
                    print("AFTER_EXPAND rect", w.get_rect(info.hwnd),
                          "zoomed", w.is_zoomed(info.hwnd),
                          "cards", app.cards.count(), flush=True)

                QTimer.singleShot(500, _chk2)
                return

            if mode == "esc":
                app.cards.expand(info.hwnd)
                app.wm.focus(info)
                print("EXPANDED", w.get_rect(info.hwnd), flush=True)

                def _esc():
                    w.user32.keybd_event(0x1B, 0, 0, 0)
                    w.user32.keybd_event(0x1B, 0, 2, 0)

                    def _chk4():
                        print("AFTER_ESC rect", w.get_rect(info.hwnd),
                              "cards", app.cards.count(), flush=True)

                    QTimer.singleShot(700, _chk4)

                QTimer.singleShot(900, _esc)
                return

            if mode == "cardclick":
                # 自建窗口做隔离测试，避免桌面上别的窗口盖住卡片
                from PyQt5.QtWidgets import QWidget

                own = QWidget()
                own.setWindowTitle("SeelenLite-Test")
                own.setStyleSheet("background:#2b6cb0;")
                own.setGeometry(300, 180, 900, 600)
                own.show()
                app.processEvents()
                target = int(own.winId())
                ok = app.cards.cardify(target)
                print("CARDIFY", ok, "cards", app.cards.count(), flush=True)

                def _click_card():
                    card = app.cards.cards.get(target)
                    if card is None:
                        print("NO_CARD", flush=True)
                        return
                    card.raise_()
                    app.processEvents()
                    g = card.geometry()
                    # 直接投递 Qt 鼠标消息：合成 mouse_event 在别的窗口抢焦点时
                    # 不稳定，这里只验证卡片的点击 -> 展开逻辑本身
                    hcard = int(card.winId())
                    lx, ly = g.width() // 2, 44
                    lp = (ly << 16) | lx
                    w.user32.PostMessageW(hcard, 0x0201, 1, lp)
                    w.user32.PostMessageW(hcard, 0x0202, 0, lp)

                    def _chk3():
                        print("AFTER_CARD_CLICK rect", w.get_rect(target),
                              "zoomed", w.is_zoomed(target),
                              "cards", app.cards.count(), flush=True)
                        own.close()

                    QTimer.singleShot(700, _chk3)

                QTimer.singleShot(900, _click_card)
                return

            if mode == "fs":
                app.wm.maximize(info)
                print("MAX_SET", w.get_rect(info.hwnd), flush=True)
                return

            l, t, ww, hh = w.get_rect(info.hwnd)
            if mode == "click":
                # 在内容区点一下，走真实的全局钩子
                _click_at(l + ww // 2, t + hh // 2)

                def _chk():
                    print("AFTER_CLICK rect", w.get_rect(info.hwnd),
                          "zoomed", w.is_zoomed(info.hwnd), flush=True)

                QTimer.singleShot(700, _chk)
                return

            if mode == "dbl":
                _click_at(l + ww // 2, t + hh // 2)   # 单击 -> 最大化

                def _after_max():
                    print("AFTER_CLICK rect", w.get_rect(info.hwnd),
                          "zoomed", w.is_zoomed(info.hwnd), flush=True)
                    l2, t2, w2, h2 = w.get_rect(info.hwnd)
                    tx, ty = l2 + w2 // 2, t2 + 8     # 标题栏中央
                    _click_at(tx, ty)

                    def _second():
                        _click_at(tx, ty)

                        def _chk():
                            print("AFTER_TITLE_DBL rect", w.get_rect(info.hwnd),
                                  "zoomed", w.is_zoomed(info.hwnd), flush=True)

                        QTimer.singleShot(500, _chk)

                    QTimer.singleShot(120, _second)

                QTimer.singleShot(700, _after_max)
                return

            app.wm.maximize(info)
            print("MAX_SET", w.get_rect(info.hwnd), flush=True)

        QTimer.singleShot(800, _demo)

        # --demo-quit [秒]：演示结束后自动退出，便于无头验证
        if "--demo-quit" in sys.argv:
            qidx = sys.argv.index("--demo-quit")
            qwait = 5.0
            if len(sys.argv) > qidx + 1:
                try:
                    qwait = float(sys.argv[qidx + 1])
                except Exception:
                    pass

            def _quit():
                try:
                    app.cards.restore_all()
                except Exception:
                    pass
                if app.wm.fs_hwnd:
                    hwnd = app.wm.fs_hwnd
                    app.wm.restore_max(hwnd)
                    print("QUIT_RESTORE", hwnd, w.get_rect(hwnd), flush=True)
                else:
                    print("QUIT_ALREADY_RESTORED", flush=True)
                app.shutdown()

            QTimer.singleShot(int(qwait * 1000), _quit)

    def _log_quit():
        if os.environ.get("SELENLITE_DEBUG"):
            print("ABOUT_TO_QUIT", flush=True)

    app.aboutToQuit.connect(_log_quit)
    app.aboutToQuit.connect(app.shutdown_hooks)
    return app.exec_()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception:
        import traceback
        traceback.print_exc()
        raise
